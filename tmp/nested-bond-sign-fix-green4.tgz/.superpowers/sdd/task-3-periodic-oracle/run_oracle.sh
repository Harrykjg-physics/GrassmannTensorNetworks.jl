#!/usr/bin/env bash
set -euo pipefail
export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin
export JULIA_PKG_OFFLINE=true
julia_grassmann --project=. exp/oracle.jl
