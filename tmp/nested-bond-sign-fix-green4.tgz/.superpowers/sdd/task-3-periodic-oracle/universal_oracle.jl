ENV["RUN_PERIODIC_ORACLE_MAIN"] = "false"
include(joinpath(@__DIR__, "oracle.jl"))

function assemble_universal_nodes(peps)
    rows, cols = size(peps)
    ket = Matrix{Grassmann{eltype(peps), 4}}(undef, rows, cols)
    bra = Matrix{Grassmann{eltype(peps), 4}}(undef, rows, cols)
    for r in 1:rows, c in 1:cols
        ket_input = add_parity_sign(
            peps.A[r, c], 4; sign_function=SIGN
        )
        bra_input = add_parity_sign(
            peps.A[r, c], 4; sign_function=SIGN
        )
        ket[r, c] = _nested_ket(ket_input)
        bra[r, c] = _nested_bra(bra_input)
    end

    nodes = Matrix{Grassmann{eltype(peps), 4}}(undef, 2rows, 2cols)
    for r in 1:rows, c in 1:cols
        xraw = _nested_x(
            size(bra[r, c])[1],
            even(bra[r, c])[1],
            size(ket[r, c])[4],
            even(ket[r, c])[4],
            eltype(peps),
        )
        xplaced = _placed_nested_x(xraw)
        x = add_perm_sign(
            xplaced, (1, 3, 2, 4); sign_function=SIGN
        )

        north_bra = bra[Nmod(r - 1, rows), c]
        east_ket = ket[r, Nmod(c + 1, cols)]
        yraw = _nested_y(
            _physical_identity(peps.A[r, c]),
            size(east_ket)[1],
            even(east_ket)[1],
            size(north_bra)[4],
            even(north_bra)[4],
        )
        y = add_perm_sign(yraw, (1, 3, 2, 4); sign_function=SIGN)

        nodes[2r - 1, 2c - 1] = ket[r, c]
        nodes[2r - 1, 2c] = y
        nodes[2r, 2c - 1] = x
        nodes[2r, 2c] = bra[r, c]
    end
    return nodes, ket, bra
end

function universal_local_comparison(raw)
    ordered = permutedims(raw, TILE_ORDER; sign_function=SIGN)
    corrected = _nested_reduced_basis(ordered)
    corrected = add_parity_sign(corrected, 5; sign_function=SIGN)
    corrected = add_parity_sign(corrected, 6; sign_function=SIGN)
    corrected = _graded_pair_sign(corrected, 1, 8)
    corrected = _graded_pair_sign(corrected, 4, 5)
    return reduced_style_fusions_local(corrected)
end

function minimal_peps(rows, cols)
    count = square_gpeps_parameter_count(2, 1, 2, rows, cols)
    params = [0.17sin(i) + 0.11cos(3i) for i in 1:count]
    return Square_GPEPS(2, 1, 2, rows, cols, params)
end

function verify_torus(label, peps)
    reduced = reduced_tensor(peps)
    nodes, _, _ = assemble_universal_nodes(peps)
    for (twist_x, twist_y) in
        ((false, false), (true, false), (false, true), (true, true))
        target = torus_scalar(
            reduced; twist_x=twist_x, twist_y=twist_y
        )
        candidate = torus_scalar(
            nodes; twist_x=twist_x, twist_y=twist_y
        )
        relative_error =
            abs(candidate - target) / max(abs(target), eps(Float64))
        println(
            "UNIVERSAL ", label,
            " tx=", twist_x,
            " ty=", twist_y,
            " target=", target,
            " candidate=", candidate,
            " rel=", relative_error,
        )
    end
end

for (rows, cols) in ((1, 1), (1, 2), (2, 1), (2, 2), (3, 2))
    verify_torus("shape=$(rows)x$(cols)", minimal_peps(rows, cols))
end

for T in (Float64, ComplexF64)
    peps = mixed_nonuniform_peps(T)
    nodes, ket, bra = assemble_universal_nodes(peps)
    maximum_local_error = 0.0
    for r in 1:2, c in 1:2
        raw = open_tile(
            ket[r, c],
            nodes[2r - 1, 2c],
            nodes[2r, 2c - 1],
            bra[r, c],
        )
        candidate = universal_local_comparison(raw)
        target = reduced_tensor(peps.A[r, c])
        maximum_local_error = max(
            maximum_local_error,
            maximum(abs, convert(Array, candidate) - convert(Array, target)),
        )
    end
    println(
        "UNIVERSAL_LOCAL type=", T,
        " max=", maximum_local_error,
    )
    verify_torus("mixed type=$(T)", peps)
end

println("UNIVERSAL_ORACLE_RESULT PASS")
