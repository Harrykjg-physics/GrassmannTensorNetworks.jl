from functools import reduce
from itertools import combinations, permutations, product


def perm_sign(q, dst):
    q, pos, sign = list(q), list(range(len(q))), 0
    for wanted in (x - 1 for x in dst):
        location = pos.index(wanted)
        if location:
            sign ^= (sum(q[:location]) & 1) & q[location]
        pos.pop(location)
        q.pop(location)
    return sign


def one_contract_sign(q, index, types):
    first, second = index
    first_type, second_type = types
    assert first_type != second_type and first < second
    start = first + 1 if first_type == "in" else first
    return (sum(q[start - 1 : second - 1]) & 1) & q[second - 1]


def multi_sign(q, first_indices, second_indices, first_types, second_types):
    q, record, sign = list(q), [len(q) + 1], 0
    for new_first, new_second, first_type, second_type in zip(
        first_indices, second_indices, first_types, second_types
    ):
        first = new_first - sum(new_first > old for old in record)
        second = new_second - sum(new_second > old for old in record)
        sign ^= one_contract_sign(
            q, (first, second), (first_type, second_type)
        )
        for location in sorted((first - 1, second - 1), reverse=True):
            q.pop(location)
        record.extend((new_first, new_second))
    return sign


def contract(first, second, first_indices, second_indices, perm=None):
    q1, arrows1, phase1 = first
    q2, arrows2, phase2 = second
    if isinstance(first_indices, int):
        first_indices, second_indices = (first_indices,), (second_indices,)
    second_global = tuple(len(q1) + i for i in second_indices)
    phase = phase1 ^ phase2 ^ multi_sign(
        q1 + q2,
        first_indices,
        second_global,
        tuple(arrows1[i - 1] for i in first_indices),
        tuple(arrows2[i - 1] for i in second_indices),
    )
    q = tuple(
        x for i, x in enumerate(q1, 1) if i not in first_indices
    ) + tuple(x for i, x in enumerate(q2, 1) if i not in second_indices)
    arrows = tuple(
        x for i, x in enumerate(arrows1, 1) if i not in first_indices
    ) + tuple(x for i, x in enumerate(arrows2, 1) if i not in second_indices)
    perm = perm or tuple(range(1, len(q) + 1))
    phase ^= perm_sign(q, perm)
    return (
        tuple(q[i - 1] for i in perm),
        tuple(arrows[i - 1] for i in perm),
        phase,
    )


def trace(tensor, first_indices, second_indices, pbc):
    q, arrows, phase = tensor
    if isinstance(first_indices, int):
        first_indices, second_indices, pbc = (
            (first_indices,),
            (second_indices,),
            (pbc,),
        )
    phase ^= multi_sign(
        q,
        first_indices,
        second_indices,
        tuple(arrows[i - 1] for i in first_indices),
        tuple(arrows[i - 1] for i in second_indices),
    )
    phase ^= sum(
        q[i - 1] for i, periodic in zip(first_indices, pbc) if not periodic
    ) & 1
    deleted = set(first_indices + second_indices)
    return (
        tuple(x for i, x in enumerate(q, 1) if i not in deleted),
        tuple(x for i, x in enumerate(arrows, 1) if i not in deleted),
        phase,
    )


def permuted(tensor, perm):
    q, arrows, phase = tensor
    return (
        tuple(q[i - 1] for i in perm),
        tuple(arrows[i - 1] for i in perm),
        phase ^ perm_sign(q, perm),
    )


def close_rank4_row(row, twist_x=False):
    current = permuted(row[0], (1, 3, 4, 2))
    for column in range(2, len(row) + 1):
        previous = column - 1
        rank = 2 * previous + 2
        perm = (
            1,
            *range(2, previous + 2),
            2 * previous + 3,
            *range(previous + 2, 2 * previous + 2),
            2 * previous + 4,
            2 * previous + 2,
        )
        current = contract(current, row[column - 1], rank, 1, perm)
    return trace(current, 1, 2 * len(row) + 2, not twist_x)


def torus_rank4(q_matrix, phases, twist_x=False, twist_y=False):
    tensors = [
        [
            (tuple(q), ("out", "in", "in", "out"), phases[r][c])
            for c, q in enumerate(row)
        ]
        for r, row in enumerate(q_matrix)
    ]
    columns = len(tensors[0])
    row_tensors = [
        close_rank4_row(row, twist_x=twist_x) for row in tensors
    ]
    current = row_tensors[0]
    for row in row_tensors[1:]:
        current = contract(
            current,
            row,
            tuple(range(columns + 1, 2 * columns + 1)),
            tuple(range(1, columns + 1)),
        )
    return trace(
        current,
        tuple(range(1, columns + 1)),
        tuple(range(columns + 1, 2 * columns + 1)),
        tuple(not twist_y for _ in range(columns)),
    )[2]


def close_rank8_row(row, twist_x=False):
    current = permuted(row[0], (1, 2, 5, 6, 7, 8, 3, 4))
    for column in range(2, len(row) + 1):
        previous = column - 1
        rank = 4 * previous + 4
        perm = (
            1,
            2,
            *range(3, 2 * previous + 3),
            rank + 1,
            rank + 2,
            *range(2 * previous + 3, 4 * previous + 3),
            rank + 3,
            rank + 4,
            rank - 1,
            rank,
        )
        current = contract(
            current,
            row[column - 1],
            (rank - 1, rank),
            (1, 2),
            perm,
        )
    return trace(
        current,
        (1, 2),
        (4 * len(row) + 3, 4 * len(row) + 4),
        (not twist_x, not twist_x),
    )


def torus_rank8(q_matrix, twist_x=False, twist_y=False):
    tensors = [
        [
            (
                tuple(q),
                ("out", "out", "in", "in", "in", "in", "out", "out"),
                0,
            )
            for q in row
        ]
        for row in q_matrix
    ]
    columns, width = len(tensors[0]), 2 * len(tensors[0])
    row_tensors = [
        close_rank8_row(row, twist_x=twist_x) for row in tensors
    ]
    current = row_tensors[0]
    for row in row_tensors[1:]:
        current = contract(
            current,
            row,
            tuple(range(width + 1, 2 * width + 1)),
            tuple(range(1, width + 1)),
        )
    return trace(
        current,
        tuple(range(1, width + 1)),
        tuple(range(width + 1, 2 * width + 1)),
        tuple(not twist_y for _ in range(width)),
    )[2]


def tile_variables(bits, row, column):
    bra_h, ket_h, bra_v, ket_v = (
        bits[:4],
        bits[4:8],
        bits[8:12],
        bits[12:16],
    )
    site = 2 * row + column
    left = 2 * row + (column - 1) % 2
    up = 2 * ((row - 1) % 2) + column
    return (
        bra_h[left],
        ket_h[left],
        bra_h[site],
        ket_h[site],
        bra_v[up],
        ket_v[up],
        bra_v[site],
        ket_v[site],
    )


def external_fuser_phase(q):
    b_left, _, b_right, k_right, b_up, k_up, b_down, _ = q
    return (b_left + b_down + b_right * k_right + b_up * k_up) & 1


def gf2_solve(matrix, rhs):
    columns = len(matrix[0])
    mask = (1 << columns) - 1
    rows = [
        sum(value << column for column, value in enumerate(row))
        | (rhs[index] << columns)
        for index, row in enumerate(matrix)
    ]
    pivots, pivot_row = [], 0
    for column in range(columns):
        selected = next(
            (
                row
                for row in range(pivot_row, len(rows))
                if (rows[row] >> column) & 1
            ),
            None,
        )
        if selected is None:
            continue
        rows[pivot_row], rows[selected] = rows[selected], rows[pivot_row]
        for row in range(len(rows)):
            if row != pivot_row and ((rows[row] >> column) & 1):
                rows[row] ^= rows[pivot_row]
        pivots.append(column)
        pivot_row += 1
    inconsistent = any(
        not (row & mask) and ((row >> columns) & 1) for row in rows
    )
    if inconsistent:
        return None, len(pivots)
    solution = [0] * columns
    for row, column in enumerate(pivots):
        solution[column] = (rows[row] >> columns) & 1
    return solution, len(pivots)


def main():
    assignments, residuals = [], []
    for bits in product((0, 1), repeat=16):
        rank8 = [
            [tile_variables(bits, row, column) for column in range(2)]
            for row in range(2)
        ]
        if any(
            (q[0] + q[2] + q[4] + q[6]) % 2
            != (q[1] + q[3] + q[5] + q[7]) % 2
            for row in rank8
            for q in row
        ):
            continue
        rank4 = [
            [
                (
                    q[0] ^ q[1],
                    q[2] ^ q[3],
                    q[4] ^ q[5],
                    q[6] ^ q[7],
                )
                for q in row
            ]
            for row in rank8
        ]
        fuser_phases = [
            [external_fuser_phase(q) for q in row] for row in rank8
        ]
        residual = torus_rank8(rank8) ^ torus_rank4(
            rank4, fuser_phases
        )
        assignments.append(bits)
        residuals.append(residual)

    print(
        "compatible",
        len(assignments),
        "connector_residual_nonzero",
        sum(residuals),
    )
    for twist_x, twist_y in ((1, 0), (0, 1), (1, 1)):
        differences = 0
        for bits, expected in zip(assignments, residuals):
            rank8 = [
                [tile_variables(bits, row, column) for column in range(2)]
                for row in range(2)
            ]
            rank4 = [
                [
                    (
                        q[0] ^ q[1],
                        q[2] ^ q[3],
                        q[4] ^ q[5],
                        q[6] ^ q[7],
                    )
                    for q in row
                ]
                for row in rank8
            ]
            fuser_phases = [
                [external_fuser_phase(q) for q in row] for row in rank8
            ]
            actual = torus_rank8(
                rank8, bool(twist_x), bool(twist_y)
            ) ^ torus_rank4(
                rank4,
                fuser_phases,
                bool(twist_x),
                bool(twist_y),
            )
            differences += actual != expected
        print("spin_residual_differences", twist_x, twist_y, differences)

    global_features = [()] + [(i,) for i in range(16)] + list(
        combinations(range(16), 2)
    )
    global_matrix = [
        [
            reduce(lambda value, index: value & bits[index], feature, 1)
            for feature in global_features
        ]
        for bits in assignments
    ]
    solution, rank = gf2_solve(global_matrix, residuals)
    print("global_quadratic_rank", rank)
    print(
        "global_polynomial",
        [feature for feature, value in zip(global_features, solution) if value],
    )

    # Local variables:
    # (p,bL,bR,bU,bD,kL,kR,kU,kD)
    node_specs = (
        ("K", (0, 5, 6, 7, 8)),
        ("B", (0, 1, 2, 3, 4)),
        ("X", (1, 8)),
        ("Y", (0, 6, 3)),
    )
    columns = []
    for node, indices in node_specs:
        for feature in [(i,) for i in indices] + list(
            combinations(indices, 2)
        ):
            columns.append((node, feature))
    local_matrix = []
    for bits in assignments:
        local_values = []
        for row in range(2):
            for column in range(2):
                q = tile_variables(bits, row, column)
                b_left, k_left, b_right, k_right, b_up, k_up, b_down, k_down = q
                physical = (k_left + k_right + k_up + k_down) & 1
                local_values.append(
                    (
                        physical,
                        b_left,
                        b_right,
                        b_up,
                        b_down,
                        k_left,
                        k_right,
                        k_up,
                        k_down,
                    )
                )
        row_values = []
        for _, feature in columns:
            total = 0
            for values in local_values:
                total ^= reduce(
                    lambda value, index: value & values[index],
                    feature,
                    1,
                )
            row_values.append(total)
        local_matrix.append(row_values)
    local_solution, local_rank = gf2_solve(local_matrix, residuals)
    print("local_columns", len(columns), "local_rank", local_rank)
    print("local_solvable", local_solution is not None)
    if local_solution is not None:
        print(
            "local_solution",
            [
                column
                for column, value in zip(columns, local_solution)
                if value
            ],
        )


if __name__ == "__main__":
    main()
