# Task 3 Existing-Operations Local Sign Solver

Status: **FEASIBLE**

No tracked source or test file was changed. This was an independent
parity-sector and periodic-composition audit.

## Conclusion

The native periodic K/Y/X/B checkerboard can be made exactly equivalent to
the native reduced network without an MPO, extra auxiliary leg, new node
type, or changed `Grassmann` contraction semantics.

Keep the raw categorical primitives unchanged, but use the following four
native placement corrections in the network:

```julia
ket_for_network = add_parity_sign(
    _nested_ket_raw(A), 3; sign_function=global_sign
) # K geographic U port: kU

# bU is not a parity of any final B port: B axis 3 has parity p+bU.
# Apply the twist to the original U leg before the (P,U) fusion.
bra_input = conj(A; sign_function=global_sign)
bra_input = add_parity_sign(
    bra_input, 4; sign_function=global_sign
) # original bra U leg: bU
signed_bra = _graded_pair_sign(bra_input, 1, 4)
routed_bra = permutedims(
    signed_bra, (2, 3, 1, 4, 5); sign_function=global_sign
)
fused_bra = fuse(routed_bra, (3, 4); index_type_fused=:in)
bra_for_network = foldl(_bend_index, (1, 2, 4); init=fused_bra)

x_for_network = add_perm_sign(
    _placed_nested_x(xraw),
    (1, 3, 2, 4);
    sign_function=global_sign,
)

y_for_network = add_perm_sign(
    _nested_y(...),
    (1, 3, 2, 4);
    sign_function=global_sign,
)
```

`add_perm_sign` does not move axes. The permutation `(1,3,2,4)` contributes
only the adjacent inversion `q2*q3`. The four added exponents are

```text
K: kU
B: bU
X: bL*kD
Y: kR*bU.
```

For X, the supported sectors obey

```text
(q1,q2,q3,q4) = (bL,bL,kD,kD),
```

so this contributes `bL*kD`. For Y,

```text
(q1,q2,q3,q4) = (p+kR,kR,bU,p+bU),
```

so it contributes `kR*bU`.

The X/Y terms cancel an explicit crossing coefficient at the placed-node
representation. This does **not** make the fermionic crossing bosonic:
native `contract(...; sign_function=auto_sign)` already contributes that
route exchange. Copying the TensorKit `BraidingTensor` coefficient unchanged
into the final native node counted the same exchange twice. The K/B twists
are the remaining vertical Jordan-Wigner gauge required when the number of
source rows is odd.

The raw `_nested_x` primitive should still retain odd-odd `-1`, and
`_nested_y` should still be constructed from the raw crossing. Only the
objects placed into the native checkerboard receive these native gauge
corrections.

## GF(2) setup

For every source tile, let

```text
p = kL+kR+kU+kD = bL+bR+bU+bD.
```

The four native node port parities are

```text
K = (kL, p+kR, kU, kD)
B = (bL, bR, p+bU, bD)
X = (bL, bL, kD, kD)
Y = (p+kR, kR, bU, p+bU).
```

An existing rank-four node can acquire every linear axis phase through
`add_parity_sign` and every required quadratic inversion phase through
compositions of `add_perm_sign`. Conjugation and paired
permutation/inverse-permutation sequences do not enlarge this degree-two
phase class.

### Local tile versus periodic network

The previous eight-leg comparison correction was

```text
C =
    kL+kR+kU
  + bL*kL+bL*bR+bL*kR+bL*bU+bL*kU+bL*bD
  + kR*bU.
```

On the 128 compatible local sectors, the four-node degree-two feature space
has rank 17 and contains `C`. This explains why a node-distributed local
factorization exists.

That local factorization is not the correct periodic gauge. It additionally
inserted the linear term `kL+kR+kU` into every K node. On the original
even-row `2 x 2` periodic oracle, the connector calculation reduces to

```text
Delta_torus =
    sum_cells (bL*kD + kR*bU).
```

The prior distributed candidate therefore closed each externally fused tile
but changed the torus contraction. Its observed errors were not an
impossibility proof for all existing node-local operations, and the displayed
even-row representative is not by itself universal.

After all four placement corrections above, the eight-leg local comparison
map also simplifies. Relative to the bra-first order

```text
(bL,kL,bR,kR,bU,kU,bD,kD),
```

the old `C` plus the four placement phases reduces, using the compatibility
constraints, to

```text
C_native = bL+kL+kR+bU.
```

Thus a local diagnostic against `reduced_tensor` can use only
`add_parity_sign` on ordered axes `(1,2,4,5)` before the existing external
fusion pipeline. This comparison map is a test/gauge map; it must not be
inserted into every periodic bulk tile.

## Exhaustive periodic solve

The audit enumerated all independent bra/ket edge parities on a `2 x 2`
source torus:

```text
2^16 raw edge assignments
8192 assignments satisfying all source-tile compatibility constraints
3968 assignments with a nontrivial raw-to-reduced phase
```

For each compatible assignment, the exact native `contract`, `trace`,
permutation, and seam-twist sign rules were evaluated for the `4 x 4`
nested and `2 x 2` reduced contraction trees.

The translationally uniform post-node linear/quadratic feature matrix has
rank 9 on this even-row torus. Its minimal solution is

```text
X: q1*q3  (equivalently q2*q3 on X support)
Y: q2*q3.
```

This is only an even-source-row representative, not a universal solution.
The native row-contraction recurrence gives, for `R` source rows,

```text
Delta_XY = (R mod 2) * S,
S = sum_cells (kU+bU).
```

Thus for odd source-row counts it leaves

```text
S = sum_cells (kU+bU).
```

For even source-row counts, the alternating sum of the tile compatibility
constraints proves `S=0`; this is why the `2 x 2` oracle hid the missing K/B
twists. For odd source-row counts the K/B placement corrections contribute
the same `S` and cancel it. Hence the four-term correction is valid for
arbitrary positive source rows and columns.

An exact symbolic recurrence of the native row contraction was evaluated
for every source shape from `1 x 1` through `3 x 3`. The number of residual
GF(2) monomials was:

| source shape | no correction | X/Y only | universal K/B/X/Y |
|---|---:|---:|---:|
| `1 x 1` | 4 | 2 | 0 |
| `1 x 2` | 10 | 4 | 0 |
| `1 x 3` | 16 | 6 | 0 |
| `2 x 1` | 6 | 0 | 0 |
| `2 x 2` | 22 | 0 | 0 |
| `2 x 3` | 40 | 0 | 0 |
| `3 x 1` | 12 | 2 | 0 |
| `3 x 2` | 46 | 4 | 0 |
| `3 x 3` | 78 | 6 | 0 |

Every entry was checked under all four spin structures. The phase difference
is spin-independent: anti-periodic seam contributions are linear in seam
parity and occur equally in the reduced and corrected nested contraction.
The exact checker used for this audit is retained as
`.superpowers/sdd/check-universal-sign.py`.

## Native numerical oracle

The same deterministic nonuniform `2 x 2` PEPS and the same native
row-by-row contraction used by the Task 3 periodic oracle were rerun on the
required SSH server. On two source rows the universal K/B contribution is
sectorwise trivial by the compatibility identity, so this also numerically
verifies the universal corrected `4 x 4` checkerboard versus the ordinary
`2 x 2` reduced network:

| `(twist_x, twist_y)` | relative error |
|---|---:|
| `(false,false)` | `1.4875e-16` |
| `(true,false)` | `8.5688e-16` |
| `(false,true)` | `1.5565e-16` |
| `(true,true)` | `4.4333e-16` |

Server result:

```text
exit_code: 0
peak_rss_kb: 1114144
killed_for_memory: 0
duration_seconds: 70
```

Remote workspace:

```text
/home/jkkong/work/2026/0731/nested-local-sign-solver-019fb340
```

Local log:

```text
D:\C 盘备份\Back up\Work_Save\coding\codex_server_logs\2026\0731\nested-local-sign-solver_019fb340.md
```

## Implementation boundary

The production change can remain narrowly scoped:

1. preserve the current raw K/B/X/Y categorical construction;
2. twist K output axis 3 (`kU`) with `add_parity_sign`;
3. twist the conjugated source-bra axis 4 (`bU`) before B's `(P,U)`
   fusion; do **not** twist final B axis 3, whose parity is `p+bU`;
4. add the same existing `add_perm_sign(..., (1,3,2,4))` placement
   correction to X and Y;
5. update the local factorization oracle to use
   `C_native=bL+kL+kR+bU`, i.e. ordered axes `(1,2,4,5)`;
6. add `1 x 1`, `2 x 2`, and `3 x 2` four-spin periodic regressions so
   both odd/even source-row cases remain covered;
7. retain anisotropic dimensions in X/Y link tests so horizontal and
   vertical routes cannot be swapped unnoticed.

No MPO or auxiliary correction structure is required by the proven native
sign convention.
