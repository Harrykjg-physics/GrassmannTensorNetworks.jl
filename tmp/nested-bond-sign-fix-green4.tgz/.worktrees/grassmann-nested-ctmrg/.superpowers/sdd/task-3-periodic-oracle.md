# Task 3 Native Periodic-Composition Oracle

Status: **BLOCKED**

The Task 2 eight-leg comparison morphism and its inverse are exact locally,
but the comparison morphism does **not** cancel when identical tiles are sewn
with the repository's ordinary native pairwise periodic contractions.
Therefore the current Task 2 primitives cannot simultaneously satisfy:

1. the corrected local equality with `reduced_tensor(A)`, and
2. an unmodified `4 x 4` K/Y/X/B checkerboard whose native periodic scalar
   equals the ordinary `2 x 2` reduced-layer scalar.

No tracked production or test file was changed by this oracle. In
particular, this result must not be used to tune another K/Y/X/B sign.

## Sources and conventions checked

- `.superpowers/sdd/task-2-sector-oracle.md`
- Task 3 in
  `docs/superpowers/plans/2026-07-30-grassmann-nested-ctmrg.md`
- Native `src/contract.jl`, `src/fusion.jl`, `src/fermionsign.jl`,
  `auxiliary/reduced_tensors.jl`, and `auxiliary/ansatz.jl`
- Reference `PEPSKit_nesting/test/exact_algebra.jl`
- Reference `PEPSKit_nesting/src/network.jl`
- PDF `0730_Nested fTN/main.pdf`, especially Sections 2.3, 4.2, 8.3, 9,
  and 14.1 and the rendered factorization diagram on page 18

The geographic native rank-four order is

```text
(L,R,U,D), arrows (:out,:in,:in,:out).
```

The reference order is `[W,S;N,E]`. Consequently:

| Spin cycle | Reference twist | Native explicit twist | Native `trace` form |
|---|---|---|---|
| horizontal | last-column axis 4 (`E`) | last-column axis 2 (`R`) | `pbc=false` on every horizontal closing pair |
| vertical | last-row axis 2 (`S`) | last-row axis 4 (`D`) | `pbc=false` on every vertical closing pair |

This rule applies both to the `2 x 2` reduced matrix and all four rows/columns
of the `4 x 4` nested checkerboard. A fused seam twist has exponent `b+k`,
because native fused parity is the sum of the two constituent parities.

## Exact Task 2 map and inverse

Let `Traw` be the open K/Y/X/B tile in the post-contraction axis order, and
let

```text
P = (5,1,7,3,4,2,8,6)
```

put its open legs in native bra-first order

```text
(bL,kL,bR,kR,bU,kU,bD,kD).
```

The comparison is

```text
M = F * C * P,
```

where `F` is exactly the left/right/up/down fusion pipeline used by native
`reduced_tensor`, and

```julia
function C(ordered)
    corrected = add_perm_sign(
        ordered, (2,3,5,4,6,7,1,8); sign_function=global_sign
    )
    for axis in (2,4,6)
        corrected = add_parity_sign(
            corrected, axis; sign_function=global_sign
        )
    end
    return corrected
end
```

The exponent of `C` on compatible sectors is

```text
C_i =
    kL + kR + kU
  + bL*kL + bL*bR + bL*kR + bL*bU + bL*kU + bL*bD
  + kR*bU                  (mod 2).
```

`C` is its own inverse because it changes no axis order and every component
is a diagonal sign. The full `M^-1` is executable without a dense array:

```julia
function comparison_inverse(reduced, templates)
    # Undo D, U, R, L fusions in reverse order.
    down_input = split_like(reduced, 4, templates.down_input)
    up = add_parity_sign(down_input, 4; sign_function=global_sign)

    up_input = split_like(up, 3, templates.up_input)
    right = add_perm_sign(
        up_input, (1,2,4,3,5,6); sign_function=global_sign
    )

    right_input = split_like(right, 2, templates.right_input)
    left = add_perm_sign(
        right_input, (1,3,2,4,5,6,7); sign_function=global_sign
    )

    left_input = split_like(left, 1, templates.left_input)
    corrected = add_parity_sign(left_input, 1; sign_function=global_sign)

    # C^-1 = C: three twists and the same no-move braid sign.
    ordered = corrected
    for axis in (2,4,6)
        ordered = add_parity_sign(
            ordered, axis; sign_function=global_sign
        )
    end
    ordered = add_perm_sign(
        ordered, (2,3,5,4,6,7,1,8); sign_function=global_sign
    )

    return permutedims(
        ordered, Tuple(invperm(collect(P))); sign_function=global_sign
    )
end
```

Here `split_like(t, axis, template)` means

```julia
split(t, axis, size(template), even(template), index_type(template))
```

The inverse must use the exact pre-fusion metadata. It is not a raw reshape.

## Executable scalar comparison

The server oracle used a nonuniform deterministic `2 x 2` PEPS with
`Dphys=Dvir=2`. It performed:

1. native assembly of the `4 x 4` K/Y/X/B nodes, with
   `X(horizontal=B.W, vertical=K.S)` and
   `Y(horizontal=east K.W, vertical=north B.S)`;
2. Task 2's internal tile contraction;
3. explicit `M` on each open eight-leg tile, producing a `2 x 2` matrix of
   rank-four mapped tiles;
4. explicit `M^-1` on each mapped tile and comparison with the original open
   tile;
5. native row-by-row periodic contraction of the reduced, mapped, and raw
   checkerboard networks under all four spin structures.

The row contraction keeps

```text
(left, all up legs, all down legs, right)
```

until the horizontal `trace`, then keeps

```text
(all top up legs, all current bottom down legs)
```

until the vertical `trace`. Every reordering and contraction uses
`sign_function=global_sign`.

Results:

```text
LOCAL_MAX   0.0
INVERSE_MAX 0.0

(twist_x,twist_y)  mapped relative error  raw nested relative error
(false,false)      0.0                    1.1597711895218507e-1
(true, false)      0.0                    5.6045063699401200e-1
(false,true)       0.0                    6.1879004464445390e-2
(true, true)       0.0                    6.4563201018176760e-1
```

Thus explicit `M` gives the exact reduced scalar, and explicit `M^-1 M`
recovers every open tile bit-for-bit. The ordinary raw checkerboard is not
the same periodic morphism.

As a wiring/control experiment, every PEPS index was then made purely even.
The raw `4 x 4` and reduced `2 x 2` scalars agreed to
`1.4116435137667836e-16` for all four spin choices. This excludes a
geographic-link, row/column, or seam-axis error in the scalar contraction.

## Analytic non-cancellation proof

Identify neighbouring open pairs in the ordinary way:

```text
(bR_i,kR_i) = (bL_right,kL_right)
(bD_i,kD_i) = (bU_below,kU_below).
```

Exhausting all 16 independent bra/ket edge parities of a `2 x 2` torus gives
8192 assignments satisfying every tile's physical compatibility condition.
For 3968 of them,

```text
sum_i C_i = 1  (mod 2).
```

A minimal explicit counterexample is:

- every horizontal bond is even in bra and ket;
- every vertical bond is even except one periodic vertical bond;
- on that one bond, both bra and ket are odd.

All four tiles remain locally compatible. The tile above that seam has

```text
(bU,kU)=(1,1), all other local legs even,
C_above = kU = 1,
```

while the other three tile contributions sum to zero. The fused boundary
twist on the same seam contributes

```text
bU+kU = 1+1 = 0  (mod 2),
```

so none of the four spin structures removes the mismatch.

This is a direct proof that `C` is not a product of one-leg gauges and that
identical tile-local copies do not cancel on ordinary bonds.

## What explicit composition does and does not prove

Inserting `M^-1 M` at a single open tile is the identity and was verified
bit-for-bit. Grouping `M` with every raw tile produces `reduced_tensor`
exactly, so sewing the mapped outputs gives the reduced periodic scalar.

However, after regrouping, the remaining `M^-1` factors belong to the
inter-tile connector. Because `C` couples parities from several geographic
legs, those inverse factors cannot be replaced by four ordinary fused bond
identities. Doing so drops the 3968 nontrivial global phases above. Therefore
the mapped scalar is a valid transformed-connector oracle, not evidence that
the unmodified checkerboard network has the same scalar.

## Server verification

Remote workspace:

```text
/home/jkkong/work/2026/0731/nested-task3-periodic-oracle-019fb340
```

Final guarded command:

```bash
cd /home/jkkong/work/2026/0731/nested-task3-periodic-oracle-019fb340
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/oracle-v6.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   export NESTED_PERIODIC_ORACLE_ROOT=/home/jkkong/work/2026/0731/nested-task3-periodic-oracle-019fb340;
   julia_grassmann exp/oracle.jl'
```

```text
exit_code: 0
peak_rss_kb: 1032760
killed_for_memory: 0
duration_seconds: 55
```

Local server log:

```text
D:\C 盘备份\Back up\Work_Save\coding\codex_server_logs\2026\0731\nested-task3-periodic-oracle-019fb340.md
```

## Required next decision

Do not accept the Task 3 exact-periodic criterion with the current
non-composable `C`. A correct continuation requires a new, genuinely
composable local derivation whose external comparison factors by geographic
bonds (or a formally supported transformed connector/network type). The
latter would be a material architecture change and cannot be silently hidden
inside `NestedNetwork.network`, because existing GCTMRG contracts ordinary
rank-four bonds.

Safe Task 3 work such as layout filling, link validation, and thin GCTMRG
adapters can still be implemented and tested, but it does not resolve this
exactness blocker.

## Ranked feasible alternatives

### 1. A finite Z2 correction MPO / auxiliary-node network

**Best chance of preserving the user's Approach A, and the smallest viable
change that still keeps an explicit nested K/Y/X/B bulk.**

The diagonal phase `C` is a quadratic Boolean phase. In the bra-first
sequence

```text
q = (bL,kL,bR,kR,bU,kU,bD,kD),
```

its interaction graph is a star from `bL` to
`kL,bR,kR,bU,kU,bD`, plus the edge `kR-bU`, with local fields on
`kL,kR,kU`. A sequential finite-state MPO can evaluate it exactly:

- retain `bL` from the first through the seventh variable;
- additionally retain `kR` between the fourth and fifth variables;
- emit each `(-1)^(q_i*q_j)` when the later endpoint is visited;
- emit the three linear twists locally.

At the largest cut the state is only `(bL,kR)`, so the abstract exact MPO has
bond dimension at most `2^2 = 4`. It uses only Z2 parity-controlled diagonal
tensors and no dense conversion.

The MPO must be an actual part of the nested network, not a comparison-only
test object. Its local tensors could be represented as extra correction nodes
or absorbed into K/Y/X/B while enlarging selected auxiliary bonds. The latter
is more compatible with the fixed checkerboard shape, but still requires:

1. a planar routing proof for the eight boundary encounters;
2. a new link-dimension and arrow audit;
3. the four-spin periodic oracle;
4. CTMRG memory/cost measurements; and
5. AD rules for the changed assembly (the correction data remain static).

The `D <= 4` statement is an algebraic MPO bound. It is not yet a proof that
the same bound survives the preferred square-lattice embedding without an
additional crossing or auxiliary node.

### 2. Group every source tile into the corrected rank-four tensor

**Smallest exact implementation, but it does not fulfill Approach A's nested
network objective.**

Compute

```text
R_i = M(Traw_i) = reduced_tensor(A_i)
```

and pass the resulting `m x n` matrix of rank-four tensors to CTMRG. This is
already exact under all four spin structures, and the existing oracle gives
an explicit native inverse for debugging and AD checks.

It collapses the doubled `2m x 2n` checkerboard back to one rank-four bulk
tensor per source site. Therefore it loses the intended nested contraction
structure and likely its memory/AD motivation. It is useful as an oracle or
temporary diagnostic backend, not as acceptance of the user's requested
Grassmann nested implementation.

### 3. Change the native pair-fusion gauge or data layout

**Not viable as a local pair-gauge fix; a global version is the largest and
riskiest change.**

An independent geographic pair gauge would have the form

```text
gL(bL,kL) + gR(bR,kR) + gU(bU,kU) + gD(bD,kD).
```

It cannot reproduce terms such as `bL*bR`, `bL*bU`, or `kR*bU`.
Equivalently, the mixed Boolean derivatives of `C` across different
directions are nonzero. Thus no choice of four independent native pair
fusion bases can make `M` leg-local.

A repository-wide Jordan-Wigner-like storage order or changed
`fuse`/`contract` convention could carry nonlocal strings, but that would
alter established native semantics and many unrelated algorithms. It
violates the user's small-change constraint and would demand a full
repository revalidation. If localized to this algorithm, it is effectively
alternative 1 under another name.

### Recommendation

If the explicit nested checkerboard is non-negotiable, pursue alternative 1
as a separately approved redesign and first prove the correction MPO on the
same `2 x 2 / 4 x 4` four-spin oracle. Alternative 2 is the lowest-code-risk
fallback but should be labelled a grouped/reduced backend, not the requested
nested implementation. Do not pursue alternative 3 as a pair-gauge patch.
