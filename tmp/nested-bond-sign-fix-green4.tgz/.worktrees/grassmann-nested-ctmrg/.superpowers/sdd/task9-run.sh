#!/usr/bin/env bash
set -euo pipefail

task_root="$1"
chi="$2"
driver="$task_root/exp/examples/Spinless_Fermion_2D_Square_AD_nested/Spinless_Fermion_2D_Square_AD_nested.jl"

cd "$task_root/exp"
exec ../run_with_memory_guard.sh \
    --limit-gb 20 \
    --log ../log/accept.log \
    -- bash -ic "export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin; export JULIA_PKG_OFFLINE=true; export NESTED_CHI=$chi; export NESTED_SEED=1234; export NESTED_VERBOSITY=0; julia_grassmann '$driver'"
