#!/usr/bin/env bash
set -euo pipefail
task="$1"
chi="$2"
mkdir -p "$task/log" "$task/results"
cd "$task"
./run_with_memory_guard.sh --limit-gb 20 --log "$task/log/reduced.log" -- \
  bash -ic "export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin; export JULIA_PKG_OFFLINE=true; julia_grassmann '$task/repo/.superpowers/sdd/task9-diagnose-reduced.jl' '$chi'"
