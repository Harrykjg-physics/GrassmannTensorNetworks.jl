### Task 2: Replace Two-Site CTMRG Tests with Exact Bond Closures

**Files:**

- Modify: `algorithms/Nested_CTMRG/measurements.jl`
- Modify: `test/nested_measurements.jl`

**Interfaces:**

- Consumes: `_operator_schmidt`, `nested_y_operator`,
  `reduced_tensor_hbond`, `reduced_tensor_vbond`, and
  `nested_test_torus_scalar`.
- Produces and tests:
  `_check_nested_bond_operator(peps, operator, source, neighbor)`.
- Preserves: the parent Task 5 environment-based strip contractions and
  public horizontal/vertical measurement methods.

- [ ] **Step 1: Add exact reduced-bond closure helpers**

Append:

```julia
function close_reduced_hbond(
    tensor::Grassmann;
    twist_x::Bool,
    twist_y::Bool,
)
    closed = trace(
        tensor,
        ((1, 3, 4), (2, 5, 6));
        pbc=(!twist_x, !twist_y, !twist_y),
        sign_function=GrassmannTensorNetworks.global_sign,
    )
    return scalar(closed)
end

function close_reduced_vbond(
    tensor::Grassmann;
    twist_x::Bool,
    twist_y::Bool,
)
    closed = trace(
        tensor,
        ((1, 2, 5), (3, 4, 6));
        pbc=(!twist_x, !twist_x, !twist_y),
        sign_function=GrassmannTensorNetworks.global_sign,
    )
    return scalar(closed)
end

function exact_nested_bond_numerator(
    nested::NestedNetwork,
    peps::Square_GPEPS,
    operator::Grassmann,
    source::CartesianIndex{2},
    orientation::Symbol;
    twist_x::Bool,
    twist_y::Bool,
)
    neighbor = orientation === :horizontal ?
        CartesianIndex(
            source[1], Nmod(source[2] + 1, size(peps)[2])
        ) :
        CartesianIndex(
            Nmod(source[1] + 1, size(peps)[1]), source[2]
        )
    total = zero(nested_test_torus_scalar(
        nested.network; twist_x, twist_y
    ))
    for (left_operator, right_operator) in
        GrassmannTensorNetworks._operator_schmidt(operator)
        impurity = copy(nested.network)
        impurity[nested.layout.y_sites[source]] =
            nested_y_operator(
                nested, peps, source, left_operator
            )
        impurity[nested.layout.y_sites[neighbor]] =
            nested_y_operator(
                nested, peps, neighbor, right_operator
            )
        total += nested_test_torus_scalar(
            impurity; twist_x, twist_y
        )
    end
    return total
end
```

- [ ] **Step 2: Write exact operator reconstruction and bond comparisons**

Append:

```julia
@testset "Exact nested nearest-neighbor measurements" begin
    identity2 = two_site_identity()
    hamiltonian =
        nn_bond(SpinlessFermionModel(1.0, 1.0, 3.0))

    terms = GrassmannTensorNetworks._operator_schmidt(hamiltonian)
    reconstructed = sum(
        contract(
            left, right;
            sign_function=GrassmannTensorNetworks.global_sign,
        ) for (left, right) in terms
    )
    ordered = permutedims(
        reconstructed, (1, 3, 2, 4);
        sign_function=GrassmannTensorNetworks.global_sign,
    )
    @test ordered ≈ hamiltonian rtol=1e-12 atol=1e-12

    Random.seed!(0x48424f4e44)
    hpeps = Square_GPEPS(2, 1, 2, 1, 2, Float64, false)
    hnested = nested_network(hpeps)
    hsource = CartesianIndex(1, 1)
    hdenominator_reference = reduced_tensor_hbond(
        hpeps.A[1, 1], hpeps.A[1, 2], identity2
    )
    hnumerator_reference = reduced_tensor_hbond(
        hpeps.A[1, 1], hpeps.A[1, 2], hamiltonian
    )

    Random.seed!(0x56424f4e44)
    vpeps = Square_GPEPS(2, 1, 2, 2, 1, Float64, false)
    vnested = nested_network(vpeps)
    vsource = CartesianIndex(1, 1)
    vdenominator_reference = reduced_tensor_vbond(
        vpeps.A[1, 1], vpeps.A[2, 1], identity2
    )
    vnumerator_reference = reduced_tensor_vbond(
        vpeps.A[1, 1], vpeps.A[2, 1], hamiltonian
    )

    @test GrassmannTensorNetworks._check_nested_bond_operator(
        hpeps, hamiltonian,
        CartesianIndex(1, 1), CartesianIndex(1, 2),
    ) === nothing
    wrong_size = Grassmann(
        (3, 2, 3, 2), (1, 1, 1, 1),
        (:out, :out, :in, :in), Float64;
        init=:zeros,
    )
    wrong_even = Grassmann(
        (2, 2, 2, 2), (2, 1, 2, 1),
        (:out, :out, :in, :in), Float64;
        init=:zeros,
    )
    wrong_arrows = Grassmann(
        (2, 2, 2, 2), (1, 1, 1, 1),
        (:in, :out, :out, :in), Float64;
        init=:zeros,
    )
    odd_operator = Grassmann(
        (2, 2, 2, 2), (1, 1, 1, 1),
        (:out, :out, :in, :in), Float64;
        init=:zeros, parity=:odd,
    )
    @test_throws ArgumentError
        GrassmannTensorNetworks._check_nested_bond_operator(
            hpeps, hamiltonian,
            CartesianIndex(2, 1), CartesianIndex(1, 2),
        )
    @test_throws DimensionMismatch
        GrassmannTensorNetworks._check_nested_bond_operator(
            hpeps, wrong_size,
            CartesianIndex(1, 1), CartesianIndex(1, 2),
        )
    @test_throws DimensionMismatch
        GrassmannTensorNetworks._check_nested_bond_operator(
            hpeps, wrong_even,
            CartesianIndex(1, 1), CartesianIndex(1, 2),
        )
    @test_throws ArgumentError
        GrassmannTensorNetworks._check_nested_bond_operator(
            hpeps, wrong_arrows,
            CartesianIndex(1, 1), CartesianIndex(1, 2),
        )
    @test_throws ArgumentError
        GrassmannTensorNetworks._check_nested_bond_operator(
            hpeps, odd_operator,
            CartesianIndex(1, 1), CartesianIndex(1, 2),
        )

    bond_numerators = Float64[]
    for (twist_x, twist_y) in MEASUREMENT_SPIN_STRUCTURES
        hdenominator = nested_test_torus_scalar(
            hnested.network; twist_x, twist_y
        )
        hnumerator = exact_nested_bond_numerator(
            hnested, hpeps, hamiltonian, hsource, :horizontal;
            twist_x, twist_y
        )
        hdenominator_reduced = close_reduced_hbond(
            hdenominator_reference; twist_x, twist_y
        )
        hnumerator_reduced = close_reduced_hbond(
            hnumerator_reference; twist_x, twist_y
        )
        @test hdenominator ≈ hdenominator_reduced
            rtol=5e-12 atol=1e-12
        @test hnumerator ≈ hnumerator_reduced
            rtol=5e-12 atol=1e-12
        @test hnumerator / hdenominator ≈
            hnumerator_reduced / hdenominator_reduced
            rtol=5e-12 atol=1e-12

        vdenominator = nested_test_torus_scalar(
            vnested.network; twist_x, twist_y
        )
        vnumerator = exact_nested_bond_numerator(
            vnested, vpeps, hamiltonian, vsource, :vertical;
            twist_x, twist_y
        )
        vdenominator_reduced = close_reduced_vbond(
            vdenominator_reference; twist_x, twist_y
        )
        vnumerator_reduced = close_reduced_vbond(
            vnumerator_reference; twist_x, twist_y
        )
        @test vdenominator ≈ vdenominator_reduced
            rtol=5e-12 atol=1e-12
        @test vnumerator ≈ vnumerator_reduced
            rtol=5e-12 atol=1e-12
        @test vnumerator / vdenominator ≈
            vnumerator_reduced / vdenominator_reduced
            rtol=5e-12 atol=1e-12

        push!(bond_numerators, abs(hnumerator), abs(vnumerator))
    end
    @test maximum(bond_numerators) > 1e-12
end
```

- [ ] **Step 3: Run the focused test and verify RED**

Run in
`/home/jkkong/work/2026/0731/nested-exact-bond-019fb340`:

```bash
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/red-exact-bond.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann focused_runtests.jl'
```

Expected: `_check_nested_bond_operator`, `_operator_schmidt`,
`compute_nested_exp_hbond`, or `compute_nested_exp_vbond` is missing. The
test output contains no CTMRG iteration.

- [ ] **Step 4: Implement parent Task 5 production methods**

Implement the exact `_operator_schmidt`, environment-based strip helpers,
three-node patch helpers, scalar public methods, and unit-cell overloads from
parent-plan Task 5. Do not add a second exact-contraction production API;
the exact closure helpers remain test-only.

- [ ] **Step 5: Run focused and full tests and verify GREEN**

Use the guarded focused command with `log/green-exact-bond.log`, followed by
the full offline command from Task 1 with `log/full-exact-bond.log`.

Expected: operator reconstruction, exact horizontal/vertical comparisons,
and the full suite pass with exit code `0`; peak RSS stays below 20 GB. Run
the static `rg` check from Task 1 and verify it still has no matches.

- [ ] **Step 6: Commit**

```bash
git add algorithms/Nested_CTMRG/measurements.jl \
        test/nested_measurements.jl
git commit -m "feat: measure nested nearest-neighbor operators"
```
