using Pkg

const TASK_ROOT = get(ENV, "NESTED_PERIODIC_ORACLE_ROOT", normpath(joinpath(@__DIR__, "..")))
Pkg.activate(joinpath(TASK_ROOT, "harness"))

using GrassmannTensorNetworks

@eval GrassmannTensorNetworks global global_sign = auto_sign

import GrassmannTensorNetworks:
    _graded_pair_sign,
    _nested_ket,
    _nested_bra,
    _nested_x,
    _placed_nested_x,
    _nested_y,
    _physical_identity,
    _nested_reduced_basis

const SIGN = GrassmannTensorNetworks.global_sign
const TILE_ORDER = (5, 1, 7, 3, 4, 2, 8, 6)
const BASIS_PERM = (2, 3, 5, 4, 6, 7, 1, 8)

function assemble_nodes(peps)
    rows, cols = size(peps)
    ket = [_nested_ket(peps.A[r, c]) for r in 1:rows, c in 1:cols]
    bra = [_nested_bra(peps.A[r, c]) for r in 1:rows, c in 1:cols]
    xraw = [
        _nested_x(
            size(bra[r, c])[1],
            even(bra[r, c])[1],
            size(ket[r, c])[4],
            even(ket[r, c])[4],
            eltype(peps),
        ) for r in 1:rows, c in 1:cols
    ]
    nodes = Matrix{Grassmann{eltype(peps), 4}}(undef, 2rows, 2cols)
    for r in 1:rows, c in 1:cols
        nodes[2r - 1, 2c - 1] = ket[r, c]
        nodes[2r, 2c] = bra[r, c]
        nodes[2r, 2c - 1] = _placed_nested_x(xraw[r, c])
        north_bra = bra[Nmod(r - 1, rows), c]
        east_ket = ket[r, Nmod(c + 1, cols)]
        nodes[2r - 1, 2c] = _nested_y(
            _physical_identity(peps.A[r, c]),
            size(east_ket)[1],
            even(east_ket)[1],
            size(north_bra)[4],
            even(north_bra)[4],
        )
    end
    return nodes, ket, bra, xraw
end

function assemble_distributed_nodes(peps)
    rows, cols = size(peps)
    ket = Matrix{Grassmann{eltype(peps), 4}}(undef, rows, cols)
    bra = [_nested_bra(peps.A[r, c]) for r in 1:rows, c in 1:cols]
    for r in 1:rows, c in 1:cols
        ket_input = peps.A[r, c]
        for axis in (2, 3, 4)
            ket_input = add_parity_sign(
                ket_input, axis; sign_function=SIGN
            )
        end
        ket[r, c] = _nested_ket(ket_input)
    end
    nodes = Matrix{Grassmann{eltype(peps), 4}}(undef, 2rows, 2cols)
    for r in 1:rows, c in 1:cols
        xraw = _nested_x(
            size(bra[r, c])[1],
            even(bra[r, c])[1],
            size(ket[r, c])[4],
            even(ket[r, c])[4],
            eltype(peps),
        )
        x = _graded_pair_sign(xraw, 1, 3)
        north_bra = bra[Nmod(r - 1, rows), c]
        east_ket = ket[r, Nmod(c + 1, cols)]
        yraw = _nested_y(
            _physical_identity(peps.A[r, c]),
            size(east_ket)[1],
            even(east_ket)[1],
            size(north_bra)[4],
            even(north_bra)[4],
        )
        y = _graded_pair_sign(yraw, 2, 3)
        nodes[2r - 1, 2c - 1] = ket[r, c]
        nodes[2r - 1, 2c] = y
        nodes[2r, 2c - 1] = x
        nodes[2r, 2c] = bra[r, c]
    end
    return nodes, ket, bra
end

function assemble_native_sign_nodes(peps)
    rows, cols = size(peps)
    ket = [_nested_ket(peps.A[r, c]) for r in 1:rows, c in 1:cols]
    bra = [_nested_bra(peps.A[r, c]) for r in 1:rows, c in 1:cols]
    nodes = Matrix{Grassmann{eltype(peps), 4}}(undef, 2rows, 2cols)
    for r in 1:rows, c in 1:cols
        xraw = _nested_x(
            size(bra[r, c])[1],
            even(bra[r, c])[1],
            size(ket[r, c])[4],
            even(ket[r, c])[4],
            eltype(peps),
        )
        xplaced = _placed_nested_x(xraw)
        # Native contract(...; auto_sign) already supplies the route crossing.
        # The no-move inversion sign removes the duplicate explicit braid.
        x = _graded_pair_sign(xplaced, 1, 3)
        north_bra = bra[Nmod(r - 1, rows), c]
        east_ket = ket[r, Nmod(c + 1, cols)]
        yraw = _nested_y(
            _physical_identity(peps.A[r, c]),
            size(east_ket)[1],
            even(east_ket)[1],
            size(north_bra)[4],
            even(north_bra)[4],
        )
        y = _graded_pair_sign(yraw, 2, 3)
        nodes[2r - 1, 2c - 1] = ket[r, c]
        nodes[2r - 1, 2c] = y
        nodes[2r, 2c - 1] = x
        nodes[2r, 2c] = bra[r, c]
    end
    return nodes
end

function open_tile(K, Y, Xplaced, B)
    ky = contract(K, Y, (2, 1); sign_function=SIGN)
    kx = contract(ky, Xplaced, (3, 3); sign_function=SIGN)
    return contract(kx, B, ((5, 7), (3, 1)); sign_function=SIGN)
end

function comparison_forward(raw)
    ordered = permutedims(raw, TILE_ORDER; sign_function=SIGN)
    corrected = _nested_reduced_basis(ordered)
    left_input = add_parity_sign(corrected, 1; sign_function=SIGN)
    left = fuse(left_input, (1, 2); index_type_fused=:out)
    right_input = add_perm_sign(
        left, (1, 3, 2, 4, 5, 6, 7); sign_function=SIGN
    )
    right = fuse(right_input, (2, 3); index_type_fused=:in)
    up_input = add_perm_sign(
        right, (1, 2, 4, 3, 5, 6); sign_function=SIGN
    )
    up = fuse(up_input, (3, 4); index_type_fused=:in)
    down_input = add_parity_sign(up, 4; sign_function=SIGN)
    reduced = fuse(down_input, (4, 5); index_type_fused=:out)
    templates = (ordered, corrected, left_input, left, right_input, right,
                 up_input, up, down_input)
    return reduced, templates
end

split_like(t, axis, template) = split(
    t, axis, size(template), even(template), index_type(template)
)

function comparison_inverse(reduced, templates)
    ordered, corrected, left_input, left, right_input, right,
        up_input, up, down_input = templates

    recovered_down_input = split_like(reduced, 4, down_input)
    recovered_up = add_parity_sign(
        recovered_down_input, 4; sign_function=SIGN
    )
    recovered_up_input = split_like(recovered_up, 3, up_input)
    recovered_right = add_perm_sign(
        recovered_up_input, (1, 2, 4, 3, 5, 6); sign_function=SIGN
    )
    recovered_right_input = split_like(recovered_right, 2, right_input)
    recovered_left = add_perm_sign(
        recovered_right_input,
        (1, 3, 2, 4, 5, 6, 7);
        sign_function=SIGN,
    )
    recovered_left_input = split_like(recovered_left, 1, left_input)
    recovered_corrected = add_parity_sign(
        recovered_left_input, 1; sign_function=SIGN
    )
    recovered_ordered = recovered_corrected
    for index in (2, 4, 6)
        recovered_ordered = add_parity_sign(
            recovered_ordered, index; sign_function=SIGN
        )
    end
    recovered_ordered = add_perm_sign(
        recovered_ordered, BASIS_PERM; sign_function=SIGN
    )
    return permutedims(
        recovered_ordered, Tuple(invperm(collect(TILE_ORDER)));
        sign_function=SIGN,
    )
end

function close_row(row; twist_x=false)
    cols = length(row)
    current = permutedims(row[1], (1, 3, 4, 2); sign_function=SIGN)
    for c in 2:cols
        j = c - 1
        rank = 2j + 2
        perm = (
            1,
            (2:(j + 1))...,
            2j + 3,
            ((j + 2):(2j + 1))...,
            2j + 4,
            2j + 2,
        )
        current = contract(
            current,
            row[c],
            (rank, 1);
            perm=perm,
            sign_function=SIGN,
        )
    end
    return trace(
        current,
        (1, 2cols + 2);
        pbc=!twist_x,
        sign_function=SIGN,
    )
end

function torus_scalar(tensors; twist_x=false, twist_y=false)
    rows, cols = size(tensors)
    row_tensors = [
        close_row(collect(tensors[r, :]); twist_x=twist_x) for r in 1:rows
    ]
    current = row_tensors[1]
    for r in 2:rows
        current = contract(
            current,
            row_tensors[r],
            ((ntuple(i -> cols + i, cols)), ntuple(identity, cols));
            sign_function=SIGN,
        )
    end
    closed = trace(
        current,
        (ntuple(identity, cols), ntuple(i -> cols + i, cols));
        pbc=ntuple(_ -> !twist_y, cols),
        sign_function=SIGN,
    )
    return scalar(closed)
end

function close_paired_row(row; twist_x=false)
    cols = length(row)
    current = permutedims(
        row[1], (1, 2, 5, 6, 7, 8, 3, 4); sign_function=SIGN
    )
    for c in 2:cols
        j = c - 1
        rank = 4j + 4
        # Invariant:
        # (Lpair, U-pairs[1:j], D-pairs[1:j], Rpair).
        default_rank = rank + 4
        u_old = collect(3:(2j + 2))
        d_old = collect((2j + 3):(4j + 2))
        r_new = (rank - 1, rank)
        u_new = (rank + 1, rank + 2)
        d_new = (rank + 3, rank + 4)
        perm = Tuple(vcat(
            [1, 2], u_old, collect(u_new), d_old, collect(d_new),
            collect(r_new),
        ))
        @assert length(perm) == default_rank
        current = contract(
            current,
            row[c],
            ((rank - 1, rank), (1, 2));
            perm=perm,
            sign_function=SIGN,
        )
    end
    rank = 4cols + 4
    return trace(
        current,
        ((1, 2), (rank - 1, rank));
        pbc=(!twist_x, !twist_x),
        sign_function=SIGN,
    )
end

function paired_torus_scalar(tensors; twist_x=false, twist_y=false)
    rows, cols = size(tensors)
    row_tensors = [
        close_paired_row(collect(tensors[r, :]); twist_x=twist_x)
        for r in 1:rows
    ]
    current = row_tensors[1]
    width = 2cols
    for r in 2:rows
        current = contract(
            current,
            row_tensors[r],
            (
                ntuple(i -> width + i, width),
                ntuple(identity, width),
            );
            sign_function=SIGN,
        )
    end
    closed = trace(
        current,
        (
            ntuple(identity, width),
            ntuple(i -> width + i, width),
        );
        pbc=ntuple(_ -> !twist_y, width),
        sign_function=SIGN,
    )
    return scalar(closed)
end

function main()
    parameter_count = square_gpeps_parameter_count(2, 1, 2, 2, 2)
    params = [0.17sin(i) + 0.11cos(3i) for i in 1:parameter_count]
    peps = Square_GPEPS(2, 1, 2, 2, 2, params)
    nodes, ket, bra, xraw = assemble_nodes(peps)

    mapped = Matrix{Grassmann{Float64, 4}}(undef, 2, 2)
    inverse_errors = Float64[]
    local_errors = Float64[]
    for r in 1:2, c in 1:2
        raw = open_tile(
            ket[r, c],
            nodes[2r - 1, 2c],
            nodes[2r, 2c - 1],
            bra[r, c],
        )
        mapped[r, c], templates = comparison_forward(raw)
        reconstructed = comparison_inverse(mapped[r, c], templates)
        push!(
            inverse_errors,
            maximum(abs, convert(Array, reconstructed) - convert(Array, raw)),
        )
        direct = reduced_tensor(peps.A[r, c])
        push!(
            local_errors,
            maximum(abs, convert(Array, mapped[r, c]) - convert(Array, direct)),
        )
    end

    reduced = reduced_tensor(peps)
    distributed_nodes, distributed_ket, distributed_bra =
        assemble_distributed_nodes(peps)
    native_sign_nodes = assemble_native_sign_nodes(peps)
    distributed_tiles = Matrix{Grassmann{Float64, 8}}(undef, 2, 2)
    for r in 1:2, c in 1:2
        raw = open_tile(
            distributed_ket[r, c],
            distributed_nodes[2r - 1, 2c],
            distributed_nodes[2r, 2c - 1],
            distributed_bra[r, c],
        )
        distributed_tiles[r, c] = permutedims(
            raw, TILE_ORDER; sign_function=SIGN
        )
    end
    println("LOCAL_MAX ", maximum(local_errors))
    println("INVERSE_MAX ", maximum(inverse_errors))
    for (tx, ty) in ((false, false), (true, false), (false, true), (true, true))
        sr = torus_scalar(reduced; twist_x=tx, twist_y=ty)
        sm = torus_scalar(mapped; twist_x=tx, twist_y=ty)
        sn = torus_scalar(nodes; twist_x=tx, twist_y=ty)
        scale = max(abs(sr), eps(Float64))
        println(
            "SPIN tx=", tx,
            " ty=", ty,
            " reduced=", sr,
            " mapped=", sm,
            " raw_nested=", sn,
            " mapped_rel=", abs(sm - sr) / scale,
            " raw_rel=", abs(sn - sr) / scale,
        )
        sd = torus_scalar(distributed_nodes; twist_x=tx, twist_y=ty)
        sp = paired_torus_scalar(
            distributed_tiles; twist_x=tx, twist_y=ty
        )
        println(
            "DISTRIBUTED tx=", tx,
            " ty=", ty,
            " reduced=", sr,
            " distributed=", sd,
            " rel=", abs(sd - sr) / scale,
            " paired=", sp,
            " node_paired_rel=", abs(sd - sp) / scale,
        )
        sns = torus_scalar(native_sign_nodes; twist_x=tx, twist_y=ty)
        println(
            "NATIVE_SIGN tx=", tx,
            " ty=", ty,
            " reduced=", sr,
            " nested=", sns,
            " rel=", abs(sns - sr) / scale,
        )
    end

    all_even_A = Matrix{Grassmann{Float64, 5}}(undef, 2, 2)
    for r in 1:2, c in 1:2
        tensor = Grassmann(
            (2, 2, 2, 2, 2),
            (2, 2, 2, 2, 2),
            (:out, :out, :in, :in, :out),
            Float64;
            init=:zeros,
        )
        tensor[(0, 0, 0, 0, 0)] .=
            reshape(
                [0.03sin(i + 7r + 11c) for i in 1:32],
                size(tensor[(0, 0, 0, 0, 0)]),
            )
        all_even_A[r, c] = tensor
    end
    even_peps = Square_GPEPS{Float64}(all_even_A, missing, missing)
    even_nodes, _, _, _ = assemble_nodes(even_peps)
    even_reduced = reduced_tensor(even_peps)
    for (tx, ty) in ((false, false), (true, false), (false, true), (true, true))
        sr = torus_scalar(even_reduced; twist_x=tx, twist_y=ty)
        sn = torus_scalar(even_nodes; twist_x=tx, twist_y=ty)
        println(
            "EVEN_CONTROL tx=", tx,
            " ty=", ty,
            " reduced=", sr,
            " raw_nested=", sn,
            " rel=", abs(sn - sr) / max(abs(sr), eps(Float64)),
        )
    end
end

main()
