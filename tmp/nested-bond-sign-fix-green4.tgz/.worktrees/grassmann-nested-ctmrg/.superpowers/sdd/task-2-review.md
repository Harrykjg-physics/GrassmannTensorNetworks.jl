# Task 2 Independent Review

Verdict: **FAIL**

Reviewed range:

```text
6b753a1..b1dcbee
```

This includes plan corrections `2123122` and `79f557a`, plus implementation
commit `b1dcbee`. No tracked file or Git state was changed during review.

## Critical

None.

## Important

### Mixed-multiplicity regression data are invariant under block-local permutations

Files:

- `test/nested_network.jl:96`
- `test/nested_network.jl:100`
- `test/nested_network.jl:102`
- `test/nested_network.jl:160`
- `test/nested_network.jl:174`

`deterministic_nested_tensor` fills every entry of a given parity block with
the same scalar. Consequently the anisotropic mixed-multiplicity closure test
cannot detect a permutation of multiplicity coordinates inside a parity
block, including a wrong reshape/fusion basis order. Such a bug is exactly
the class that the larger `(3,3,4,3,4)` case is meant to cover; the minimal
128-sector case has one-dimensional parity blocks and therefore cannot cover
it either.

The ignored oracle does contain the missing evidence:

```text
larger mixed Float64 seeds 4409/5519:
relative error 1.13e-16 / 8.35e-17

larger mixed ComplexF64 seeds 4409/5519:
relative error 1.71e-16 / 1.25e-16
```

Those runs support the correctness of the current implementation, but they
are not a tracked regression and will not protect later Task 3/measurement/AD
changes.

Action: add a deterministic nonuniform block initializer to
`test/nested_network.jl` (stable unique values per block coordinate, or a
fixed seeded generator) and run the mixed-multiplicity anisotropic closure
for both `Float64` and `ComplexF64`. The values must vary within each parity
block. Keep the existing dimension assertions so horizontal `B.W` and
vertical `K.S` remain distinguishable.

## Minor

### The 128-sector test verifies entries but not its semantic labels independently

Files:

- `test/nested_network.jl:122`
- `test/nested_network.jl:136`
- `test/nested_network.jl:147`

The loop does visit all 128 populated minimal fused entries, and the hardcoded
map is correct for the current native `fuse`: `(0,0),(1,1),(1,0),(0,1)` map
to dense indices `1,2,3,4`. However, comparing `candidate[idx]` with
`target[idx]` at the same hardcoded index does not independently prove that
the index is semantically the claimed `(bra,ket)` pair; any bijective
relabeling would still traverse the same populated entries.

Action: add a small direct fusion-basis fixture or compare selected asymmetric
`ComplexF64` entries with the expected
`conj(A[p,bra...]) * A[p,ket...]` bilinear. This is not a current correctness
failure because inspection of `calculate_sectors` and `fuse` confirms the
map.

## Verified

- `_graded_pair_sign` applies exactly `(-1)^(q_i q_j)` without reordering
  axes.
- `_nested_x` is the raw braid: odd-odd is `-1`, all other diagonal parity
  exchanges are `+1`; no dense production shortcut is used.
- `_placed_nested_x` alone adds the west/axis-1 twist, so raw and placed X
  remain separate.
- K uses the physical/right same-order exchange, graded route permutation,
  and `(P,R)` fusion.
- B uses Grassmann-aware conjugation, physical/up exchange, route
  permutation, `(P,U)` fusion, and parity-twisted bends on axes `(1,2,4)`.
- Y uses a raw horizontal/vertical braid, physical identity closure, and the
  documented west/south fusion order.
- Local closure contracts `K-Y`, then placed X, then B on the corrected axes
  `(5,7) <-> (3,1)`.
- Open legs are reordered bra-first as
  `(bL,kL,bR,kR,bU,kU,bD,kD)`.
- `_nested_reduced_basis` implements the derived native comparison morphism:
  braid `(2,3,5,4,6,7,1,8)` followed by twists `(2,4,6)`.
- The external fusers exactly reproduce `reduced_tensor`: left/down twists,
  right/up permutation signs, then native fusions.
- The 128 minimal compatible sectors are exhaustively visited. The fused
  index mapping agrees with native `calculate_sectors` and `fuse`.
- The anisotropic dimensions distinguish horizontal `B.W` (size 3) from
  vertical `K.S` (size 4) in the local helper; Task 3 still must preserve
  this order in the production assembly caller.
- Server evidence is internally consistent: focused `159/159`, full
  `1106/1106`, both exit 0 under the 20 GB guard. No repeated full run was
  needed for this review.
- `git diff --check 6b753a1..b1dcbee` is clean.

## Task 3 boundary

The eight-leg basis correction is not a product of independent one-leg
gauges. The oracle's naive periodic traces fail, but this is explicitly
isolated as a Task 3 global-composition risk rather than evidence against the
proven local Task 2 identity.

Task 3 must not attach `_nested_reduced_basis` silently to a single network
bond. Its acceptance gate must remain the planned native `2x2` reduced /
`4x4` nested periodic comparison under all four spin structures, with the
comparison morphisms and inverses composed explicitly. A failure there is a
Task 3 blocker and must not be "fixed" by changing the already verified local
K/Y/X/B signs without a new derivation.

---

## Re-review of `cdba085`

Verdict: **PASS**

The original Important and Minor findings are resolved. No new Critical,
Important, or Minor findings were found.

### Important resolution: nonuniform mixed-multiplicity data

Verified in `test/nested_network.jl:96-109` and
`test/nested_network.jl:183-203`:

- every stored coordinate receives a stable value derived from both its
  block number and its Cartesian coordinate number;
- values vary within every non-scalar parity block;
- the anisotropic test explicitly checks that all 218 stored values are
  globally distinct;
- both `Float64` and asymmetric `ComplexF64` fixtures run the full local
  closure comparison;
- the horizontal X size remains `B.W = 3` and the vertical X size remains
  `K.S = 4`.

This fixture will now detect block-local reshape/fusion basis permutations
that the previous block-constant data could hide.

### Minor resolution: independent fused-index semantics

Verified in `test/nested_network.jl:127-150`:

- a rank-three `ComplexF64` fixture assigns four distinct values to the
  explicit sectors `(0,0,0)`, `(1,1,0)`, `(1,0,1)`, and `(0,1,1)`;
- after fusing the first two axes, the assertions directly locate those
  values at fused dense indices `1,2,3,4`;
- the third axis distinguishes the even and odd total sectors, so the test
  independently establishes the bra-first pair map
  `(0,0),(1,1),(1,0),(0,1) -> 1,2,3,4`.

This no longer relies on comparing the nested candidate and
`reduced_tensor` at the same potentially mislabelled index.

### Evidence

- Fix commit: `cdba085b5e4ea5175b3c8ad647296b88436bc8ef`.
- Tracked change is test-only; production remains unchanged from
  `b1dcbee`.
- RED demonstrated the old weakness: only 16 unique values among 218
  coordinates for each scalar type.
- Focused GREEN: `168/168`, exit 0, peak RSS 893,564 KiB, no memory kill.
- The prior full production suite remains `1106/1106`, exit 0.
- `git diff --check b1dcbee..cdba085b` is clean.
