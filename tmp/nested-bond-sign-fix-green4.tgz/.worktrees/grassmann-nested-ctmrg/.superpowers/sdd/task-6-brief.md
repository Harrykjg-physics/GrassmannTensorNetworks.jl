### Task 6: Reverse Rules and Gradient Accuracy

**Files:**

- Create: `algorithms/Nested_CTMRG/nested_chainrules.jl`
- Create: `test/nested_chainrules.jl`
- Modify: `ext/GrassmannChainRulesCoreExt/GrassmannChainRulesCoreExt.jl`
- Modify: `test/runtests.jl`
- Modify: `test/server_runtests.jl`

**Interfaces:**

- Consumes: K/B/Y construction and existing Grassmann ChainRules.
- Produces `rrule`s for `_graded_pair_sign`, the four native placement
  helpers, `nested_network`, and `nested_y_operator`.

- [ ] **Step 1: Write a reusable centered directional-derivative test**

```julia
using ChainRulesCore
using FiniteDifferences
using LinearAlgebra
using Random
using Test
using Zygote

function directional_error(f, x, direction; step=1e-6)
    value, pullback = Zygote.pullback(f, x)
    gradient = only(pullback(one(value)))
    finite = (f(x + step * direction) - f(x - step * direction)) / (2step)
    analytic = real(dot(gradient, direction))
    relative =
        abs(analytic - finite) /
        max(abs(analytic), abs(finite), eps(Float64))
    return relative, analytic, finite
end

@testset "Nested reverse rules" begin
    Random.seed!(0x4e455354)
    count = square_gpeps_parameter_count(2, 1, 2, 1, 1)
    params = randn(count)
    direction = randn(count)
    direction ./= norm(direction)

    nested_norm2(x) = begin
        peps = Square_GPEPS(2, 1, 2, 1, 1, x, false)
        nested = nested_network(peps)
        sum(t -> sum(abs2, t), nested.network)
    end
    relative, analytic, finite =
        directional_error(nested_norm2, params, direction)
    @info "nested network directional derivative" relative analytic finite
    @test relative <= 1e-4
end
```

- [ ] **Step 2: Run and confirm reverse-mode failure**

Expected: Zygote fails on dictionary mutation, matrix assignment, or a missing
pullback in nested construction.

- [ ] **Step 3: Include nested rules only from the extension**

Add a second import statement after the existing
`import GrassmannTensorNetworks: ...` block:

```julia
import GrassmannTensorNetworks:
    NestedLayout, NestedNetwork,
    nested_network, nested_y_operator,
    _source_site, _graded_pair_sign,
    _nested_ket, _nested_ket_raw,
    _nested_bra, _nested_bra_raw,
    _nested_ket_for_network, _nested_bra_for_network,
    _nested_x_for_network, _nested_y_for_network,
    _nested_y_operator_raw
```

Append:

```julia
include(joinpath(
    @__DIR__, "..", "..", "algorithms", "Nested_CTMRG", "nested_chainrules.jl"
))
```

Do not include this file from `src/algorithms.jl`.

- [ ] **Step 4: Implement linear pair-sign and node pullbacks**

```julia
function ChainRulesCore.rrule(
    ::typeof(_graded_pair_sign), t::Grassmann, i::Int, j::Int)

    y = _graded_pair_sign(t, i, j)
    pullback(delta) = (
        NoTangent(),
        _graded_pair_sign(unthunk(delta), i, j),
        NoTangent(),
        NoTangent(),
    )
    return y, pullback
end
```

Define `_nested_ket` and `_nested_bra` rules around their raw pipelines:

```julia
function ChainRulesCore.rrule(
    config::RuleConfig{>:HasReverseMode},
    ::typeof(_nested_ket),
    A::Grassmann,
)
    y, raw_pullback = rrule_via_ad(config, _nested_ket_raw, A)
    function pullback(delta)
        _, delta_A = raw_pullback(unthunk(delta))
        return NoTangent(), delta_A
    end
    return y, pullback
end

function ChainRulesCore.rrule(
    config::RuleConfig{>:HasReverseMode},
    ::typeof(_nested_bra),
    A::Grassmann,
)
    y, raw_pullback = rrule_via_ad(config, _nested_bra_raw, A)
    function pullback(delta)
        _, delta_A = raw_pullback(unthunk(delta))
        return NoTangent(), delta_A
    end
    return y, pullback
end
```

This keeps the static integer permutations out of the returned tangent tuple
while reusing existing `fuse`, sign, bend, and conjugation rules.

Define the placement-helper rules. The K/B rules include the north-input
twist; the X/Y placement maps are diagonal signs and therefore self-adjoint:

```julia
function ChainRulesCore.rrule(
    config::RuleConfig{>:HasReverseMode},
    ::typeof(_nested_ket_for_network),
    A::Grassmann,
)
    y, pullback_A = rrule_via_ad(
        config,
        input -> _nested_ket(
            add_parity_sign(
                input, 4;
                sign_function=GrassmannTensorNetworks.global_sign,
            )
        ),
        A,
    )
    function pullback(delta)
        _, delta_A = pullback_A(unthunk(delta))
        return NoTangent(), delta_A
    end
    return y, pullback
end

function ChainRulesCore.rrule(
    config::RuleConfig{>:HasReverseMode},
    ::typeof(_nested_bra_for_network),
    A::Grassmann,
)
    y, pullback_A = rrule_via_ad(
        config,
        input -> _nested_bra(
            add_parity_sign(
                input, 4;
                sign_function=GrassmannTensorNetworks.global_sign,
            )
        ),
        A,
    )
    function pullback(delta)
        _, delta_A = pullback_A(unthunk(delta))
        return NoTangent(), delta_A
    end
    return y, pullback
end

function ChainRulesCore.rrule(
    ::typeof(_nested_x_for_network), xraw::Grassmann
)
    y = _nested_x_for_network(xraw)
    pullback(delta) =
        (NoTangent(), _nested_x_for_network(unthunk(delta)))
    return y, pullback
end

function ChainRulesCore.rrule(
    ::typeof(_nested_y_for_network), yraw::Grassmann
)
    y = _nested_y_for_network(yraw)
    pullback(delta) =
        (NoTangent(), _nested_y_for_network(unthunk(delta)))
    return y, pullback
end
```

- [ ] **Step 5: Implement the network assembly pullback**

Materialize `Tangent`-backed Grassmann cotangents before adding the K and B
paths:

```julia
function _materialize_nested_cotangent(delta, primal)
    delta = unthunk(delta)
    return delta isa Tangent ?
        ChainRulesCore.construct(
            typeof(primal), ChainRulesCore.backing(delta)
        ) : delta
end

function _add_nested_cotangents(first, second, primal)
    first = _materialize_nested_cotangent(first, primal)
    second = _materialize_nested_cotangent(second, primal)
    first isa AbstractZero && return second
    second isa AbstractZero && return first
    return first + second
end
```

Then use the approved reference pattern:

```julia
function ChainRulesCore.rrule(
    config::RuleConfig{>:HasReverseMode},
    ::typeof(nested_network),
    peps::Square_GPEPS,
    layout::NestedLayout)

    ket_rules = map(
        A -> rrule_via_ad(config, _nested_ket_for_network, A), peps.A
    )
    bra_rules = map(
        A -> rrule_via_ad(config, _nested_bra_for_network, A), peps.A
    )
    nested = nested_network(peps, layout)

    function pullback(delta_nested)
        delta_nested = unthunk(delta_nested)
        delta_nested isa AbstractZero &&
            return NoTangent(), ZeroTangent(), NoTangent()
        delta_network = unthunk(getproperty(delta_nested, :network))
        raw_gradients = map(CartesianIndices(peps.A)) do source
            _, dket = last(ket_rules[source])(
                delta_network[layout.ket_sites[source]]
            )
            _, dbra = last(bra_rules[source])(
                delta_network[layout.bra_sites[source]]
            )
            return _add_nested_cotangents(
                unthunk(dket), unthunk(dbra), peps.A[source]
            )
        end
        Tensor = eltype(peps.A)
        gradients = map(CartesianIndices(peps.A)) do source
            gradient = raw_gradients[source]
            primal = peps.A[source]
            gradient isa AbstractZero ? zero(primal) : gradient
        end
        delta_peps = Tangent{typeof(peps)}(
            ; A=Matrix{Tensor}(gradients),
              Λx=NoTangent(), Λy=NoTangent()
        )
        return NoTangent(), delta_peps, NoTangent()
    end
    return nested, pullback
end
```

Add the two-argument rule by delegating to `NestedLayout(peps)`:

```julia
function ChainRulesCore.rrule(
    config::RuleConfig{>:HasReverseMode},
    ::typeof(nested_network),
    peps::Square_GPEPS,
)
    nested, pullback =
        rrule(config, nested_network, peps, NestedLayout(peps))
    function two_argument_pullback(delta)
        _, delta_peps, _ = pullback(delta)
        return NoTangent(), delta_peps
    end
    return nested, two_argument_pullback
end
```

Add the operator-dressed Y rule. Geometry and PEPS dimensions are static;
only the operator is a numerical input to this rule:

```julia
function ChainRulesCore.rrule(
    config::RuleConfig{>:HasReverseMode},
    ::typeof(nested_y_operator),
    nested::NestedNetwork,
    peps::Square_GPEPS,
    site,
    operator::Grassmann,
)
    source = _source_site(site)
    y, raw_pullback = rrule_via_ad(
        config, _nested_y_operator_raw,
        nested, peps, source, operator,
    )
    function pullback(delta)
        _, _, _, _, delta_operator = raw_pullback(unthunk(delta))
        return (
            NoTangent(), NoTangent(), NoTangent(),
            NoTangent(), delta_operator,
        )
    end
    return y, pullback
end
```

Use the actual `Square_GPEPS` field names `A`, `Λx`, and `Λy`.

- [ ] **Step 6: Add one-site and bond-energy gradient tests**

Freeze a deterministic one-iteration environment and define the three
objectives:

```julia
function convert_nested_env(env::CTMRGEnv, ::Type{T}) where {T}
    convert_grid(grid) = Matrix{Grassmann{T, ndims(first(grid))}}(
        reshape([convert(tensor, T) for tensor in grid], size(grid))
    )
    return CTMRGEnv{T}(
        convert_grid(env.El), convert_grid(env.Er),
        convert_grid(env.Eu), convert_grid(env.Ed),
        convert_grid(env.Clu), convert_grid(env.Cru),
        convert_grid(env.Cld), convert_grid(env.Crd),
    )
end

initial_peps = Square_GPEPS(2, 1, 2, 1, 1, params, false)
initial_nested = nested_network(initial_peps)
frozen_env = initialize_nested_environment(initial_nested, 4)
run_nested_GCTMRG!(
    initial_nested, frozen_env, 4;
    ctmrg_iter=1, verbosity=0, save_iter=0,
)
model = SpinlessFermionModel(1.0, 1.0, 3.0)
number = n_site(model)
bond = nn_bond(model)

function nested_inputs(x)
    peps = Square_GPEPS(2, 1, 2, 1, 1, x, false)
    nested = nested_network(peps)
    return peps, nested, convert_nested_env(frozen_env, eltype(x))
end

site_energy(x) = begin
    peps, nested, env = nested_inputs(x)
    _, value =
        compute_nested_exp_site(nested, peps, number, env, (1, 1))
    real(value)
end
horizontal_energy(x) = begin
    peps, nested, env = nested_inputs(x)
    _, value =
        compute_nested_exp_hbond(nested, peps, bond, env, (1, 1))
    real(value)
end
vertical_energy(x) = begin
    peps, nested, env = nested_inputs(x)
    _, value =
        compute_nested_exp_vbond(nested, peps, bond, env, (1, 1))
    real(value)
end

for (name, objective) in (
    ("site", site_energy),
    ("horizontal", horizontal_energy),
    ("vertical", vertical_energy),
)
    relative, analytic, finite =
        directional_error(objective, params, direction)
    @info "nested measurement directional derivative" name relative analytic finite
    @test relative <= 1e-4
end
```

The logged values let a server failure distinguish a sign error from
numerical noise.

- [ ] **Step 7: Run tests and commit**

```bash
git add algorithms/Nested_CTMRG/nested_chainrules.jl \
        ext/GrassmannChainRulesCoreExt/GrassmannChainRulesCoreExt.jl \
        test/nested_chainrules.jl test/runtests.jl test/server_runtests.jl
git commit -m "feat: differentiate nested Grassmann networks"
```

---

