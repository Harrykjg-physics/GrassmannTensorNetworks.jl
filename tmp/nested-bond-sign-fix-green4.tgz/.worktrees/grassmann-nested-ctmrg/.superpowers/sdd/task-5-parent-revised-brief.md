### Task 5: Horizontal and Vertical Three-Node Measurements

> **Testing amendment:** Keep the production steps in this task, but replace
> its CTMRG-based tests with Task 2 of
> `docs/superpowers/plans/2026-07-31-nested-exact-measurement-tests.md`.
> Measurement tests must compare exact horizontal and vertical nested and
> reduced bond closures without constructing or iterating a CTMRG
> environment.

**Files:**

- Modify: `algorithms/Nested_CTMRG/measurements.jl`
- Modify: `test/nested_measurements.jl`

**Interfaces:**

- Consumes: operator-dressed Y tensors and nested CTMRG environments.
- Produces:
  - `_check_nested_bond_operator(peps, operator, source, neighbor)`
  - `_contract_nested_hpatch3(nested, env, source, left_y, right_y)`
  - `_contract_nested_vpatch3(nested, env, source, top_y, bottom_y)`
  - `compute_nested_exp_hbond(...)`
  - `compute_nested_exp_vbond(...)`

- [ ] **Step 1: Write exact identity and Hamiltonian-bond tests**

Execute Task 2 Steps 1-3 of
`docs/superpowers/plans/2026-07-31-nested-exact-measurement-tests.md`.
Those steps contain the complete two-site identity, operator reconstruction,
rank-six reduced closure, horizontal/vertical comparison, nonzero-numerator,
and four-spin-structure tests.

- [ ] **Step 2: Run and verify missing-function failures**

Expected: FAIL because the two bond functions do not exist.

- [ ] **Step 3: Factor a two-site operator into parity-preserving one-site terms**

Implement an internal exact operator Schmidt decomposition. This converts one
two-site insertion into a sum of products of two operator-dressed Y tensors
and avoids inventing a separate rank-eight Grassmann impurity type:

```julia
function _check_nested_bond_operator(
    peps::Square_GPEPS,
    operator::Grassmann{<:Number, 4},
    source::CartesianIndex{2},
    neighbor::CartesianIndex{2},
)
    checkbounds(Bool, peps.A, source) ||
        throw(ArgumentError("source site $source is outside the unit cell"))
    checkbounds(Bool, peps.A, neighbor) ||
        throw(ArgumentError(
            "neighbor site $neighbor is outside the unit cell"
        ))
    source_physical = size(peps.A[source])[1]
    neighbor_physical = size(peps.A[neighbor])[1]
    expected_size = (
        source_physical,
        neighbor_physical,
        source_physical,
        neighbor_physical,
    )
    size(operator) == expected_size ||
        throw(DimensionMismatch(
            "bond-operator physical dimensions do not match PEPS"
        ))
    source_even = even(peps.A[source])[1]
    neighbor_even = even(peps.A[neighbor])[1]
    expected_even = (
        source_even,
        neighbor_even,
        source_even,
        neighbor_even,
    )
    even(operator) == expected_even ||
        throw(DimensionMismatch(
            "bond-operator parity splits do not match PEPS"
        ))
    index_type(operator) == (:out, :out, :in, :in) ||
        throw(ArgumentError(
            "bond-operator arrows must be (:out, :out, :in, :in)"
        ))
    tensor_parity(operator) == 0 ||
        throw(ArgumentError("bond operator must have even total parity"))
    return nothing
end

function _operator_schmidt(operator::Grassmann{T, 4}) where {T}
    dense = convert(Array, operator)
    dout1, dout2, din1, din2 = size(operator)
    matrix = reshape(
        permutedims(dense, (1, 3, 2, 4)),
        dout1 * din1, dout2 * din2,
    )
    parity(index, even_dim) = index <= even_dim ? 0 : 1
    row_parity = [
        mod(
            parity(out, even(operator)[1]) +
            parity(input, even(operator)[3]),
            2,
        ) for out in 1:dout1, input in 1:din1
    ][:]
    col_parity = [
        mod(
            parity(out, even(operator)[2]) +
            parity(input, even(operator)[4]),
            2,
        ) for out in 1:dout2, input in 1:din2
    ][:]

    terms = Tuple{Grassmann, Grassmann}[]
    for sector in 0:1
        rows = findall(==(sector), row_parity)
        cols = findall(==(sector), col_parity)
        factor = svd(matrix[rows, cols])
        for alpha in eachindex(factor.S)
            factor.S[alpha] > eps(real(float(one(T)))) || continue
            left_vector = zeros(eltype(factor.U), dout1 * din1)
            right_vector = zeros(eltype(factor.Vt), dout2 * din2)
            left_vector[rows] =
                factor.U[:, alpha] * sqrt(factor.S[alpha])
            right_vector[cols] =
                factor.Vt[alpha, :] * sqrt(factor.S[alpha])
            parity_symbol = sector == 0 ? :even : :odd
            left = Grassmann(
                reshape(left_vector, dout1, din1),
                (dout1, din1),
                (even(operator)[1], even(operator)[3]),
                (:out, :in);
                parity=parity_symbol,
            )
            right = Grassmann(
                reshape(right_vector, dout2, din2),
                (dout2, din2),
                (even(operator)[2], even(operator)[4]),
                (:out, :in);
                parity=parity_symbol,
            )
            push!(terms, (left, right))
        end
    end
    return terms
end
```

Verify reconstruction before using the terms:

```julia
reconstructed = sum(
    contract(left, right; sign_function=global_sign) for (left, right) in terms
)
ordered = permutedims(reconstructed, (1, 3, 2, 4); sign_function=global_sign)
@test ordered ≈ operator rtol=1e-12
```

The two parity sectors are decomposed separately, so every Schmidt term has a
defined one-site operator parity and odd terms occur in odd-odd pairs.

- [ ] **Step 4: Implement normalized arbitrary-strip contractions**

Build each numerator as a sum over operator-Schmidt terms. For a horizontal
bond, replace the two endpoint Y tensors and retain the K tensor between them;
for a vertical bond retain the B tensor. Reuse the tested `left_move` and
`up_move` primitives from `algorithms/CTMRG/measurements.jl`; these absorb one
bulk column/row with the same fermionic axis order as ordinary correlation
functions. Add these complete strip helpers:

```julia
function _contract_horizontal_strip(
    bulks::NTuple{N, <:Grassmann},
    env::CTMRGEnv,
    sites::NTuple{N, CartesianIndex{2}},
) where {N}
    N > 0 || throw(ArgumentError("a strip must contain at least one tensor"))
    left_site = first(sites)
    right_site = last(sites)

    # L[top, bulk, bottom] from the left corners and edge.
    left_top = contract(
        env.Clu[left_site], env.El[left_site], (2, 1);
        sign_function=global_sign,
    )
    state = contract(
        left_top, env.Cld[left_site], (2, 2);
        sign_function=global_sign,
    )
    for (bulk, site) in zip(bulks, sites)
        state, _ = left_move(
            state, env.Ed[site], bulk, env.Eu[site]
        )
    end

    # R[top, bulk, bottom] from the right corners and edge.
    right_top = contract(
        env.Cru[right_site], env.Er[right_site], (2, 1);
        sign_function=global_sign,
    )
    right = contract(
        right_top, env.Crd[right_site], (2, 2);
        sign_function=global_sign,
    )
    return contract(
        state, right, ((1, 2, 3), (1, 2, 3));
        sign_function=global_sign,
    )
end

function _contract_vertical_strip(
    bulks::NTuple{N, <:Grassmann},
    env::CTMRGEnv,
    sites::NTuple{N, CartesianIndex{2}},
) where {N}
    N > 0 || throw(ArgumentError("a strip must contain at least one tensor"))
    top_site = first(sites)
    bottom_site = last(sites)

    # U[left, bulk, right] from the upper corners and edge.
    upper_left = contract(
        env.Clu[top_site], env.Eu[top_site], (1, 1);
        sign_function=global_sign,
    )
    state = contract(
        upper_left, env.Cru[top_site], (2, 1);
        sign_function=global_sign,
    )
    for (bulk, site) in zip(bulks, sites)
        state, _ = up_move(
            state, env.El[site], bulk, env.Er[site]
        )
    end

    # D[left, bulk, right] from the lower corners and edge.
    lower_left = contract(
        env.Cld[bottom_site], env.Ed[bottom_site], (1, 1);
        sign_function=global_sign,
    )
    lower = contract(
        lower_left, env.Crd[bottom_site], (2, 1);
        sign_function=global_sign,
    )
    return contract(
        state, lower, ((1, 2, 3), (1, 2, 3));
        sign_function=global_sign,
    )
end

function _contract_nested_hpatch3(
    nested::NestedNetwork,
    env::CTMRGEnv,
    source::CartesianIndex{2},
    left_y::Grassmann,
    right_y::Grassmann,
)
    y1 = nested.layout.y_sites[source]
    next_source = CartesianIndex(
        source[1],
        Nmod(source[2] + 1, nested.layout.source_size[2]),
    )
    y2 = nested.layout.y_sites[next_source]
    middle = CartesianIndex(
        y1[1], Nmod(y1[2] + 1, size(nested, 2))
    )
    return _contract_horizontal_strip(
        (left_y, nested[middle], right_y),
        env,
        (y1, middle, y2),
    )
end

function _contract_nested_vpatch3(
    nested::NestedNetwork,
    env::CTMRGEnv,
    source::CartesianIndex{2},
    top_y::Grassmann,
    bottom_y::Grassmann,
)
    y1 = nested.layout.y_sites[source]
    next_source = CartesianIndex(
        Nmod(source[1] + 1, nested.layout.source_size[1]),
        source[2],
    )
    y2 = nested.layout.y_sites[next_source]
    middle = CartesianIndex(
        Nmod(y1[1] + 1, size(nested, 1)), y1[2]
    )
    return _contract_vertical_strip(
        (top_y, nested[middle], bottom_y),
        env,
        (y1, middle, y2),
    )
end
```

Return the raw scalar patch contraction. Compute a denominator once using two
physical identities, and divide the summed operator-Schmidt numerator by that
same denominator.

- [ ] **Step 5: Implement public horizontal/vertical functions**

```julia
function compute_nested_exp_hbond(
    nested::NestedNetwork, peps::Square_GPEPS,
    operator::Grassmann{<:Number, 4}, env::CTMRGEnv, site)

    source = _source_site(site)
    neighbor = CartesianIndex(
        source[1], Nmod(source[2] + 1, size(peps)[2])
    )
    _check_nested_bond_operator(peps, operator, source, neighbor)
    identity_left = _physical_identity(peps.A[source])
    identity_right = _physical_identity(peps.A[neighbor])
    closed_left = nested_y_operator(nested, peps, source, identity_left)
    closed_right = nested_y_operator(nested, peps, neighbor, identity_right)
    denominator = _contract_nested_hpatch3(
        nested, env, source, closed_left, closed_right
    )
    terms = _operator_schmidt(operator)
    numerator = isempty(terms) ? zero(denominator) : sum(terms) do (left_op, right_op)
        left_y = nested_y_operator(nested, peps, source, left_op)
        right_y = nested_y_operator(nested, peps, neighbor, right_op)
        _contract_nested_hpatch3(nested, env, source, left_y, right_y)
    end
    return denominator, scalar(numerator) / scalar(denominator)
end
```

Add the vertical method and explicit unit-cell overloads:

```julia
function compute_nested_exp_vbond(
    nested::NestedNetwork, peps::Square_GPEPS,
    operator::Grassmann{<:Number, 4}, env::CTMRGEnv, site)

    source = _source_site(site)
    neighbor = CartesianIndex(
        Nmod(source[1] + 1, size(peps)[1]), source[2]
    )
    _check_nested_bond_operator(peps, operator, source, neighbor)
    identity_top = _physical_identity(peps.A[source])
    identity_bottom = _physical_identity(peps.A[neighbor])
    closed_top = nested_y_operator(nested, peps, source, identity_top)
    closed_bottom = nested_y_operator(nested, peps, neighbor, identity_bottom)
    denominator = _contract_nested_vpatch3(
        nested, env, source, closed_top, closed_bottom
    )
    terms = _operator_schmidt(operator)
    numerator = isempty(terms) ? zero(denominator) : sum(terms) do (top_op, bottom_op)
        top_y = nested_y_operator(nested, peps, source, top_op)
        bottom_y = nested_y_operator(nested, peps, neighbor, bottom_op)
        _contract_nested_vpatch3(nested, env, source, top_y, bottom_y)
    end
    return denominator, scalar(numerator) / scalar(denominator)
end

function compute_nested_exp_hbond(
    nested::NestedNetwork, peps::Square_GPEPS,
    operators::AbstractMatrix{<:Grassmann}, env::CTMRGEnv)

    size(operators) == size(peps) ||
        throw(DimensionMismatch("operator and PEPS unit cells differ"))
    results = map(CartesianIndices(peps.A)) do site
        compute_nested_exp_hbond(
            nested, peps, operators[site], env, site
        )
    end
    return first.(results), last.(results)
end

function compute_nested_exp_vbond(
    nested::NestedNetwork, peps::Square_GPEPS,
    operators::AbstractMatrix{<:Grassmann}, env::CTMRGEnv)

    size(operators) == size(peps) ||
        throw(DimensionMismatch("operator and PEPS unit cells differ"))
    results = map(CartesianIndices(peps.A)) do site
        compute_nested_exp_vbond(
            nested, peps, operators[site], env, site
        )
    end
    return first.(results), last.(results)
end
```

- [ ] **Step 6: Cross-check exact reduced-layer bond contractions**

Execute Task 2 Steps 1, 2, and 5 of the exact-test companion. Compare raw
denominators, raw numerators, and normalized horizontal/vertical
expectations at `rtol=5e-12` and `atol=1e-12`. Do not construct or iterate
a CTMRG environment in `test/nested_measurements.jl`.

- [ ] **Step 7: Run tests and commit**

```bash
git add algorithms/Nested_CTMRG/measurements.jl test/nested_measurements.jl
git commit -m "feat: measure nested nearest-neighbor operators"
```

---

