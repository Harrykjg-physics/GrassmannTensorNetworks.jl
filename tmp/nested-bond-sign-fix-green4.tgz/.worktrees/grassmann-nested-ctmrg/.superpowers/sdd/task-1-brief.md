### Task 1: Nested Layout, Wrapper, and Package Wiring

**Files:**

- Create: `algorithms/Nested_CTMRG/nested_network.jl`
- Create: `test/nested_network.jl`
- Modify: `src/algorithms.jl`
- Modify: `src/GrassmannTensorNetworks.jl`
- Modify: `test/runtests.jl`
- Modify: `test/server_runtests.jl`

**Interfaces:**

- Consumes: `Square_GPEPS`, `Grassmann`, `CTMRGEnv`, `run_GCTMRG!`.
- Produces:
  - `NestedLayout(source_size::Tuple{Int,Int})`
  - `NestedLayout(peps::Square_GPEPS)`
  - `NestedNetwork(network, layout, x_crossings)`

- [ ] **Step 1: Write the failing layout and export tests**

Add to `test/nested_network.jl`:

```julia
using Test
using GrassmannTensorNetworks

@testset "Nested layout" begin
    layout = NestedLayout((2, 3))
    @test size(layout) == (4, 6)
    @test layout.source_size == (2, 3)
    @test layout.ket_sites[2, 3] == CartesianIndex(3, 5)
    @test layout.y_sites[2, 3] == CartesianIndex(3, 6)
    @test layout.x_sites[2, 3] == CartesianIndex(4, 5)
    @test layout.bra_sites[2, 3] == CartesianIndex(4, 6)
end
```

Add `include("nested_network.jl")` inside the top-level testset in both test
entry points. Add assertions to the existing package-symbol smoke test:

```julia
@test isdefined(GrassmannTensorNetworks, :NestedLayout)
@test isdefined(GrassmannTensorNetworks, :NestedNetwork)
```

- [ ] **Step 2: Run the focused test to verify failure**

Run on the Julia server:

```bash
julia_grassmann --project=. test/server_runtests.jl
```

Expected: FAIL with `UndefVarError: NestedLayout not defined`.

- [ ] **Step 3: Implement layout and wrapper types**

Add to `algorithms/Nested_CTMRG/nested_network.jl`:

```julia
struct NestedLayout
    source_size::Tuple{Int, Int}
    nested_size::Tuple{Int, Int}
    ket_sites::Matrix{CartesianIndex{2}}
    y_sites::Matrix{CartesianIndex{2}}
    x_sites::Matrix{CartesianIndex{2}}
    bra_sites::Matrix{CartesianIndex{2}}
end

function NestedLayout(source_size::Tuple{Int, Int})
    rows, cols = source_size
    rows > 0 && cols > 0 ||
        throw(ArgumentError("source unit-cell dimensions must be positive"))
    ket = [CartesianIndex(2r - 1, 2c - 1) for r in 1:rows, c in 1:cols]
    y = [CartesianIndex(2r - 1, 2c) for r in 1:rows, c in 1:cols]
    x = [CartesianIndex(2r, 2c - 1) for r in 1:rows, c in 1:cols]
    bra = [CartesianIndex(2r, 2c) for r in 1:rows, c in 1:cols]
    return NestedLayout(source_size, (2rows, 2cols), ket, y, x, bra)
end

NestedLayout(peps::Square_GPEPS) = NestedLayout(size(peps))
Base.size(layout::NestedLayout) = layout.nested_size
Base.size(layout::NestedLayout, dim::Integer) = layout.nested_size[dim]

struct NestedNetwork{T<:Number, X<:AbstractMatrix}
    network::Matrix{Grassmann{T, 4}}
    layout::NestedLayout
    x_crossings::X
end

Base.size(nested::NestedNetwork, args...) = size(nested.network, args...)
Base.axes(nested::NestedNetwork, args...) = axes(nested.network, args...)
Base.getindex(nested::NestedNetwork, inds...) = getindex(nested.network, inds...)
```

Wire the new network source into `src/algorithms.jl` after the existing CTMRG
core includes:

```julia
include(joinpath(@__DIR__, "..", "algorithms", "Nested_CTMRG", "nested_network.jl"))
```

Export the types and entry points from `src/GrassmannTensorNetworks.jl`:

```julia
export NestedLayout, NestedNetwork
```

- [ ] **Step 4: Run the focused tests**

Run the same server command. Expected: layout and wrapper symbol tests PASS.

- [ ] **Step 5: Commit**

```bash
git add algorithms/Nested_CTMRG/nested_network.jl \
        src/algorithms.jl src/GrassmannTensorNetworks.jl \
        test/nested_network.jl test/runtests.jl test/server_runtests.jl
git commit -m "feat: add nested CTMRG layout"
```

---

