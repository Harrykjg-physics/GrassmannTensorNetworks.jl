using Pkg

Pkg.activate(joinpath(@__DIR__, "harness"))
Pkg.develop(path=joinpath(@__DIR__, "src"))

using Random
using GrassmannTensorNetworks

@eval GrassmannTensorNetworks global global_sign = auto_sign

Random.seed!(0x4e455354)
peps = Square_GPEPS(2, 1, 2, 1, 1, Float64, false)
number = n_site(SpinlessFermionModel(1.0, 1.0, 3.0))

nested = nested_network(peps)
nested_env = initialize_nested_environment(nested, 8)
nested_values = Dict{Int, Float64}()
for iteration in 1:20
    run_nested_GCTMRG!(
        nested, nested_env, 8;
        ctmrg_iter=1, verbosity=0, save_iter=0,
    )
    if iteration in (1, 2, 5, 10, 20)
        _, value =
            compute_nested_exp_site(
                nested, peps, number, nested_env, (1, 1)
            )
        nested_values[iteration] = real(value)
    end
end

reduced_bulk =
    Matrix{Grassmann{Float64, 4}}(reduced_tensor.(peps.A))
reduced_impurity =
    Matrix{Grassmann{Float64, 4}}(
        reduced_tensor.(peps.A, Ref(number))
    )
reduced_env = CTMRGEnv(reduced_bulk, 8, 4)
reduced_values = Dict{Int, Float64}()
for iteration in 1:20
    run_GCTMRG!(
        reduced_bulk, reduced_bulk, reduced_env, 8;
        ctmrg_iter=1, verbosity=0, save_iter=0,
    )
    if iteration in (1, 2, 5, 10, 20)
        _, values =
            compute_exp_site(reduced_bulk, reduced_impurity, reduced_env)
        reduced_values[iteration] = real(values[1, 1])
    end
end

for iteration in (1, 2, 5, 10, 20)
    println(
        "iteration=", iteration,
        " nested=", nested_values[iteration],
        " reduced=", reduced_values[iteration],
        " difference=",
        nested_values[iteration] - reduced_values[iteration],
    )
end
