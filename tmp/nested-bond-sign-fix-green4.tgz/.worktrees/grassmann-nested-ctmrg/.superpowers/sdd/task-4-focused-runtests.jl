using Pkg

Pkg.activate(joinpath(@__DIR__, "harness"))
Pkg.develop(path=joinpath(@__DIR__, "src"))

using Test
using LinearAlgebra
using GrassmannTensorNetworks

@eval GrassmannTensorNetworks global global_sign = auto_sign

function close_nested_test_row(row; twist_x=false)
    sign = GrassmannTensorNetworks.global_sign
    cols = length(row)
    current =
        permutedims(row[1], (1, 3, 4, 2); sign_function=sign)
    for c in 2:cols
        j = c - 1
        rank = 2j + 2
        perm = (
            1,
            (2:(j + 1))...,
            2j + 3,
            ((j + 2):(2j + 1))...,
            2j + 4,
            2j + 2,
        )
        current = contract(
            current, row[c], (rank, 1);
            perm, sign_function=sign,
        )
    end
    return trace(
        current, (1, 2cols + 2);
        pbc=!twist_x, sign_function=sign,
    )
end

function nested_test_torus_scalar(tensors; twist_x=false, twist_y=false)
    sign = GrassmannTensorNetworks.global_sign
    rows, cols = size(tensors)
    row_tensors = [
        close_nested_test_row(collect(tensors[r, :]); twist_x)
        for r in 1:rows
    ]
    current = row_tensors[1]
    for r in 2:rows
        current = contract(
            current,
            row_tensors[r],
            (ntuple(i -> cols + i, cols), ntuple(identity, cols));
            sign_function=sign,
        )
    end
    closed = trace(
        current,
        (ntuple(identity, cols), ntuple(i -> cols + i, cols));
        pbc=ntuple(_ -> !twist_y, cols),
        sign_function=sign,
    )
    return scalar(closed)
end

@testset "Focused nested measurements" begin
    include(joinpath(@__DIR__, "src", "test", "nested_measurements.jl"))
end
