### Task 2: Graded Crossing and K/Y/X/B Local Nodes

**Files:**

- Modify: `algorithms/Nested_CTMRG/nested_network.jl`
- Modify: `test/nested_network.jl`

**Interfaces:**

- Consumes: `Grassmann`, `Square_GPEPS`, `permutedims`, `fuse`,
  `index_conjugation`, `add_parity_sign`, `global_sign`.
- Produces:
  - `_graded_pair_sign(t, i, j)`
  - `_nested_ket(A)`
  - `_nested_bra(A)`
  - `_nested_x(horizontal_size, horizontal_even, vertical_size, vertical_even, T)`
  - `_nested_y(operator, horizontal_size, horizontal_even, vertical_size, vertical_even)`
  - `_physical_identity(A)`

- [ ] **Step 1: Write failing sign and node-structure tests**

Append:

```julia
import GrassmannTensorNetworks:
    _graded_pair_sign, _nested_ket, _nested_bra, _nested_x, _nested_y

@testset "Nested graded primitives" begin
    odd_crossing = _nested_x(1, 0, 1, 0, Float64)
    @test !haskey(odd_crossing, (0, 0, 0, 0))
    @test only(odd_crossing[(1, 1, 1, 1)]) == -1

    mixed_crossing = _nested_x(2, 1, 2, 1, Float64)
    dense = convert(Array, mixed_crossing)
    @test dense[1, 1, 1, 1] == 1
    @test dense[2, 2, 1, 1] == 1
    @test dense[1, 1, 2, 2] == 1
    @test dense[2, 2, 2, 2] == -1

    peps = Square_GPEPS(2, 1, 2, 1, 1, Float64, false)
    A = peps.A[1, 1]
    K = _nested_ket(A)
    B = _nested_bra(A)
    @test size(K) == (2, 4, 2, 2)
    @test size(B) == (2, 2, 4, 2)
    @test index_type(K) == (:out, :in, :in, :out)
    @test index_type(B) == (:out, :in, :in, :out)

    identity = Grassmann(Matrix{Float64}(I, 2, 2), (2, 2), (1, 1), (:out, :in))
    Y = _nested_y(identity, 2, 1, 2, 1)
    @test size(Y) == (4, 2, 2, 4)
    @test index_type(Y) == (:out, :in, :in, :out)
end
```

- [ ] **Step 2: Run and confirm missing-function failures**

Expected: FAIL at import because `_graded_pair_sign` and node functions do not
exist.

- [ ] **Step 3: Implement the pair sign and pure crossing**

Add:

```julia
function _graded_pair_sign(t::Grassmann{T, N, AT}, i::Int, j::Int) where {T, N, AT}
    1 <= i <= N && 1 <= j <= N && i != j ||
        throw(ArgumentError("graded-pair indices must be distinct and in bounds"))
    blocks = Dict{NTuple{N, Int}, AT}()
    for (sector, block) in nonzero_pairs(t)
        blocks[sector] = (-1)^(sector[i] * sector[j]) .* block
    end
    return Grassmann(size(t), even(t), index_type(t), blocks)
end

function _nested_x(
    horizontal_size::Int,
    horizontal_even::Int,
    vertical_size::Int,
    vertical_even::Int,
    ::Type{T}) where {T}

    dense = zeros(T, horizontal_size, horizontal_size, vertical_size, vertical_size)
    parity(index, even_dim) = index <= even_dim ? 0 : 1
    for h in 1:horizontal_size, v in 1:vertical_size
        dense[h, h, v, v] =
            (-one(T))^(parity(h, horizontal_even) * parity(v, vertical_even))
    end
    return Grassmann(
        dense,
        (horizontal_size, horizontal_size, vertical_size, vertical_size),
        (horizontal_even, horizontal_even, vertical_even, vertical_even),
        (:out, :in, :in, :out),
    )
end
```

- [ ] **Step 4: Implement K, B, identity, and operator-dressed Y**

Use one explicit arrow-bend helper so every bend carries the same parity
twist:

```julia
function _bend_index(t::Grassmann, index::Int)
    return add_parity_sign(
        index_conjugation(t, index), index; sign_function=global_sign
    )
end

function _nested_ket_raw(A::Grassmann{T, 5}) where {T}
    signed = _graded_pair_sign(A, 1, 3)
    routed = permutedims(signed, (2, 1, 3, 4, 5); sign_function=global_sign)
    return fuse(routed, (2, 3); index_type_fused=:in)
end
_nested_ket(A::Grassmann{T, 5}) where {T} = _nested_ket_raw(A)

function _nested_bra_raw(A::Grassmann{T, 5}) where {T}
    bra = conj(A; sign_function=global_sign)
    signed = _graded_pair_sign(bra, 1, 4)
    routed = permutedims(signed, (2, 3, 1, 4, 5); sign_function=global_sign)
    fused = fuse(routed, (3, 4); index_type_fused=:in)
    return foldl(_bend_index, (1, 2, 4); init=fused)
end
_nested_bra(A::Grassmann{T, 5}) where {T} = _nested_bra_raw(A)

function _physical_identity(A::Grassmann{T, 5}) where {T}
    p, pe = size(A, 1), even(A)[1]
    return Grassmann(Matrix{T}(I, p, p), (p, p), (pe, pe), (:out, :in))
end

function _nested_y(
    operator::Grassmann{T, 2},
    horizontal_size::Int,
    horizontal_even::Int,
    vertical_size::Int,
    vertical_even::Int) where {T}

    crossing = _nested_x(
        horizontal_size, horizontal_even, vertical_size, vertical_even, T
    )
    product = contract(operator, crossing; sign_function=global_sign)
    routed = permutedims(
        product, (1, 3, 4, 5, 2, 6); sign_function=global_sign
    )
    west_fused = fuse(routed, (1, 2); index_type_fused=:out)
    return fuse(west_fused, (4, 5); index_type_fused=:out)
end
```

- [ ] **Step 5: Add local closure and factorization tests**

Add helpers that contract the nested tile and compare with `reduced_tensor`.
The comparison must use the documented external order
`(left, right, up, down)`:

```julia
function contract_nested_tile(K, Y, X, B)
    ky = contract(K, Y, (2, 1); sign_function=global_sign)
    kx = contract(ky, X, (3, 3); sign_function=global_sign)
    tile = contract(kx, B, ((5, 7), (3, 1)); sign_function=global_sign)
    ordered = permutedims(
        tile, (1, 5, 3, 7, 2, 4, 6, 8); sign_function=global_sign
    )
    left = fuse(ordered, (1, 2); index_type_fused=:out)
    right = fuse(left, (2, 3); index_type_fused=:in)
    up = fuse(right, (3, 4); index_type_fused=:in)
    return fuse(up, (4, 5); index_type_fused=:out)
end

@testset "Local nested factorization" begin
    for T in (Float64, ComplexF64)
        peps = Square_GPEPS(2, 1, 2, 1, 1, T, false)
        A = peps.A[1, 1]
        K, B = _nested_ket(A), _nested_bra(A)
        X = _nested_x(size(A, 2), even(A)[2], size(A, 5), even(A)[5], T)
        Y = _nested_y(
            _physical_identity(A),
            size(A, 3), even(A)[3],
            size(A, 4), even(A)[4],
        )
        @test contract_nested_tile(K, Y, X, B) ≈ reduced_tensor(A) rtol=1e-10
    end
end
```

The exact contraction indices and the documented external order are
implementation invariants; do not weaken this comparison or substitute a
dense contraction that bypasses Grassmann signs.

- [ ] **Step 6: Run tests and commit**

Expected: odd-odd sign, node structure, and local factorization all PASS.

```bash
git add algorithms/Nested_CTMRG/nested_network.jl test/nested_network.jl
git commit -m "feat: construct graded nested tensor nodes"
```

---

