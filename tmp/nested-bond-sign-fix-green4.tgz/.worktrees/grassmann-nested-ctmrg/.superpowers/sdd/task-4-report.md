# Task 4 Report — Operator-Dressed Y and One-Site Measurements

Status: **DONE**

Task 4 was completed under the user-approved exact-test amendment in:

- `.superpowers/sdd/task-4-parent-revised-brief.md`
- `.superpowers/sdd/task-4-exact-tests-brief.md`

The environment-based production scalar and matrix interfaces are preserved.
The measurement test itself constructs and iterates no CTMRG environment.

## Files

The commit contains exactly the six required tracked files:

- `algorithms/Nested_CTMRG/measurements.jl`
- `src/algorithms.jl`
- `src/GrassmannTensorNetworks.jl`
- `test/nested_measurements.jl`
- `test/runtests.jl`
- `test/server_runtests.jl`

## Implementation

- Added `nested_y_operator`, deriving the east-ket and north-bra link
  dimensions from the periodic nested network and applying
  `_nested_y_for_network` to retain Task 3's native placement signs.
- Added source-site, physical-dimension, physical-parity, and arrow
  validation.
- Added the scalar `compute_nested_exp_site` adapter over the existing
  ten-tensor scalar `compute_exp_site` interface. No alternate contraction
  semantics or tensor structures were introduced.
- Added the environment-based matrix-unit-cell overload with promoted
  scalar output matrices.
- Added the pure `_check_nested_operator_unit_cell` validator and reused it
  at the start of the environment-based matrix overload.
- Included and exported the parent Task 4 interfaces exactly as required.

## Exact measurement coverage

`test/nested_measurements.jl` now:

- uses a seeded `1 x 2` PEPS and no CTMRG environment;
- verifies identity-dressed Y equals the native nested bulk Y;
- verifies invalid source, physical size, parity split, and arrows;
- verifies valid and invalid operator unit-cell shapes through the pure
  validator;
- builds independent exact nested and reduced bulk/impurity networks;
- compares identity and number denominators, numerators, and ratios for all
  four periodic spin structures;
- uses `rtol=5e-12`, `atol=1e-12`;
- verifies at least one number numerator is nonzero.

All 32 focused assertions passed. Across the four spin structures, every
exact nested denominator and numerator agreed with its reduced
representation at the prescribed tolerance, every number ratio agreed, and
every identity ratio normalized to one.

The required static check was:

```powershell
rg -n `
  'CTMRGEnv|initialize_nested_environment|run_GCTMRG!|run_nested_GCTMRG!' `
  test/nested_measurements.jl
```

Result: no matches.

## TDD evidence

All Julia execution was remote-only on `jkkong@172.23.26.248`, through
`julia_grassmann`, in:

```text
/home/jkkong/work/2026/0731/nested-exact-site-019fb340
```

Every amended test run used the 20 GB process-group guard.

### Amended validator RED

The exact tests and validator assertions were added before the validator.
Exact command:

```bash
cd /home/jkkong/work/2026/0731/nested-exact-site-019fb340
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/red-exact-site.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann focused_runtests.jl'
```

Result: exit 1, 30 passed, 1 failed, 1 errored, 63 seconds, peak RSS
950,156 KB, no memory kill.

The import warned that `_check_nested_operator_unit_cell` was undeclared.
Its valid call then errored with
`UndefVarError: _check_nested_operator_unit_cell not defined`; the
`@test_throws DimensionMismatch` assertion received that same
`UndefVarError`. This is the required missing-validator failure. The other
30 exact operator and four-spin-structure closure assertions had already
passed, and no CTMRG iteration appeared in the output.

### Amended exact-site GREEN

After adding only the pure validator and replacing the matrix overload's
inline size check:

```bash
cd /home/jkkong/work/2026/0731/nested-exact-site-019fb340
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/green-exact-site.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann focused_runtests.jl'
```

Result: exit 0, `32/32` passed, 61 seconds, peak RSS 887,344 KB, no
memory kill.

### Earlier parent-task RED/GREEN evidence

Before the exact-test amendment, the same production implementation was
developed test-first:

- missing scalar measurement RED:
  `UndefVarError: compute_nested_exp_site not defined`, exit 1, 56 seconds,
  peak RSS 955,092 KB;
- scalar/operator GREEN: `3/3`, exit 0, 59 seconds, peak RSS 959,256 KB;
- missing matrix overload RED: expected four-argument `MethodError`, exit 1,
  77 seconds, peak RSS 966,448 KB;
- after the overload, all 12 scalar/matrix/validation assertions passed.

Those finite-iteration fixtures were removed by the amendment. Their
`0.6693673563` versus `0.3040397724` comparison is obsolete evidence, not a
production defect. A guarded exact local factorization diagnostic had
already shown relative operator error `0.0`.

The interrupted diagnostic observer was checked on resume. Its process had
already exited normally (exit 0, 68 seconds, peak RSS 967,164 KB), so no
remote process group was terminated.

## Full guarded suite

Exact command:

```bash
cd /home/jkkong/work/2026/0731/nested-exact-site-019fb340
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/full-exact-site.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann server_runtests_offline.jl'
```

Result:

```text
GrassmannTensorNetworks | 1252 / 1252
Finished all tests in 10.1 minutes.
```

Guard summary: exit 0, duration 677 seconds, peak RSS 1,331,784 KB, no
memory kill.

The first local SSH observer timed out after 124 seconds. The original
remote guarded process continued and was observed to completion; no second
full suite was launched.

## Logs and memory

- Required amended local Markdown log:
  `D:\C 盘备份\Back up\Work_Save\coding\codex_server_logs\2026\0731\nested-exact-site_019fb340.md`
- Superseded preliminary local Markdown log:
  `D:\C 盘备份\Back up\Work_Save\coding\codex_server_logs\2026\0731\nested-one-site_019fb340.md`
- Amended remote logs:
  `/home/jkkong/work/2026/0731/nested-exact-site-019fb340/log/`

All reported peaks were below the 20 GB limit and no run was killed for
memory.

## Commit

```text
079874164141a027f843fb06a7182765bc7ea0ab
feat: measure nested one-site operators
```

The commit contains exactly the required six tracked files.

## Self-review

- `git diff --check` passed before staging.
- `git diff --cached --check` passed.
- `git diff HEAD^ HEAD --check` passed after commit.
- The staged file list contained exactly the six required paths.
- The committed diff is 225 insertions across those six files.
- SHA-256 hashes for all six local files matched the files tested in the
  remote exact-site workspace.
- The worktree was clean after commit.
- Production measurement code retains the existing scalar contraction
  interface and native nested placement correction.
- The matrix overload calls the pure validator before allocating output.
- The exact measurement test has no CTMRG construction or run reference.
- Exact focused and full guarded server suites pass.

## Concerns

No implementation concern remains. The only operational issue was the
non-terminal local SSH observer timeout during the full suite; the original
guarded process completed successfully and its final log is intact.
