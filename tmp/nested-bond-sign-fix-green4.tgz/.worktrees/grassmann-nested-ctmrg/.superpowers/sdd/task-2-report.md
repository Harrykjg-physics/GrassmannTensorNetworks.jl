# Task 2 Report

Status: `BLOCKED_AT_FORMULA`

## Outcome

The graded crossing and K/B/Y node structure was implemented test-first in
uncommitted forensic edits. Primitive tests are green, including the exact
odd-odd X sign and all required node sizes/arrows. The local K/Y/X/B closure
does not equal `reduced_tensor(A)` for either `Float64` or `ComplexF64`.

The user approved replacing the flawed formulas with a from-first-principles
sector-oracle derivation. Per that decision, no fourth production fix, commit,
or final acceptance-suite claim was made.

Full evidence:

- `.superpowers/sdd/task-2-sign-diagnostics.md`
- Local server log:
  `D:\C 盘备份\Back up\Work_Save\coding\codex_server_logs\2026\0730\nested-task2-019fb340.md`
- Copied remote logs:
  `D:\C 盘备份\Back up\Work_Save\coding\codex_server_logs\2026\0730\nested-task2-019fb340-server-log`

## Files left uncommitted

- `algorithms/Nested_CTMRG/nested_network.jl`
  - Adds `_graded_pair_sign`, `_nested_x`, `_bend_index`, `_nested_ket`,
    `_nested_bra`, `_physical_identity`, and `_nested_y`.
  - Preserves the formula set that passed primitive structure tests but failed
    exact closure, for forensic comparison with the sector oracle.
- `test/nested_network.jl`
  - Adds the test-only `global_sign=auto_sign` binding.
  - Adds graded crossing/node structure tests.
  - Adds exact real/complex local closure tests using the user-approved
    corrected internal bonds `(5,7) <-> (3,1)`.
- `.superpowers/sdd/task-2-sign-diagnostics.md`
- `.superpowers/sdd/task-2-report.md`

No Task 2 implementation commit exists. HEAD is the plan-correction commit
`2123122cbdfb8e3c99a574d1d19d46b3e008d325`.

## RED/GREEN evidence

All Julia execution was remote-only under:

```text
/home/jkkong/work/2026/0730/nested-task2-019fb340
```

with `PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin`,
`JULIA_PKG_OFFLINE=true`, `julia_grassmann`, an isolated harness, and the
20 GB memory guard.

Exact runner:

```bash
ssh -tt -p 22 jkkong@172.23.26.248 \
  'bash -i /home/jkkong/work/2026/0730/nested-task2-019fb340/nested-task2-019fb340-run.sh <phase>'
```

Valid primitive RED, phase `red-primitives-v3`:

```text
Nested layout             8/8 pass
Nested network wrapper    4/4 pass
Nested graded primitives  error: _nested_x not defined
exit_code: 1
peak_rss_kb: 606100
killed_for_memory: 0
```

Primitive GREEN, phase `green-primitives`:

```text
Nested layout             8/8 pass
Nested network wrapper    4/4 pass
Nested graded primitives 12/12 pass
exit_code: 0
peak_rss_kb: 719360
killed_for_memory: 0
```

Corrected local-factorization RED, phase
`red-factorization-corrected`:

```text
Nested layout             8/8 pass
Nested network wrapper    4/4 pass
Nested graded primitives 12/12 pass
Local nested factorization 0/2; Float64 and ComplexF64 both fail exact equality
exit_code: 1
peak_rss_kb: 858452
killed_for_memory: 0
```

The prior original-axis run failed earlier because `(3,6) <-> (3,1)` paired
equal arrow types. The user approved `(5,7) <-> (3,1)` in plan commit
`2123122`; that correction reaches a genuine numerical sign failure.

## Diagnostic result

For `Random.seed!(1234567)`,
`Dphys=2`, `Dphys_even=1`, `Dvir=2`, and a `1 x 1` complex cell:

- The updated plan permutation `(1,5,3,7,2,4,6,8)` is not sign-equivalent to
  `reduced_tensor`; nonzero ratios are not restricted to `±1`.
- Bra-first `(5,1,7,3,4,2,8,6)` is sign-equivalent entrywise but not equal.
- All 16 within-pair reversals fail for real and complex tensors.
- All K/B exchange toggles and all eight B bend-twist masks fail under direct
  and reduced-style external fusions.
- Applying the exact parity/permutation signs used by `reduced_tensor` during
  external fusion still fails.

The final residual after bra-first ordering and reduced-style external
fusions is:

```text
D =
    bL + kL + kR + kU
  + bL*kL + bL*bR + bL*kR + bL*bU + bL*kU + bL*bD
  + kR*bU
```

The candidate differs by `(-1)^D`. Here `b*` are bra virtual parities,
`k*` are ket virtual parities, and
`p = sum(b*) = sum(k*) (mod 2)`. Every seeded nonzero ratio is within
`1.11e-16` of `±1`.

## Self-review and concerns

- X parity blocks: confirmed odd-odd exactly `-1`; all other exchanges `+1`.
- Arrows: K/B/Y are `(:out,:in,:in,:out)`; corrected internal bonds join dual
  arrows.
- Every reorder, conjugation, contraction, bend, and diagnostic fusion uses
  native Grassmann operations with `sign_function=global_sign`.
- No PEPSKit/TensorKit dependency or dense production shortcut was added.
  Dense conversion was used only to diagnose entrywise ratios.
- Real and complex exact equality remains unsatisfied. The preserved formulas
  must not be merged or used by Task 3.
- The categorical reference/PDF does not determine the native block-basis
  isomorphism. A sector oracle is required before implementation resumes.

