# Task 5 Report: Exact Horizontal and Vertical Bond Measurements

## Status

Implemented the nearest-neighbor nested measurement interfaces in
`algorithms/Nested_CTMRG/measurements.jl` and exact, environment-free bond
tests in `test/nested_measurements.jl`.

The production interface remains environment based. The tests construct no
CTMRG environment and perform no CTMRG iteration.

## TDD RED

Remote workspace:
`/home/jkkong/work/2026/0731/nested-exact-bond-019fb340`

Guarded focused command:

```bash
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/red-exact-bond-missing2.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann focused_runtests.jl'
```

Genuine RED result:

- Exit code: `1`
- Result before the new bond test: `32` passed, `1` errored
- Exact failure: `UndefVarError: _operator_schmidt not defined in
  GrassmannTensorNetworks`
- Duration: `59 s`
- Peak RSS: `910,084 KB`
- Memory kill: no
- No CTMRG construction or iteration occurred.

Two earlier guarded RED attempts found line-breaking parse errors in the
literal brief snippets before reaching the missing production function:

- `red-exact-bond.log`: invalid line-broken `@test ... rtol/atol`, exit `1`,
  `67 s`, peak `916,504 KB`.
- `red-exact-bond-missing.log`: invalid line-broken `@test_throws`, exit `1`,
  `59 s`, peak `900,400 KB`.

Only test syntax was corrected before the genuine missing-function RED;
production remained untouched.

## Implementation

Implemented:

- `_check_nested_bond_operator` with source and neighbor bounds, physical
  dimensions, parity splits, arrows, and even-total-parity validation.
- `_operator_schmidt` with separate even/even and odd/odd SVD sectors.
- `_contract_horizontal_strip` and `_contract_vertical_strip` using the
  existing `left_move` and `up_move` primitives.
- `_contract_nested_hpatch3` and `_contract_nested_vpatch3`, retaining the
  intervening K or B tensor.
- Scalar and unit-cell matrix overloads for `compute_nested_exp_hbond` and
  `compute_nested_exp_vbond`.
- Exact rank-six reduced horizontal/vertical closures in tests only.

No MPO, new tensor type, alternate contraction API, or exact-contraction
production interface was added.

## Approved Graded-Sign Corrections

The original plan's dense ordinary permutation was inconsistent with its own
graded reconstruction assertion. Diagnostic evidence showed that the even
sector reconstructed correctly while the odd sector lost the braid sign.
The approved plan correction in `aee9a5f` builds the SVD matrix from:

```julia
convert(
    Array,
    permutedims(
        operator, (1, 3, 2, 4);
        sign_function=global_sign,
    ),
)
```

After this correction, reconstruction and all vertical comparisons passed,
leaving only the four horizontal odd-sector numerator/ratio pairs.

The sector diagnostic (`log/sector-diagnostic-graded.log`) established:

- even sector: nested equals reduced in both orientations;
- odd sector: nested equals reduced vertically;
- odd sector: horizontal nested equals minus horizontal reduced under every
  spin structure.

This is the single extra exchange of the two separated odd Y endpoints in
horizontal row order. The approved correction in `005534d` multiplies each
horizontal term by
`(-one(eltype(operator)))^tensor_parity(left_operator)`. The vertical path
is unchanged.

## Exact Raw Comparison Evidence

The guarded evidence run `log/raw-exact-bond-evidence.log` exited `0`, took
`81 s`, peaked at `904,156 KB`, and was not memory killed.

| Orientation | Twists `(x,y)` | Nested denominator | Reduced denominator | Nested numerator | Reduced numerator | Nested ratio | Reduced ratio |
|---|---:|---:|---:|---:|---:|---:|---:|
| H | `(false,false)` | 5.169257240470862 | 5.169257240470862 | -1.5362906932178404 | -1.5362906932178415 | -0.2971975705116779 | -0.2971975705116781 |
| V | `(false,false)` | 0.0494338107587981 | 0.04943381075879816 | -0.021492099066507914 | -0.021492099066508452 | -0.43476516854777997 | -0.43476516854779035 |
| H | `(true,false)` | 7.044550838475748 | 7.044550838475747 | 1.7380243682277068 | 1.7380243682277041 | 0.24671897585506938 | 0.24671897585506905 |
| V | `(true,false)` | 0.9528109630276135 | 0.9528109630276144 | -3.0934178862036825 | -3.0934178862036834 | -3.246622893983255 | -3.2466228939832527 |
| H | `(false,true)` | 0.007344122355719435 | 0.00734412235571992 | -0.021789542529541656 | -0.021789542529541878 | -2.9669362075064636 | -2.966936207506298 |
| V | `(false,true)` | 0.028387899968838063 | 0.028387899968838295 | -0.07352573060588832 | -0.07352573060588825 | -2.5900376810753496 | -2.590037681075326 |
| H | `(true,true)` | 0.0017941085718917171 | 0.0017941085718916477 | -0.0020618946991910747 | -0.0020618946991911857 | -1.149258596438789 | -1.1492585964388953 |
| V | `(true,true)` | 6.842751010840284 | 6.842751010840285 | -13.716219295271113 | -13.716219295271124 | -2.004489024011232 | -2.0044890240112334 |

All comparisons use `rtol=5e-12`, `atol=1e-12`. The bond numerators are
manifestly nonzero.

## Validation Coverage

The focused test covers:

- exact Schmidt reconstruction at `rtol=1e-12`, `atol=1e-12`;
- valid operator acceptance;
- out-of-bounds source rejection;
- physical-dimension mismatch rejection;
- physical parity-split mismatch rejection;
- arrow mismatch rejection;
- odd total operator parity rejection;
- horizontal and vertical denominator, numerator, and normalized value under
  all four spin structures;
- a nonzero bond-numerator assertion.

The implementation additionally validates the neighbor bound before any
decomposition.

## GREEN Verification

Focused command:

```bash
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/green-exact-bond-final.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann focused_runtests.jl'
```

Focused result:

- `64/64` passed
- Exit code: `0`
- Duration: `77 s`
- Peak RSS: `909,584 KB`
- Memory kill: no

Static scan:

```powershell
rg -n 'CTMRGEnv|initialize_nested_environment|run_GCTMRG!|run_nested_GCTMRG!' `
  test/nested_measurements.jl
```

Result: no matches.

Full suite command (run once):

```bash
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/full-exact-bond.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann server_runtests_offline.jl'
```

Full result:

- `1252/1252` passed
- Test time: `10m02.4s`
- Guard duration: `680 s`
- Exit code: `0`
- Peak RSS: `1,381,296 KB`
- Memory kill: no

All Julia execution occurred on `jkkong@172.23.26.248` through
`julia_grassmann`; Julia was never run locally.

## Commit

`8520371` — `feat: measure nested nearest-neighbor operators`

The commit contains exactly:

- `algorithms/Nested_CTMRG/measurements.jl`
- `test/nested_measurements.jl`

## Self-Review

- Scope is limited to the two required tracked files.
- Production remains environment based; exact closures are test-only.
- The Schmidt decomposition is parity separated and reconstructs the original
  operator with graded operations.
- Horizontal and vertical endpoint/source ordering matches the nested layout.
- Denominators are computed once from two physical identities and reused.
- Matrix overloads reject mismatched unit cells and return denominator/value
  matrices.
- No prohibited CTMRG construction or iteration appears in the measurement
  tests.
- No task-generated untracked files remain.
- `git diff --check` reports no whitespace errors (only Git's Windows line
  ending advisory).
- Independent read-only review found no Critical, Important, or Minor issues
  and assessed the change ready to merge.

## Concerns

No known correctness concerns remain. The two graded-sign plan corrections
were evidence driven, explicitly approved, and encoded in plan commits
`aee9a5f` and `005534d`.

## Reviewer Follow-Up: Every Bond Numerator Is Nonzero

The reviewer noted that `maximum(bond_numerators) > 1e-12` proved only one
of the eight horizontal/vertical spin-structure numerators was nonzero. The
test was strengthened to:

```julia
@test all(value -> value > 1e-12, bond_numerators)
```

Exact guarded command:

```bash
cd /home/jkkong/work/2026/0731/nested-exact-bond-019fb340
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/green-all-bond-numerators.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann focused_runtests.jl'
```

Result:

- `64/64` passed
- Exit code: `0`
- Test time: `1m06.3s`
- Guard duration: `77 s`
- Peak RSS: `912,120 KB`
- Memory kill: no

The static prohibited-CTMRG scan again returned no matches. Per instruction,
the full suite was not repeated for this assertion-only change.

Follow-up commit: `118e4db` —
`test: require every nested bond numerator nonzero`.
