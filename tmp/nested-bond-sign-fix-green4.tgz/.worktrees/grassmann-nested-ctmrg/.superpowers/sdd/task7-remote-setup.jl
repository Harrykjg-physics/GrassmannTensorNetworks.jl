using Pkg

const TASK_ROOT = "/home/jkkong/work/2026/0801/task7-nested-example-a13f/exp"
const EXAMPLE_ROOT = joinpath(
    TASK_ROOT, "examples", "Spinless_Fermion_2D_Square_AD_nested"
)

Pkg.activate(TASK_ROOT)
Pkg.instantiate()
Pkg.activate(EXAMPLE_ROOT)
Pkg.instantiate()

println("TASK7_SETUP_ACTIVE_PROJECT=", Base.active_project())
for package in ("GrassmannTensorNetworks", "HDF5", "Optim", "Zygote")
    println("TASK7_SETUP_PACKAGE_", package, "=", Base.find_package(package))
end
