# Task 1: Nested Layout, Wrapper, and Package Wiring

## Implementation

Implemented the Task 1 public data structures only:

- `NestedLayout` stores the source/nested dimensions and deterministic ket, y, x, and bra lattice coordinates.
- `NestedLayout(::Square_GPEPS)` derives the layout from `size(peps)`.
- `NestedNetwork` wraps rank-4 Grassmann tensor grids and delegates `size`, `axes`, and indexing.
- Package includes and exports make both types publicly available.
- No `nested_network` constructor or CTMRG adapter was added; those remain Task 3 work.

## Files

- Created `algorithms/Nested_CTMRG/nested_network.jl`
- Created `test/nested_network.jl`
- Updated `src/algorithms.jl`
- Updated `src/GrassmannTensorNetworks.jl`
- Updated `test/runtests.jl`
- Updated `test/server_runtests.jl`

## TDD evidence

### RED

The failing tests were added before production code. The server execution command was:

```bash
JULIA_PKG_OFFLINE=true ./run_with_memory_guard.sh --limit-gb 20 --log ../log/red-final.guard.log -- bash -ic 'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin; julia_grassmann --project=. test/server_runtests.jl'
```

This executes the required underlying command:

```bash
julia_grassmann --project=. test/server_runtests.jl
```

RED result: exit code `1`; `945` existing tests passed, while the new export assertions failed and `NestedLayout`/`NestedNetwork` each raised the expected `UndefVarError`. The guard reported `peak_rss_kb: 1435876`, `killed_for_memory: 0`, and `duration_seconds: 602`.

### GREEN

After the minimal implementation, the same guarded command was run with `green.guard.log`:

```bash
JULIA_PKG_OFFLINE=true ./run_with_memory_guard.sh --limit-gb 20 --log ../log/green.guard.log -- bash -ic 'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin; julia_grassmann --project=. test/server_runtests.jl'
```

GREEN result: exit code `0`.

```text
Test Summary:           | Pass  Total     Time
GrassmannTensorNetworks |  959    959  8m45.7s
Finished all tests in 8.77 minutes.
peak_rss_kb: 1447760
killed_for_memory: 0
```

All Julia execution used the isolated server workspace `/home/jkkong/work/2026/0730/nested-layout-task1/repo` through the `julia_grassmann` alias. Because DNS was unavailable, only the remote harness copy changed `TestExtras` from `0.1` to cached `0.3.2`; no repository dependency version changed.

The local server execution log is `D:\C 盘备份\Back up\Work_Save\coding\codex_server_logs\2026\0730\nested-layout-task1-019fb340.md`.

## Self-review

- Confirmed the coordinate formulas match the required 2×2 expansion exactly.
- Confirmed both test entry points include the nested test and symbol smoke checks.
- Confirmed package export and include order are valid (`Square_GPEPS` is defined before the new source is included).
- Confirmed `git diff --cached --check` was clean before committing.
- Confirmed the implementation does not add Task 3 constructors or CTMRG adapters.

## Commit

`6b753a1 feat: add nested CTMRG layout`

## Concerns

- The complete server suite takes about nine minutes. No correctness concerns remain from the verified Task 1 scope.
