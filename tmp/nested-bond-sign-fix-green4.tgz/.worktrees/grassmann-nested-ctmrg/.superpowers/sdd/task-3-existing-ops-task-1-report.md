# Task 3 Existing-Ops — Task 1 Report

Status: **DONE**

## Implementation

Added the universal native placement layer while preserving all raw
primitives:

- `_nested_input_north_twist(A)` applies the north-axis parity twist.
- `_nested_ket_for_network` and `_nested_bra_for_network` construct raw K/B
  nodes from the twisted input.
- `_nested_x_for_network` applies the existing placed-X correction plus the
  `(1, 3, 2, 4)` permutation sign; `_nested_y_for_network` applies the same
  placement permutation sign.
- `_nested_network_reduced_basis` applies parity signs on ordered axes
  `(1, 2, 4, 5)` for the corrected local factorization diagnostic.

The raw `_nested_ket`, `_nested_bra`, `_nested_x`, `_placed_nested_x`,
`_nested_y`, and `_nested_reduced_basis` remain unchanged.

## Files changed

- `algorithms/Nested_CTMRG/nested_network.jl`
- `test/nested_network.jl`

The test adds the prescribed helper imports, corrected K/Y/X/B tile
factorization, raw odd-odd X check, and minimal/mixed Float64/ComplexF64
closures.

## TDD evidence

### RED

```bash
cd /home/jkkong/work/2026/0731/nested-existing-ops-placement-019fb340
./run_with_memory_guard.sh --limit-gb 20 --log log/red-import.log -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann focused_runtests.jl'
```

Exit code 1, duration 81 seconds, peak RSS 927,956 KB, no memory kill.
Existing coverage produced 168 passing assertions; the three new assertions
then errored exclusively because `_nested_x_for_network` and
`_nested_ket_for_network` were undefined. This is the expected missing-
placement-helper RED condition.

### GREEN focused suite

```bash
cd /home/jkkong/work/2026/0731/nested-existing-ops-placement-019fb340
./run_with_memory_guard.sh --limit-gb 20 --log log/green.log -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann focused_runtests.jl'
```

Exit code 0, duration 77 seconds, peak RSS 856,332 KB, no memory kill.
All 170 focused assertions passed, including the new universal-placement
minimal and mixed-basis closures.

### Full suite

```bash
cd /home/jkkong/work/2026/0731/nested-existing-ops-placement-019fb340
./run_with_memory_guard.sh --limit-gb 20 --log log/full.log -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann src/test/server_runtests_offline.jl'
```

Exit code 0, duration 633 seconds, peak RSS 1,360,544 KB, no memory kill.
`GrassmannTensorNetworks | 1121 / 1121` passed in 9m18.3s.

## Server logs

- Local: `D:\C 盘备份\Back up\Work_Save\coding\codex_server_logs\2026\0731\nested-existing-ops-placement_019fb340.md`
- Remote: `/home/jkkong/work/2026/0731/nested-existing-ops-placement-019fb340/log/red-import.log`
- Remote: `/home/jkkong/work/2026/0731/nested-existing-ops-placement-019fb340/log/green.log`
- Remote: `/home/jkkong/work/2026/0731/nested-existing-ops-placement-019fb340/log/full.log`

## Commit

```text
9aa085ccab07cbfd4e5a50c102522978d82d15cd
fix: place native nested fermion signs
```

## Self-review

- `git diff --check` passed.
- The production diff contains only the exact five network-placement helpers
  from the task brief; raw primitives and existing basis map are untouched.
- The test diff contains only the prescribed placement regression helpers and
  assertions.
- Fresh focused and full guarded server suites pass.

## Concerns

None for the implementation. SSH was initially unavailable before the RED
run; after access was restored, all required guarded validation completed.
