### Task 4: Operator-Dressed Y and One-Site Measurements

**Files:**

- Create: `algorithms/Nested_CTMRG/measurements.jl`
- Create: `test/nested_measurements.jl`
- Modify: `src/algorithms.jl`
- Modify: `test/runtests.jl`
- Modify: `test/server_runtests.jl`
- Modify: `src/GrassmannTensorNetworks.jl`

**Interfaces:**

- Consumes: `NestedNetwork`, `_nested_y`, `_nested_y_for_network`, existing scalar
  `compute_exp_site(Tbulk, Timp, El, Er, Eu, Ed, Clu, Cru, Cld, Crd)`.
- Produces:
  - `nested_y_operator(nested, peps, site, operator)`
  - `compute_nested_exp_site(nested, peps, operator, env, site)`
  - `compute_nested_exp_site(nested, peps, operator_matrix, env)`

- [ ] **Step 1: Write failing identity and number-operator tests**

```julia
using Test
using Random
using GrassmannTensorNetworks

function physical_identity(::Type{T}=Float64) where {T}
    return Grassmann(Matrix{T}(I, 2, 2), (2, 2), (1, 1), (:out, :in))
end

@testset "Nested one-site measurements" begin
    peps = Square_GPEPS(2, 1, 2, 1, 1, Float64, false)
    nested = nested_network(peps)
    env = initialize_nested_environment(nested, 4)
    run_nested_GCTMRG!(nested, env, 4; ctmrg_iter=2, verbosity=0)

    denominator, identity_value =
        compute_nested_exp_site(nested, peps, physical_identity(), env, (1, 1))
    @test isfinite(real(denominator))
    @test identity_value ≈ 1 atol=1e-10

    number = n_site(SpinlessFermionModel(1.0, 1.0, 3.0))
    _, nested_number =
        compute_nested_exp_site(nested, peps, number, env, (1, 1))
    @test isfinite(real(nested_number))
end
```

The reduced-layer comparison is added in Step 4 with a separate environment.

- [ ] **Step 2: Run and confirm missing measurement failure**

Expected: FAIL with `UndefVarError: compute_nested_exp_site not defined`.

- [ ] **Step 3: Implement operator-dressed Y and scalar measurement**

Append to `src/algorithms.jl`:

```julia
include(joinpath(@__DIR__, "..", "algorithms", "Nested_CTMRG", "measurements.jl"))
```

Append to `src/GrassmannTensorNetworks.jl`:

```julia
export nested_y_operator
export compute_nested_exp_site, compute_nested_exp_hbond, compute_nested_exp_vbond
```

Create `algorithms/Nested_CTMRG/measurements.jl` with:

```julia
_source_site(site::CartesianIndex{2}) = site
_source_site(site::Tuple{Int, Int}) = CartesianIndex(site)

function _nested_y_operator_raw(
    nested::NestedNetwork,
    peps::Square_GPEPS,
    source::CartesianIndex{2},
    operator::Grassmann{T, 2},
) where {T}
    rows, cols = size(peps)
    east_source = CartesianIndex(source[1], Nmod(source[2] + 1, cols))
    north_source = CartesianIndex(Nmod(source[1] - 1, rows), source[2])
    east_ket = nested[nested.layout.ket_sites[east_source]]
    north_bra = nested[nested.layout.bra_sites[north_source]]
    raw = _nested_y(
        operator,
        size(east_ket)[1], even(east_ket)[1],
        size(north_bra)[4], even(north_bra)[4],
    )
    return _nested_y_for_network(raw)
end

function nested_y_operator(
    nested::NestedNetwork,
    peps::Square_GPEPS,
    site,
    operator::Grassmann{T, 2}) where {T}

    source = _source_site(site)
    checkbounds(Bool, peps.A, source) ||
        throw(ArgumentError("source site $source is outside the unit cell"))
    physical_size = size(peps.A[source])[1]
    physical_even = even(peps.A[source])[1]
    size(operator) == (physical_size, physical_size) ||
        throw(DimensionMismatch("operator physical dimensions do not match PEPS"))
    even(operator) == (physical_even, physical_even) ||
        throw(DimensionMismatch("operator physical parity split does not match PEPS"))
    index_type(operator) == (:out, :in) ||
        throw(ArgumentError("operator arrows must be (:out, :in)"))
    return _nested_y_operator_raw(nested, peps, source, operator)
end

function compute_nested_exp_site(
    nested::NestedNetwork,
    peps::Square_GPEPS,
    operator::Grassmann{<:Number, 2},
    env::CTMRGEnv,
    site)

    source = _source_site(site)
    ysite = nested.layout.y_sites[source]
    impurity = nested_y_operator(nested, peps, source, operator)
    return compute_exp_site(
        nested[ysite], impurity,
        env.El[ysite], env.Er[ysite], env.Eu[ysite], env.Ed[ysite],
        env.Clu[ysite], env.Cru[ysite], env.Cld[ysite], env.Crd[ysite],
    )
end
```

- [ ] **Step 4: Implement matrix overload and direct-layer comparison**

```julia
function compute_nested_exp_site(
    nested::NestedNetwork,
    peps::Square_GPEPS,
    operators::AbstractMatrix{<:Grassmann{Q, 2}},
    env::CTMRGEnv) where {Q}

    size(operators) == size(peps) ||
        throw(DimensionMismatch("operator and PEPS unit cells differ"))
    denominator = Matrix{promote_type(eltype(peps), Q)}(
        undef, size(peps)...
    )
    values = similar(denominator)
    for site in CartesianIndices(peps.A)
        denominator[site], values[site] =
            compute_nested_exp_site(nested, peps, operators[site], env, site)
    end
    return denominator, values
end
```

Create separate nested and reduced environments in the test, run each for
five iterations at `chi=8`, and require number expectations to agree to
`rtol=5e-3`:

```julia
Random.seed!(0x4e455354)
peps = Square_GPEPS(2, 1, 2, 1, 1, Float64, false)
number = n_site(SpinlessFermionModel(1.0, 1.0, 3.0))

nested = nested_network(peps)
nested_env = initialize_nested_environment(nested, 8)
run_nested_GCTMRG!(
    nested, nested_env, 8; ctmrg_iter=5, verbosity=0, save_iter=0
)
_, nested_number =
    compute_nested_exp_site(nested, peps, number, nested_env, (1, 1))

reduced_bulk = reduced_tensor.(peps.A)
reduced_impurity = reduced_tensor.(peps.A, Ref(number))
reduced_env = CTMRGEnv(reduced_bulk, 8, 4)
run_GCTMRG!(
    reduced_bulk, reduced_bulk, reduced_env, 8;
    ctmrg_iter=5, verbosity=0, save_iter=0,
)
_, reduced_number =
    compute_exp_site(reduced_bulk, reduced_impurity, reduced_env)
@test nested_number ≈ reduced_number[1, 1] rtol=5e-3
```

This is a cross-representation smoke tolerance, not the exact local
factorization tolerance.

- [ ] **Step 5: Run tests and commit**

```bash
git add algorithms/Nested_CTMRG/measurements.jl \
        src/algorithms.jl test/nested_measurements.jl \
        test/runtests.jl test/server_runtests.jl \
        src/GrassmannTensorNetworks.jl
git commit -m "feat: measure nested one-site operators"
```

---

