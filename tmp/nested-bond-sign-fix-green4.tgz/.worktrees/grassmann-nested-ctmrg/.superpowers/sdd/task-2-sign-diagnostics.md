# Task 2 Sign Diagnostics

Status: `BLOCKED_AT_FORMULA`

The primitive structure tests pass, but the proposed native K/Y/X/B translation
does not reproduce `reduced_tensor(A)` for either `Float64` or `ComplexF64`.
After multiple independent sign hypotheses failed, the user approved replacing
the formulas with a from-first-principles sector oracle. No further production
fix was attempted.

## Preserved worktree state

Baseline:

- Branch: `codex/grassmann-nested-ctmrg-implementation`
- HEAD: `2123122cbdfb8e3c99a574d1d19d46b3e008d325`
- Plan correction at HEAD: contract `kx` axes `(5, 7)` with `B` axes
  `(3, 1)`, then use the documented external permutation
  `(1, 5, 3, 7, 2, 4, 6, 8)`.

Forensic implementation edits are intentionally uncommitted:

- `algorithms/Nested_CTMRG/nested_network.jl`
- `test/nested_network.jl`

This diagnostic and `task-2-report.md` are also uncommitted handoff files.
There is no Task 2 implementation commit.

The source file currently adds:

```julia
function _graded_pair_sign(
    t::Grassmann{T, N, AT}, i::Int, j::Int
) where {T, N, AT}
    1 <= i <= N && 1 <= j <= N && i != j ||
        throw(ArgumentError("graded-pair indices must be distinct and in bounds"))
    blocks = Dict{NTuple{N, Int}, AT}()
    for (sector, block) in nonzero_pairs(t)
        blocks[sector] = (-1)^(sector[i] * sector[j]) .* block
    end
    return Grassmann(size(t), even(t), index_type(t), blocks)
end

function _nested_x(
    horizontal_size::Int,
    horizontal_even::Int,
    vertical_size::Int,
    vertical_even::Int,
    ::Type{T},
) where {T}
    dense = zeros(T, horizontal_size, horizontal_size, vertical_size, vertical_size)
    parity(index, even_dim) = index <= even_dim ? 0 : 1
    for h in 1:horizontal_size, v in 1:vertical_size
        dense[h, h, v, v] =
            (-one(T))^(parity(h, horizontal_even) * parity(v, vertical_even))
    end
    return Grassmann(
        dense,
        (horizontal_size, horizontal_size, vertical_size, vertical_size),
        (horizontal_even, horizontal_even, vertical_even, vertical_even),
        (:out, :in, :in, :out),
    )
end

function _bend_index(t::Grassmann, index::Int)
    return add_parity_sign(
        index_conjugation(t, index), index; sign_function=global_sign
    )
end

function _nested_ket_raw(A::Grassmann{T, 5}) where {T}
    signed = _graded_pair_sign(A, 1, 3)
    routed = permutedims(signed, (2, 1, 3, 4, 5); sign_function=global_sign)
    return fuse(routed, (2, 3); index_type_fused=:in)
end

function _nested_bra_raw(A::Grassmann{T, 5}) where {T}
    bra = conj(A; sign_function=global_sign)
    signed = _graded_pair_sign(bra, 1, 4)
    routed = permutedims(signed, (2, 3, 1, 4, 5); sign_function=global_sign)
    fused = fuse(routed, (3, 4); index_type_fused=:in)
    return foldl(_bend_index, (1, 2, 4); init=fused)
end

function _physical_identity(A::Grassmann{T, 5}) where {T}
    p, pe = size(A)[1], even(A)[1]
    return Grassmann(Matrix{T}(I, p, p), (p, p), (pe, pe), (:out, :in))
end

function _nested_y(
    operator::Grassmann{T, 2},
    horizontal_size::Int,
    horizontal_even::Int,
    vertical_size::Int,
    vertical_even::Int,
) where {T}
    crossing = _nested_x(
        horizontal_size, horizontal_even, vertical_size, vertical_even, T
    )
    product = contract(operator, crossing; sign_function=global_sign)
    routed = permutedims(
        product, (1, 3, 4, 5, 2, 6); sign_function=global_sign
    )
    west_fused = fuse(routed, (1, 2); index_type_fused=:out)
    return fuse(west_fused, (4, 5); index_type_fused=:out)
end
```

The test creates the intentionally absent runtime binding only in test scope:

```julia
@eval GrassmannTensorNetworks global global_sign = auto_sign
```

This is required on Julia 1.12; direct external assignment to an undeclared
module global is rejected. Production behavior was not changed.

## Confirmed primitive behavior

With `Dphys=2`, `Dphys_even=1`, `Dvir=2`, and a `1 x 1` cell:

- `_nested_x(1, 0, 1, 0, Float64)` has only the odd-odd sector and value
  `-1`.
- `_nested_x(2, 1, 2, 1, Float64)` has exchange signs `+1,+1,+1,-1`
  for even-even, odd-even, even-odd, odd-odd.
- `size(K) == (2, 4, 2, 2)`.
- `size(B) == (2, 2, 4, 2)`.
- `size(Y) == (4, 2, 2, 4)`.
- K, B, and Y all have arrows `(:out, :in, :in, :out)`.

Remote `green-primitives.log` records 24/24 total assertions passing:
8 layout, 4 wrapper, and 12 graded primitive assertions.

## Geometry trace and first corrected invariant

For node arrows `(:out, :in, :in, :out)`:

```text
ky = contract(K, Y, (2, 1))
ky arrows = (:out, :in, :out, :in, :in, :out)

kx = contract(ky, X, (3, 3))
kx arrows = (:out, :in, :in, :in, :out, :out, :in, :out)
```

The original proposed closure

```julia
contract(kx, B, ((3, 6), (3, 1)); sign_function=global_sign)
```

paired `(:in,:in)` and `(:out,:out)` and therefore could not be a valid
Grassmann contraction. The user approved the corrected internal bonds:

```julia
tile = contract(kx, B, ((5, 7), (3, 1)); sign_function=global_sign)
```

The semantic `kx` axes before closing B are:

```text
(K_left, K_up, Y_right, Y_up, Y_down, X_left, X_right, X_down)
```

Axes 5 and 7 are therefore `Y_down -> B_up` and `X_right -> B_left`.
After closing B, `tile` axes are:

```text
(K_left, K_up, Y_right, Y_up, X_left, X_down, B_right, B_down)
```

The updated plan groups those external directions with:

```julia
(1, 5, 3, 7, 2, 4, 6, 8)
```

This corrected closure contracts without arrow errors, but exact equality
still fails for both scalar types.

## Tested permutations and sign hypotheses

### 1. Updated plan order

Internal closure:

```julia
tile = contract(kx, B, ((5, 7), (3, 1)); sign_function=global_sign)
```

External order:

```julia
permutedims(tile, (1, 5, 3, 7, 2, 4, 6, 8); sign_function=global_sign)
```

The four adjacent pairs are fused directly as left, right, up, down.
`red-factorization-corrected.log` reports both the `Float64` and
`ComplexF64` exact comparisons failing.

For the seeded complex diagnostic, nonzero candidate/target ratios are not
restricted to `+1` or `-1`:

```text
max distance from either ±1 = 1.4077716642417364
```

Consequently, no parity sign can repair this within-pair ket/bra order.

### 2. All external pair reversals

The base endpoint pairs after the corrected internal closure are:

```julia
((1, 5), (3, 7), (2, 4), (6, 8))
```

All `2^4 = 16` choices of reversing these pairs were tested using
Grassmann-aware `permutedims` and native `fuse`.

Results:

```text
Float64 matches: []
ComplexF64 matches: []
```

The bra-first order

```julia
(5, 1, 7, 3, 4, 2, 8, 6)
```

does align the complex bilinears: every nonzero candidate/target ratio is
exactly `±1` to floating-point precision:

```text
max distance from either ±1 = 1.1102230246251565e-16
```

It still does not match because of a residual Koszul sign.

### 3. K/B exchange signs and B bend twists

The diagnostic kept all arrow conjugations but exhaustively toggled:

- K exchange: absent/present
  (`_graded_pair_sign(A, 1, 3)`).
- B exchange: absent/present
  (`_graded_pair_sign(conj(A), 1, 4)`).
- Each B bend parity twist on final B axes `(1, 2, 4)`: absent/present,
  while `index_conjugation` remained mandatory.

This is `2 * 2 * 2^3 = 32` node variants for each external-fusion mode.
All variants were tested for:

- updated plan order with direct fusions;
- bra-first order with direct fusions; and
- bra-first order with the exact `reduced_tensor` fusion signs below.

Results:

```text
plan matches: []
bra_first matches: []
reduced_fusions matches: []
```

### 4. Exact reduced-tensor external fusion isomorphisms

The following sequence was tested without weakening equality:

```julia
ordered = permutedims(
    tile, (5, 1, 7, 3, 4, 2, 8, 6); sign_function=global_sign
)
ordered = add_parity_sign(ordered, 1; sign_function=global_sign)
left = fuse(ordered, (1, 2); index_type_fused=:out)
left = add_perm_sign(
    left, (1, 3, 2, 4, 5, 6, 7); sign_function=global_sign
)
right = fuse(left, (2, 3); index_type_fused=:in)
right = add_perm_sign(
    right, (1, 2, 4, 3, 5, 6); sign_function=global_sign
)
up = fuse(right, (3, 4); index_type_fused=:in)
up = add_parity_sign(up, 4; sign_function=global_sign)
candidate = fuse(up, (4, 5); index_type_fused=:out)
```

The candidate remains sign-equivalent entrywise but not equal:

```text
bra-first with reduced-style fusions matches: false
max distance from either ±1 = 1.1102230246251565e-16
```

## Residual GF(2) sign polynomials

Variable definitions:

- `bL,bR,bU,bD`: parities of the conjugate-bra virtual left, right, up,
  and down indices.
- `kL,kR,kU,kD`: parities of the un-conjugated ket virtual left, right,
  up, and down indices.
- For the even PEPS tensor and the physical-identity contraction, the shared
  physical parity obeys
  `p = bL+bR+bU+bD = kL+kR+kU+kD (mod 2)`.
- The fitted fused-index order is `(bra, ket)` in each external direction.

For bra-first external order and direct fusions, the candidate differs from
`reduced_tensor` by `(-1)^D`, where one valid representation is:

```text
D =
    kL + kR + kU + bD
  + bL*kL + bL*bR + bL*kR + bL*bU + bL*kU + bL*bD
  + bR*kR + kR*bU + bU*kU
```

After applying the exact reduced-style external fusion signs, the residual is:

```text
D_reduced_fusions =
    bL + kL + kR + kU
  + bL*kL + bL*bR + bL*kR + bL*bU + bL*kU + bL*bD
  + kR*bU
```

The GF(2) fit uses all 128 nonzero parity-compatible entries of the
`Dphys=Dvir=2`, even-dimension-one complex tensor. The maximum numerical
distance of every fitted ratio from `±1` is `1.11e-16`.

## Reference and PDF mapping assumptions

Sources:

- Reference implementation:
  `D:\C 盘备份\Back up\Work_Save\coding\VS files\AI optimized Project\PEPSKit_nesting\src\network.jl`
- Derivation:
  `D:\C 盘备份\Back up\Work_Save\latex file\2026\0730_Nested fTN\main.pdf`,
  especially Sections 6-9 and Figures 7-12.

The translation used these assumptions:

1. Native `Square_GPEPS` stores
   `(physical,left,right,up,down)` with arrows
   `(:out,:out,:in,:in,:out)`.
2. The reference writes `A[p; n e s w]` and PFTensors as
   `T[w s; n e]`.
3. Reference K is `K[w s; n pe]`: it transports the un-conjugated physical
   leg and east virtual leg eastward. In native CTMRG direction order this
   was translated to `(w,pe,n,s)`.
4. Reference B is `B[w s; pn e]`: it transports conjugated physical and
   north legs northward. In native direction order this was translated to
   `(w,e,pn,s)`.
5. X crosses K's south route with B's west route. Y crosses K's east route
   with B's north route and closes the physical identity.
6. The 2 x 2 local placement is K/Y over X/B under native matrix row/column
   interpretation.
7. The required native node order is `(left,right,up,down)` with arrows
   `(:out,:in,:in,:out)`.
8. `_nested_x` was kept as the required pure graded exchange: odd-odd is
   exactly `-1`, all other exchanges are `+1`. The reference separately
   applies `twist(TensorMap(x), 1)` during assembly; no unproved native
   analogue was folded into `_nested_x`.
9. Native B arrow changes were represented by
   `index_conjugation` plus the parity twist from `add_parity_sign`.
10. Native Y fusion was represented by Grassmann direct product,
    `permutedims(...; sign_function=global_sign)`, and native `fuse`.

The PDF establishes the categorical identity but does not specify the native
Grassmann block-basis isomorphism. The failed residual shows that assumptions
8-10, or another categorical-to-native routing convention, cannot be accepted
without a sector-level derivation.

## Reproduction environment and commands

Remote workspace:

```text
/home/jkkong/work/2026/0730/nested-task2-019fb340
```

Remote repository copy:

```text
/home/jkkong/work/2026/0730/nested-task2-019fb340/repo
```

Isolated harness:

```text
/home/jkkong/work/2026/0730/nested-task2-019fb340/harness
```

The harness activates its own project and develops the remote repository copy.
`JULIA_PKG_OFFLINE=true` was used. No repository dependency version was
changed, and TestExtras was not needed. Julia ran only through the interactive
alias `julia_grassmann` on Julia 1.12.6.

The test runner command was:

```bash
ssh -tt -p 22 jkkong@172.23.26.248 \
  'bash -i /home/jkkong/work/2026/0730/nested-task2-019fb340/nested-task2-019fb340-run.sh <phase>'
```

The runner executes:

```bash
export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin
export JULIA_PKG_OFFLINE=true
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log "log/${phase}.log" \
  -- bash -ic \
  "export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin; \
   export JULIA_PKG_OFFLINE=true; \
   julia_grassmann \
   /home/jkkong/work/2026/0730/nested-task2-019fb340/task2_runtests.jl"
```

Diagnostic runners use the same guard and environment:

```bash
bash -i /home/jkkong/work/2026/0730/nested-task2-019fb340/pair_order.sh
bash -i /home/jkkong/work/2026/0730/nested-task2-019fb340/sign_search.sh
bash -i /home/jkkong/work/2026/0730/nested-task2-019fb340/sign_fit.sh
```

Fixed diagnostic parameters:

- `Random.seed!(1234567)`.
- `Dphys=2`, `Dphys_even=1`, `Dvir=2`, `Lx=1`, `Ly=1`.
- Pair-order diagnostic: both `Float64` and `ComplexF64`.
- Sign-search and GF(2) diagnostics: `ComplexF64`.
- Main factorization test: both `Float64` and `ComplexF64`; the supplied test
  itself is unseeded, but the failure was reduced to the seeded diagnostic.

Server logs are retained at:

```text
/home/jkkong/work/2026/0730/nested-task2-019fb340/log
```

and copied locally to:

```text
D:\C 盘备份\Back up\Work_Save\coding\codex_server_logs\2026\0730\nested-task2-019fb340-server-log
```

Important logs:

- `red-primitives-v3.log`: valid missing-function RED; exit 1.
- `green-primitives.log`: primitive GREEN, 24/24 assertions; exit 0.
- `green-factorization-v1.log`: original axes pair equal arrow types; exit 1.
- `red-factorization-corrected.log`: corrected topology, exact real and
  complex comparisons both fail; exit 1.
- `diagnose-pair-order.log`: all 16 pair reversals fail; exit 0 diagnostic.
- `diagnose-sign-search.log`: all K/B exchange/bend variants fail; exit 0
  diagnostic.
- `diagnose-sign-fit.log`: seeded ratio and GF(2) evidence; exit 0 diagnostic.

No run exceeded the 20 GB guard. The largest recorded peak was 893,628 KiB.

Excluded setup failures:

- `red-primitives.log`: wrong uploaded harness filename.
- `red-primitives-v2.log`: Julia 1.12 rejected direct assignment to an
  undeclared module global.
- `red-factorization.log`: supplied test used unsupported `size(A, dim)`.
- `red-factorization-v2.log`: `_physical_identity` repeated the same
  unsupported size call; this led to the preserved `size(A)[1]` correction.

## Required next step

Build the replacement from a sector oracle rather than another sign toggle:

1. Enumerate every parity-compatible basis sector for the minimal
   `Dphys=Dvir=2`, even-dimension-one tensor.
2. Derive each K/Y/X/B block coefficient and fused-basis position directly
   from the native `reduced_tensor` contraction.
3. Solve and document the categorical-to-native basis isomorphisms for K,
   B, X, Y, and external fusions.
4. Generalize the resulting sector formula to arbitrary even/odd
   multiplicities without dense shortcuts.
5. Re-run the exact `Float64` and `ComplexF64` closure before replacing the
   preserved forensic formulas.

