using Pkg

const GTN_ROOT = normpath(joinpath(@__DIR__, "../.."))
Pkg.activate(GTN_ROOT)
Pkg.instantiate()
const EXAMPLE_ROOT = joinpath(
    GTN_ROOT, "examples", "Spinless_Fermion_2D_Square_AD_nested"
)
Pkg.activate(EXAMPLE_ROOT)
Pkg.instantiate()
GTN_ROOT in LOAD_PATH || push!(LOAD_PATH, GTN_ROOT)

using GrassmannTensorNetworks
using LinearAlgebra
using Random

include(joinpath(
    GTN_ROOT,
    "examples",
    "Spinless_Fermion_2D_Square_AD_nested",
    "Spinless_Fermion_2D_Square_AD_nested.jl",
))

@eval GrassmannTensorNetworks global global_sign = auto_sign

const D = 2
const LX = 2
const LY = 2
const SEED = 1234
const CHI = parse(Int, ARGS[1])
const AVERAGE_TRUNC = length(ARGS) < 2 ? true : parse(Bool, ARGS[2])
const DAMPING = length(ARGS) < 3 ? 0.0 : parse(Float64, ARGS[3])
const PARAMETER_COUNT = square_gpeps_parameter_count(2, 1, D, LX, LY)

Random.seed!(SEED)
const PARAMS = normalized_params(randn(PARAMETER_COUNT))
const PEPS = Square_GPEPS(2, 1, D, LX, LY, PARAMS, false)
const NESTED = nested_network(PEPS)
const HAMILTONIAN = nn_bond(SpinlessFermionModel(1.0, 1.0, 3.0))

function acceptance_seeded_environment()
    Random.seed!(SEED)
    normalized_params(randn(PARAMETER_COUNT))
    return initialize_nested_environment(NESTED, CHI)
end

finite_number(z) = isfinite(real(z)) && isfinite(imag(z))

function environment_norms(env)
    grids = (
        El=env.El, Er=env.Er, Eu=env.Eu, Ed=env.Ed,
        Clu=env.Clu, Cru=env.Cru, Cld=env.Cld, Crd=env.Crd,
    )
    values = map(grid -> maximum(norm, grid), grids)
    return merge(values, (maximum=maximum(values),))
end

function environment_distance(left, right)
    left_grids = (
        left.El, left.Er, left.Eu, left.Ed,
        left.Clu, left.Cru, left.Cld, left.Crd,
    )
    right_grids = (
        right.El, right.Er, right.Eu, right.Ed,
        right.Clu, right.Cru, right.Cld, right.Crd,
    )
    absolute = maximum(
        maximum(norm(a - b) for (a, b) in zip(lgrid, rgrid))
        for (lgrid, rgrid) in zip(left_grids, right_grids)
    )
    scale = maximum(
        maximum(norm, grid) for grid in (left_grids..., right_grids...)
    )
    return (absolute=absolute, relative=absolute / max(scale, eps(Float64)))
end

function damp_environment!(env, old, damping)
    for name in (:El, :Er, :Eu, :Ed, :Clu, :Cru, :Cld, :Crd)
        target = getfield(env, name)
        source = getfield(old, name)
        for site in eachindex(target)
            mixed = (1 - damping) * source[site] + damping * target[site]
            scale = maximum(abs(mixed))
            target[site] = scale > eps(Float64) ? mixed / scale : mixed
        end
    end
    return env
end

function snapshot(label, iteration, env)
    horizontal = NamedTuple[]
    vertical = NamedTuple[]
    energy = 0.0
    for site in CartesianIndices(PEPS.A)
        hden, hvalue = compute_nested_exp_hbond(
            NESTED, PEPS, HAMILTONIAN, env, site
        )
        vden, vvalue = compute_nested_exp_vbond(
            NESTED, PEPS, HAMILTONIAN, env, site
        )
        hz = GrassmannTensorNetworks._nested_scalar_or_zero(hden)
        vz = GrassmannTensorNetworks._nested_scalar_or_zero(vden)
        push!(horizontal, (
            site=Tuple(site), value=hvalue, denominator=hz,
            denominator_abs=abs(hz), denominator_phase=angle(hz),
            denominator_finite=finite_number(hz), value_finite=finite_number(hvalue),
        ))
        push!(vertical, (
            site=Tuple(site), value=vvalue, denominator=vz,
            denominator_abs=abs(vz), denominator_phase=angle(vz),
            denominator_finite=finite_number(vz), value_finite=finite_number(vvalue),
        ))
        energy += real(hvalue + vvalue)
    end
    record = (
        chi=CHI, average_trunc=AVERAGE_TRUNC,
        label=label, iteration=iteration,
        energy=energy / length(PEPS.A),
        horizontal=horizontal, vertical=vertical,
        environment_norms=environment_norms(env),
    )
    println("DIAG_RECORD=", repr(record))
    flush(stdout)
    return record
end

println("DIAG_PARAMS=", repr((
    seed=SEED, count=PARAMETER_COUNT, norm=norm(PARAMS),
    checksum=sum(i * PARAMS[i] for i in eachindex(PARAMS)),
    first8=PARAMS[1:min(8, end)],
    average_trunc=AVERAGE_TRUNC, damping=DAMPING,
)))

env = acceptance_seeded_environment()
snapshot(:initial, 0, env)
env20 = Ref{Any}(nothing)
records = Dict{Int, Any}()
for iteration in 1:40
    old = DAMPING > 0 ? deepcopy(env) : nothing
    run_nested_GCTMRG!(
        NESTED, env, CHI;
        ctmrg_iter=1, ctmrg_tol=0.0, average_trunc=AVERAGE_TRUNC,
        verbosity=0, save_iter=0,
    )
    DAMPING > 0 && damp_environment!(env, old, DAMPING)
    if iteration <= 20 || iteration in (25, 30, 40)
        records[iteration] = snapshot(:reuse_trajectory, iteration, env)
    end
    iteration == 20 && (env20[] = deepcopy(env))
end

stable_hint = maximum((
    abs(records[40].energy - records[30].energy),
    abs(records[30].energy - records[25].energy),
)) < 0.1
println("DIAG_STABLE_HINT=", repr((
    chi=CHI, average_trunc=AVERAGE_TRUNC, stable_hint=stable_hint,
    energy25=records[25].energy, energy30=records[30].energy,
    energy40=records[40].energy,
)))
if !AVERAGE_TRUNC && stable_hint
    for iteration in 41:80
        run_nested_GCTMRG!(
            NESTED, env, CHI;
            ctmrg_iter=1, ctmrg_tol=0.0,
            average_trunc=AVERAGE_TRUNC, verbosity=0, save_iter=0,
        )
        DAMPING > 0 && error("damping extension requires old env capture")
        iteration in (60, 80) &&
            snapshot(:stable_extension, iteration, env)
    end
end

println("DIAG_FRESH20_BEGIN chi=", CHI)
fresh = acceptance_seeded_environment()
if DAMPING > 0
    for _ in 1:20
        old = deepcopy(fresh)
        run_nested_GCTMRG!(
            NESTED, fresh, CHI;
            ctmrg_iter=1, ctmrg_tol=0.0,
            average_trunc=AVERAGE_TRUNC, verbosity=0, save_iter=0,
        )
        damp_environment!(fresh, old, DAMPING)
    end
else
    run_nested_GCTMRG!(
        NESTED, fresh, CHI;
        ctmrg_iter=20, ctmrg_tol=0.0, average_trunc=AVERAGE_TRUNC,
        verbosity=0, save_iter=0,
    )
end
fresh_record = snapshot(:fresh20, 20, fresh)
println("DIAG_FRESH20_COMPARISON=", repr((
    chi=CHI,
    energy_repeated1=snapshot(
        :repeat1_reference20, 20, env20[]
    ).energy,
    energy_fresh20=fresh_record.energy,
    environment_distance=environment_distance(env20[], fresh),
)))
println("DIAG_DONE chi=", CHI)
