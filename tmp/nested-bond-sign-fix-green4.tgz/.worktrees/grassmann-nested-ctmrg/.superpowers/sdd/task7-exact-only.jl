using Test

const TASK_ROOT = "/home/jkkong/work/2026/0801/task7-nested-example-a13f/exp"
TASK_ROOT in LOAD_PATH || pushfirst!(LOAD_PATH, TASK_ROOT)

include(joinpath(
    TASK_ROOT,
    "examples",
    "Spinless_Fermion_2D_Square_AD_nested",
    "Spinless_Fermion_2D_Square_AD_nested.jl",
))

@testset "Nested spinless exact energy focused" begin
    @test spinless_exact_energy(1.0, 1.0, 3.0; nk=512) ≈
        -6.170521774015 atol=2e-6
    @test_throws ArgumentError spinless_exact_energy(
        1.0, 1.0, 3.0; nk=0
    )
end
