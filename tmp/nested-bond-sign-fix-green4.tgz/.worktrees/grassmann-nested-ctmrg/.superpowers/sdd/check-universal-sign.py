from itertools import product

OUT, IN = 0, 1
TYPES = (OUT, IN, IN, OUT)


def xor(*polys):
    out = set()
    for poly in polys:
        out.symmetric_difference_update(poly)
    return out


def lin(*forms):
    value = 0
    for form in forms:
        value ^= form
    return value


def mul(a, b):
    out = set()
    for i in range(a.bit_length()):
        if not ((a >> i) & 1):
            continue
        for j in range(b.bit_length()):
            if (b >> j) & 1:
                monomial = (1 << i) | (1 << j)
                if monomial in out:
                    out.remove(monomial)
                else:
                    out.add(monomial)
    return out


def linear_poly(a):
    return {1 << i for i in range(a.bit_length()) if (a >> i) & 1}


def permutation_sign(q, dst):
    positions = list(range(len(q)))
    values = list(q)
    phase = set()
    for wanted in dst:
        pos = positions.index(wanted)
        phase = xor(phase, mul(lin(*values[:pos]), values[pos]))
        positions.pop(pos)
        values.pop(pos)
    return phase


def permute(tensor, dst):
    q, arrows, phase = tensor
    return (
        [q[i] for i in dst],
        [arrows[i] for i in dst],
        xor(phase, permutation_sign(q, dst)),
    )


def pair_sign(q, first, second, first_arrow, second_arrow):
    assert first_arrow != second_arrow
    start = first + 1 if first_arrow == IN else first
    if start > second - 1:
        return set()
    return mul(lin(*q[start:second]), q[second])


def contract(first, second, first_inds, second_inds, dst=None):
    q1, arrows1, phase1 = first
    q2, arrows2, phase2 = second
    labels = [(0, i) for i in range(len(q1))] + [
        (1, i) for i in range(len(q2))
    ]
    q = q1 + q2
    phase = xor(phase1, phase2)
    for original_first, original_second in zip(first_inds, second_inds):
        i = labels.index((0, original_first))
        j = labels.index((1, original_second))
        phase = xor(
            phase,
            pair_sign(
                q,
                i,
                j,
                arrows1[original_first],
                arrows2[original_second],
            ),
        )
        for index in sorted((i, j), reverse=True):
            labels.pop(index)
            q.pop(index)
    open1 = [i for i in range(len(q1)) if i not in first_inds]
    open2 = [i for i in range(len(q2)) if i not in second_inds]
    q = [q1[i] for i in open1] + [q2[i] for i in open2]
    arrows = [arrows1[i] for i in open1] + [arrows2[i] for i in open2]
    if dst is None:
        dst = list(range(len(q)))
    return permute((q, arrows, phase), dst)


def trace(tensor, first_inds, second_inds, pbc):
    q, arrows, phase = tensor
    labels = list(range(len(q)))
    values = list(q)
    for original_first, original_second in zip(first_inds, second_inds):
        i = labels.index(original_first)
        j = labels.index(original_second)
        phase = xor(
            phase,
            pair_sign(
                values,
                i,
                j,
                arrows[original_first],
                arrows[original_second],
            ),
        )
        for index in sorted((i, j), reverse=True):
            labels.pop(index)
            values.pop(index)
    for original_first, is_periodic in zip(first_inds, pbc):
        if not is_periodic:
            phase = xor(phase, linear_poly(q[original_first]))
    return values, [arrows[i] for i in labels], phase


def close_row(row, twist_x):
    columns = len(row)
    current = permute(row[0], [0, 2, 3, 1])
    for column in range(1, columns):
        j = column
        rank = 2 * j + 2
        dst = (
            [0]
            + list(range(1, j + 1))
            + [2 * j + 2]
            + list(range(j + 1, 2 * j + 1))
            + [2 * j + 3, 2 * j + 1]
        )
        current = contract(current, row[column], [rank - 1], [0], dst)
    return trace(current, [0], [2 * columns + 1], [not twist_x])


def torus(matrix, twist_x, twist_y):
    columns = len(matrix[0])
    row_tensors = [close_row(row, twist_x) for row in matrix]
    current = row_tensors[0]
    for row_tensor in row_tensors[1:]:
        current = contract(
            current,
            row_tensor,
            list(range(columns, 2 * columns)),
            list(range(columns)),
        )
    return trace(
        current,
        list(range(columns)),
        list(range(columns, 2 * columns)),
        [not twist_y] * columns,
    )[2]


def free_edge_forms(rows, columns):
    edge_count = 4 * rows * columns
    constraints = []

    def raw(kind, row, column):
        return 1 << (
            kind * rows * columns + row * columns + column
        )

    for row, column in product(range(rows), range(columns)):
        constraints.append(
            raw(0, row, (column - 1) % columns)
            ^ raw(0, row, column)
            ^ raw(1, (row - 1) % rows, column)
            ^ raw(1, row, column)
            ^ raw(2, row, (column - 1) % columns)
            ^ raw(2, row, column)
            ^ raw(3, (row - 1) % rows, column)
            ^ raw(3, row, column)
        )

    rows_reduced = []
    for equation in constraints:
        value = equation
        for pivot, row_value in rows_reduced:
            if (value >> pivot) & 1:
                value ^= row_value
        if value:
            pivot = value.bit_length() - 1
            rows_reduced.append((pivot, value))
            rows_reduced.sort(reverse=True)

    for index, (pivot, value) in enumerate(rows_reduced):
        for other in range(len(rows_reduced)):
            if other != index and ((rows_reduced[other][1] >> pivot) & 1):
                other_pivot, other_value = rows_reduced[other]
                rows_reduced[other] = (other_pivot, other_value ^ value)

    pivot_rows = {pivot: value for pivot, value in rows_reduced}
    free = [i for i in range(edge_count) if i not in pivot_rows]
    free_position = {original: index for index, original in enumerate(free)}
    forms = []
    for original in range(edge_count):
        if original in free_position:
            forms.append(1 << free_position[original])
        else:
            expression = pivot_rows[original] ^ (1 << original)
            form = 0
            for free_original in free:
                if (expression >> free_original) & 1:
                    form ^= 1 << free_position[free_original]
            forms.append(form)
    return forms, len(rows_reduced)


def networks(rows, columns, correction):
    forms, constraint_rank = free_edge_forms(rows, columns)

    def edge(kind, row, column):
        return forms[
            kind * rows * columns + row * columns + column
        ]

    raw = [[None] * (2 * columns) for _ in range(2 * rows)]
    reduced = [[None] * columns for _ in range(rows)]
    for row, column in product(range(rows), range(columns)):
        kL = edge(0, row, (column - 1) % columns)
        kR = edge(0, row, column)
        kU = edge(1, (row - 1) % rows, column)
        kD = edge(1, row, column)
        bL = edge(2, row, (column - 1) % columns)
        bR = edge(2, row, column)
        bU = edge(3, (row - 1) % rows, column)
        bD = edge(3, row, column)
        p = lin(kL, kR, kU, kD)
        kroute = lin(p, kR)
        broute = lin(p, bU)

        phi_k = mul(p, lin(kL, kR))
        phi_b = xor(
            linear_poly(lin(bL, bR)),
            mul(bL, bR),
            mul(bL, bU),
            mul(bR, bU),
        )
        phi_x = xor(linear_poly(bL), mul(bL, kD))
        phi_y = xor(mul(p, bU), mul(kR, bU))

        if correction in ("simple", "universal"):
            phi_x = xor(phi_x, mul(bL, kD))
            phi_y = xor(phi_y, mul(kR, bU))
        if correction == "universal":
            phi_k = xor(phi_k, linear_poly(kU))
            phi_b = xor(phi_b, linear_poly(bU))

        raw[2 * row][2 * column] = (
            [kL, kroute, kU, kD],
            list(TYPES),
            phi_k,
        )
        raw[2 * row + 1][2 * column + 1] = (
            [bL, bR, broute, bD],
            list(TYPES),
            phi_b,
        )
        raw[2 * row + 1][2 * column] = (
            [bL, bL, kD, kD],
            list(TYPES),
            phi_x,
        )
        raw[2 * row][2 * column + 1] = (
            [kroute, kR, bU, broute],
            list(TYPES),
            phi_y,
        )

        phi_reduced = xor(
            linear_poly(lin(bL, bD)),
            mul(bL, bR),
            mul(bL, bU),
            mul(bL, bD),
            mul(kL, bR),
            mul(kL, bU),
            mul(kL, bD),
            mul(bR, kR),
            mul(bR, bU),
            mul(bR, bD),
            mul(kR, bU),
            mul(kR, bD),
            mul(bU, kU),
            mul(bU, bD),
            mul(kU, bD),
        )
        reduced[row][column] = (
            [
                lin(bL, kL),
                lin(bR, kR),
                lin(bU, kU),
                lin(bD, kD),
            ],
            list(TYPES),
            phi_reduced,
        )
    return raw, reduced, constraint_rank


for rows, columns in product(range(1, 4), repeat=2):
    line = [f"{rows}x{columns}"]
    for correction in ("none", "simple", "universal"):
        raw, reduced, rank = networks(rows, columns, correction)
        residuals = []
        for twist_x, twist_y in (
            (False, False),
            (True, False),
            (False, True),
            (True, True),
        ):
            residuals.append(
                len(
                    xor(
                        torus(raw, twist_x, twist_y),
                        torus(reduced, twist_x, twist_y),
                    )
                )
            )
        line.append(f"{correction}={residuals}")
    line.append(f"constraint_rank={rank}")
    print(" ".join(line))
