# Task 2 Implementation Report

Status: **DONE**

Commit:

```text
b1dcbee4e50ed1790c3b02df973ba7adb51344f6
feat: construct graded nested tensor nodes
Codex <codex@openai.com>
```

Tracked scope:

- `algorithms/Nested_CTMRG/nested_network.jl`
- `test/nested_network.jl`

## Implemented

- `_graded_pair_sign`
- sector-native raw `_nested_x` with exact odd-odd `-1`
- `_placed_nested_x` with the west-leg parity twist
- graded `_nested_ket` / `_nested_bra` and explicit bent-index twists
- `_physical_identity`
- `_nested_y` with horizontal/vertical braid roles kept distinct
- `_nested_reduced_basis`, using the proven native braid
  `(2,3,5,4,6,7,1,8)` and twists on bra-first axes `(2,4,6)`

No production path converts a tensor to dense storage or calls
`reduced_tensor` as a shortcut. Dense conversion is confined to test
inspection.

## TDD evidence

RED:

```text
phase: red-missing-basis
expected failure:
  UndefVarError: `_placed_nested_x` not defined in `Main`
  imported `_nested_reduced_basis` was also undeclared
earlier primitive assertions: 24/24 passed
exit_code: 1
peak_rss_kb: 914456
killed_for_memory: 0
```

GREEN focused command:

```bash
ssh -p 22 jkkong@172.23.26.248 \
  'bash -i /home/jkkong/work/2026/0731/nested-task2-native-basis-019fb340/run_task2_native.sh green-focused'
```

The runner used:

```bash
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/green-focused.log \
  -- bash -ic \
  "export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin; \
   export JULIA_PKG_OFFLINE=true; \
   julia_grassmann /home/jkkong/work/2026/0731/nested-task2-native-basis-019fb340/focused_runtests.jl"
```

Focused result:

```text
159/159 assertions passed
duration_seconds: 69
exit_code: 0
peak_rss_kb: 850460
killed_for_memory: 0
```

Coverage includes:

- raw and placed X parity signs
- K/B/Y shapes and arrow types
- exact minimal Float64 and ComplexF64 local factorization
- one assertion for each of all 128 compatible parity sectors
- mixed-multiplicity anisotropic dimensions
  `(3,3,4,3,4)` with evens `(2,1,3,2,1)`

## Full server verification

Command:

```bash
ssh -tt -p 22 jkkong@172.23.26.248 \
  'bash -i /home/jkkong/work/2026/0731/nested-task2-native-basis-019fb340/run_task2_native.sh full'
```

The offline server harness differs only by requesting cached
`TestExtras v0.3.2`; repository dependency constraints were not changed.

Result:

```text
GrassmannTensorNetworks | 1106 passed / 1106 total
test time: 9m12.5s
guarded duration_seconds: 623
exit_code: 0
peak_rss_kb: 1395372
killed_for_memory: 0
```

Local log:

```text
D:\C 盘备份\Back up\Work_Save\coding\codex_server_logs\2026\0731\nested-task2-native-basis-019fb340.md
```

Remote logs:

```text
/home/jkkong/work/2026/0731/nested-task2-native-basis-019fb340/log
```

## Remaining risk

The local factorization and native comparison morphism are proven here.
The derived eight-leg basis correction is not a product of independent
one-leg gauges, so Task 3 must still verify periodic `2x2 reduced / 4x4
nested` composition under all four spin structures before accepting global
network assembly. This report does not claim that Task 3 composition result.

## Independent review fix

Review findings in `.superpowers/sdd/task-2-review.md` were addressed in:

```text
cdba085b5e4ea5175b3c8ad647296b88436bc8ef
test: strengthen nested basis regression
Codex <codex@openai.com>
```

Tracked scope is limited to `test/nested_network.jl`; production remains at
`b1dcbee`.

The deterministic fixture now assigns a stable unique value to every block
coordinate. ComplexF64 values use asymmetric real and imaginary parts. The
mixed-multiplicity anisotropic closure runs for both Float64 and ComplexF64
and explicitly asserts all 218 stored coordinate values are distinct.

A direct rank-three ComplexF64 fixture independently verifies the native
bra-first pair fusion basis:

```text
(0,0) -> 1
(1,1) -> 2
(1,0) -> 3
(0,1) -> 4
```

TDD evidence:

```text
RED red-uniform-blocks:
  uniqueness failed for both scalar types: 16 unique / 218 coordinates
  direct fusion fixture: 4/4 passed
  exit_code: 1

GREEN green-final:
  168/168 focused assertions passed
  duration_seconds: 73
  peak_rss_kb: 893564
  killed_for_memory: 0
  exit_code: 0
```

Local log:

```text
D:\C 盘备份\Back up\Work_Save\coding\codex_server_logs\2026\0731\nested-task2-review-fix-019fb340.md
```

The full 1106/1106 result above still corresponds to the same production
commit `b1dcbee`; the follow-up commit changes tests only. `git diff --check`
is clean.
