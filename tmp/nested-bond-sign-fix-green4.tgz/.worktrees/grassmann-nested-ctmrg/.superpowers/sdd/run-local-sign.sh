#!/usr/bin/env bash
set -euo pipefail

task_root=/home/jkkong/work/2026/0731/nested-local-sign-solver-019fb340
export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin
export JULIA_PKG_OFFLINE=true
export NESTED_PERIODIC_ORACLE_ROOT="$task_root"

cd "$task_root"
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/oracle-v2.log \
  -- bash -ic \
  "export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin; \
   export JULIA_PKG_OFFLINE=true; \
   export NESTED_PERIODIC_ORACLE_ROOT=$task_root; \
   julia_grassmann exp/oracle.jl"
