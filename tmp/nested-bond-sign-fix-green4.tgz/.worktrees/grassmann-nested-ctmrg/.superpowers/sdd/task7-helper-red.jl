using Test

const TASK_ROOT = "/home/jkkong/work/2026/0801/task7-nested-example-a13f/exp"
TASK_ROOT in LOAD_PATH || pushfirst!(LOAD_PATH, TASK_ROOT)

include(joinpath(
    TASK_ROOT,
    "examples",
    "Spinless_Fermion_2D_Square_AD_nested",
    "Spinless_Fermion_2D_Square_AD_nested.jl",
))

@testset "Normalized gradient candidate RED" begin
    params = normalized_params([1.0, -0.5, 0.75, 2.0])
    objective = x -> sum(abs2, x)
    result = _normalized_gradient_candidate(
        objective, params;
        inner_optim_iter=2,
        max_step_norm=0.25,
    )
    @test result.candidate_energy <= result.energy
end
