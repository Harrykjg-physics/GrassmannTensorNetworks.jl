# Task 6: Reverse Rules and Gradient Accuracy

## Scope

- Base commit: `118e4db714060dac2248d2c226c691764612d0f2`
- Branch: `codex/grassmann-nested-ctmrg-implementation`
- Production ownership: the nested rules are loaded only by
  `GrassmannChainRulesCoreExt`.
- Julia execution: remote-only via `julia_grassmann`, with a 20 GB guard.

## RED

- Focused-harness setup failure (not accepted as RED):

  ```bash
  cd /home/jkkong/work/2026/0731/nested-chainrules-019fb340
  ./run_nested_chainrules_019fb340.sh red-network
  ```

- Result: exit `1`; `0` passed, `1` errored; duration `74 s`; peak RSS
  `902,340 KB`; no memory kill. The focused runner omitted the normal
  `test/nested_network.jl` setup, so the package binding `global_sign` was
  absent. This did not establish a reverse-mode defect and is preserved only
  as setup evidence in `log/red-network.log`.
- Correction: initialize the same binding with
  `@eval GrassmannTensorNetworks global global_sign = auto_sign` and assert
  the ordinary forward `_nested_ket_for_network` call succeeds before the AD
  check.
- Genuine RED after correction:

  ```bash
  cd /home/jkkong/work/2026/0731/nested-chainrules-019fb340
  ./run_nested_chainrules_019fb340.sh red-network-corrected
  ```

  The forward-placement assertion passed, then Zygote failed specifically on
  the `nested_network` matrix `setindex!` path with `Mutating arrays is not
  supported`. Result: exit `1`; `1` passed, `1` errored; duration `85 s`;
  peak RSS `991,164 KB`; no memory kill. Production files were still
  unchanged.

## GREEN

- First implementation run (`green-network`) failed before numerical
  comparison because two identifiers were copied from mojibake terminal
  output as U+879E (`螞`) instead of the source/brief's U+039B (`Λ`).
  ChainRules correctly rejected tangent fields `螞x`/`螞y` against primal
  fields `Λx`/`Λy`. The UTF-8 source and brief were checked by code point and
  the two identifiers were corrected. Exit `1`; duration `74 s`; peak RSS
  `932,620 KB`; no memory kill.
- The corrected-field run (`green-network-lambda`) reached the numerical
  assertion but exposed a real missing bra contribution: relative error
  `0.4999999997081881`, analytic `4.104178428840356`, finite
  `8.20835685289012`. Exit `1`; duration `78 s`; peak RSS `962,108 KB`; no
  memory kill.
- Systematic path diagnostics (`diagnose-bra-stages` and `diagnose-foldl`)
  found ket raw/placement/network derivatives accurate to about `1.51e-10`.
  Bra conjugation, pair sign, permutation, fusion, and one/two/three explicit
  bends were accurate (`2.82e-10` to `7.15e-10`), while the equivalent
  `foldl(_bend_index, (1, 2, 4); init=...)` returned a `Nothing` cotangent.
  This isolates the loss to `foldl` inside `_nested_bra_raw`, not to the
  existing Grassmann rules or the network cotangent addition.
- After approval, `_nested_bra_explicit_bends` was added exactly as the
  updated plan specifies. The next focused run (`focused-all`) passed the
  pair-sign, raw K/B, four placement, and network assembly checks (`9`
  passes), then errored in the operator-dressed Y pullback because AD entered
  static `_nested_x` construction and encountered its block `setindex!`.
  Exit `1`; duration `91 s`; peak RSS `944,240 KB`; no memory kill. The
  fixed-boundary measurement setup was not reached.
- An extension-local precomputed-crossing diagnostic (`diagnose-y-crossing`)
  preserved forward equality with `nested_y_operator` and produced relative
  error `3.89086125753516e-12` (analytic `7.987499174775251`, finite
  `7.987499174744173`). Exit `0`; duration `63 s`; peak RSS `849,588 KB`; no
  memory kill. Production remains unchanged pending approval of this second
  narrow plan deviation.
- After approval, the operator-only crossing helper was implemented exactly
  as the updated plan specifies. `focused-all-crossing` passed all ten direct
  reverse-rule checks; worst relative error was `5.106310197994386e-9`, the
  network error was `5.83623847548693e-10`, and operator-dressed Y was
  `6.768068201802029e-10`. Its single fixed-boundary CTMRG iteration then
  completed, but the test helper errored because `ndims(::Grassmann)` is not
  defined. Exit `1`; duration `118 s`; peak RSS `1,018,656 KB`; no memory
  kill.
- The approved test-only replacement `tensor_rank(first(grid))` passed that
  point. `focused-measurements` again retained all ten direct passes, then the
  site loss exposed `zero(primal)` in the planned network pullback:
  `Base.zero(::Grassmann)` is not defined when unused nested slots yield an
  `AbstractZero` cotangent. The remote guard completed despite the local SSH
  timeout: exit `1`; duration `132 s`; peak RSS `1,050,140 KB`; no memory
  kill.
- After approval, the zero cotangent was replaced only with
  `primal * zero(eltype(primal))`. `focused-measurements-zero` retained all ten
  direct passes and the site measurement directional check passed with zero
  analytic and finite derivatives. The horizontal measurement then exposed a
  pre-existing rank-zero scalar addition defect: `compute_nested_exp_hbond`
  adds `GrassmannScalar`s, `Base.:+` calls `tensor_parity`, and the scalar's
  sector key `()` makes Julia 1.12 reject `sum(())` as an empty reduction.
  Result: exit `1`; `11` passed and `1` errored; duration `158 s`; peak RSS
  `1,137,396 KB`; no memory kill.
- An isolated no-CTMRG diagnostic confirmed all three Schmidt contractions
  have the scalar sector key `()`, ordinary horizontal measurement forward
  evaluation fails at their addition, and extracting each scalar before
  numerical summation produces the finite forward value
  `4.852337819899432`. The successful diagnostic was exit `0`; duration
  `69 s`; peak RSS `868,424 KB`; no memory kill.
- The first safe-scalar AD diagnostic multiplied the fermionic sign into the
  `GrassmannScalar` before extracting its value. Its existing multiplication
  pullback received a structural tangent and failed at `Dict * Float64`.
  Result: exit `1`; duration `91 s`; peak RSS `1,002,128 KB`; no memory kill.
- Reordering to scalar extraction before sign multiplication avoided that
  path, but computing `tensor_parity(left_op)` inside the differentiated
  closure made Zygote traverse constant Schmidt-sector dictionary keys and
  fail at `getindex(::Dict)`. Result: exit `1`; duration `91 s`; peak RSS
  `1,046,992 KB`; no memory kill.
- Precomputing Schmidt terms and their orientation signs outside the
  differentiated objective, then contracting, extracting a safe numeric
  scalar, multiplying the numeric sign, and summing numbers completed
  successfully without CTMRG iterations. Horizontal relative error was
  `1.7122619073899308e-10` and vertical relative error was
  `1.1415643538562055e-9`. Result: exit `0`; duration `108 s`; peak RSS
  `993,400 KB`; no memory kill. The proposed test-local bypass was rejected in
  favor of repairing the public Task 5 forward path.
- Task 5's scalar-first public forward repair landed at `54dc914`, and the
  fixed-observable H/V pullback plan landed at `f65591e`. The new focused RED,
  `red-public-measurement-rrules`, passed all ten existing direct checks and
  fixed-boundary setup, then direct public H/V `rrule` lookup returned
  `nothing`; destructuring failed at `iterate(::Nothing)`. Result: exit `1`;
  `10` passed, `1` errored; duration `116 s`; peak RSS `1,073,268 KB`; no
  memory kill.
- `green-public-measurement-rrules` passed all `25` focused checks. Both H/V
  pullbacks returned six entries with nonzero `Tangent{NestedNetwork}` and
  `Tangent{CTMRGEnv}` values, and `NoTangent` for direct PEPS, fixed operator,
  and site. Result: exit `0`; duration `167 s`; peak RSS `1,038,768 KB`; no
  memory kill.
- Review hardening RED (`red-zero-cotangent-hardening`) directly seeded the
  pair-sign pullback with `ZeroTangent()`. The forward precheck passed, then
  the pullback called `_graded_pair_sign(::ZeroTangent, ...)` and raised the
  expected `MethodError`. Result: exit `1`; `1` passed and `1` errored;
  duration `47 s`; peak RSS `735,456 KB`; no memory kill.
- The first hardening GREEN (`green-zero-cotangent-hardening`) passed all new
  direct rule checks and all three non-vacuous measurement derivatives. Its
  only error was test-side: Zygote represented the gradient of the
  crossing-only constant objective as `nothing`, and the assertion called
  `norm` on it. Result: exit `1`; `52` passed and `1` errored; duration
  `164 s`; peak RSS `1,091,948 KB`; no memory kill.
- The approved assertion accepts either Zygote's `nothing` no-gradient
  representation or an explicit numeric zero, while the direct structured
  `network=ZeroTangent()` rrule check remains strict. The rerun
  (`green-zero-cotangent-hardening-2`) passed `53 / 53`; duration `160 s`;
  peak RSS `1,120,080 KB`; no memory kill.
- Validation-order RED (`red-y-validation-order`) established that public
  `nested_y_operator` rejects out-of-bounds `(2, 1)` with `ArgumentError`,
  while its rrule indexed `layout.ket_sites` first and raised `BoundsError`.
  Result: `54` passed and `1` failed; duration `163 s`; peak RSS
  `1,191,572 KB`; no memory kill.
- Moving the public primal call before all source/layout/crossing accesses was
  the only production change. `green-y-validation-order` passed `55 / 55`;
  duration `164 s`; peak RSS `1,032,536 KB`; no memory kill.

## Directional Errors

- Graded pair sign: `3.932696642403023e-9`.
- Raw nested ket: `2.072977382424146e-9`.
- Raw nested bra: `7.108603565972214e-11`.
- Placed nested ket: `2.072977382424146e-9`.
- Placed nested bra: `7.108603565972214e-11`.
- X placement: `5.106310197994386e-9`.
- Y placement: `6.949821052516902e-10`.
- Full nested network: `5.83623847548693e-10`.
- Operator-dressed Y: `6.768068201802029e-10`.
- Fixed-environment site measurement, differentiated with respect to the
  public operator argument along normalized physical identity:
  `8.25513792372003e-11`; analytic `0.7071067811865477`, finite
  `0.707106781128175`.
- Public horizontal measurement: `4.669179329732364e-9`; analytic
  `-0.06381208154285828`, finite `-0.06381208184080833`.
- Public vertical measurement: `5.677325785783064e-9`; analytic
  `-0.046078573329867534`, finite `-0.04607857306826446`.

## Full Suite

- The repository `test/server_runtests.jl` first stopped during package setup:
  its declared TestExtras `0.1` is absent from the server's offline cache,
  which contains `0.3.2`. No tests executed. Guard: exit `1`, duration `33 s`,
  peak RSS `661,128 KB`, no memory kill.
- With approval, a remote-only temporary copy retained every test include and
  mechanically changed only TestExtras to `0.3.2`. The repository file stayed
  at its required `0.1` constraint.
- The actual guarded full suite passed `1351 / 1351` tests in `11m18.3s`.
  Guard: exit `0`, duration `748 s`, peak RSS `1,457,504 KB`, no memory kill.
- After review hardening, the same approved remote-only TestExtras `0.3.2`
  harness passed `1379 / 1379` tests in `11m32.7s`. Guard: exit `0`, duration
  `764 s`, peak RSS `1,458,504 KB`, no memory kill.
- Final validation-order full verification passed `1381 / 1381` in
  `11m23.5s`. Guard: exit `0`, duration `757 s`, peak RSS `1,465,668 KB`, no
  memory kill. A temporary SSH outage delayed log retrieval only; the original
  full run was not restarted.

## Server Log and Memory

- Isolated workspace:
  `/home/jkkong/work/2026/0731/nested-chainrules-019fb340`.
- Every Julia invocation used `julia_grassmann` under the 20 GB guard.
- Focused green: `log/green-public-measurement-rrules.log`.
- Full green: `log/full-public-measurement-rrules-offline.log`.
- Review-hardening RED/focused/full logs:
  `log/red-zero-cotangent-hardening.log`,
  `log/green-zero-cotangent-hardening-2.log`, and
  `log/full-zero-cotangent-hardening.log`.
- Validation-order logs: `log/red-y-validation-order.log`,
  `log/green-y-validation-order.log`, and
  `log/full-y-validation-order.log`.
- Local copies are under
  `D:\C 盘备份\Back up\Work_Save\coding\codex_server_logs\2026\0731`.

## Commit

- `446dfca` — `feat: differentiate nested Grassmann networks`
- Commit scope is exactly the five Task 6 files.
- `80c8b27` — `fix: handle zero nested cotangents`
- Follow-up scope is limited to the Task 6 rules and tests.
- `8f219a5` — `fix: preserve nested Y validation order`
- Final follow-up scope is limited to the same Task 6 rules and tests.

## Self-review

- The rules file is included only by `GrassmannChainRulesCoreExt`; it is not
  included from `src/algorithms.jl`.
- Public H/V primals call the official measurement functions before preparing
  pullback data.
- Schmidt decompositions, dressed Y tensors, horizontal parity signs, and the
  promoted numeric zero are prepared outside `rrule_via_ad`.
- Prepared helpers differentiate only `nested` and `env`, scalarize every
  rank-zero contraction before numeric multiplication/addition, and return
  the public `(denominator, value)` shape.
- H/V pullbacks retain nested and environment cotangents and return
  `NoTangent` for direct PEPS, fixed operator, and site.
- Every linear nested pullback now unthunks before checking `AbstractZero`,
  and returns the correct tuple arity with `ZeroTangent` only for its dynamic
  input. The network rule also short-circuits a structured zero `network`
  field before indexing it.
- The operator-Y rule computes its primal through public
  `nested_y_operator`, preserving public validation; equality and invalid
  operator tests cover that boundary.
- The operator-Y public primal now runs before every source/layout/crossing
  access, so out-of-bounds sites preserve the public `ArgumentError` instead
  of leaking an internal `BoundsError` from rrule setup.
- Site/H/V derivative tests now reject vacuous checks before applying the
  relative-error tolerance. Site differentiates the public operator input;
  H/V retain the planned PEPS-parameter path.
- `git diff --check` passed, and repository TestExtras remains `0.1`.

## Concerns

- The H/V rules intentionally implement a fixed-observable optimization
  contract. They are not an operator-gradient API; a rank-four operator
  gradient needs a separate adjoint of the operator-to-numerator linear map.
- The offline server cannot resolve repository-declared TestExtras `0.1`; full
  verification currently needs the documented remote-only `0.3.2` harness
  substitution.

## Public H/V rrule design audit (server unavailable)

No Julia process was run for this audit and no Task 6 source or test file was
edited. The design assumes Task 5 supplies the scalar-first numeric
accumulation now visible in `compute_nested_exp_hbond` and
`compute_nested_exp_vbond`.

### Prepared data and extension-local helpers

The public-rule body should perform all operator/geometry preparation outside
`rrule_via_ad`:

1. Normalize `site` to `source` and derive the orientation-specific neighbor.
2. Run the public bond-operator validation.
3. Build the two physical identities and their closed Y insertions.
4. Run `_operator_schmidt(operator)` once.
5. Build each pair of operator-dressed Y insertions. For horizontal bonds,
   compute and store `(-one(eltype(operator)))^tensor_parity(left_op)` at this
   stage. Vertical terms store no sign (or a numeric `one`).

This preparation is outside AD. In particular, neither `_operator_schmidt`
nor `tensor_parity(left_op)` may appear in the differentiated helper. The
successful isolated diagnostic showed that precomputed pairs/signs plus
scalar-first numeric accumulation give horizontal and vertical relative
errors `1.7122619073899308e-10` and `1.1415643538562055e-9`; tracing the sign
metadata inside AD instead failed while traversing dictionary keys.

Use two branch-free extension-local helpers with only `nested` and `env` as
dynamic inputs; `source` and the prepared insertions are closure constants:

```julia
function _nested_hbond_from_prepared(
    nested, env, source,
    closed_left, closed_right, signed_insertions,
)
    denominator = _contract_nested_hpatch3(
        nested, env, source, closed_left, closed_right
    )
    denominator_value = _nested_scalar_or_zero(denominator)
    numerator = zero(denominator_value)
    for (left_y, right_y, sign) in signed_insertions
        term = _contract_nested_hpatch3(
            nested, env, source, left_y, right_y
        )
        numerator += sign * _nested_scalar_or_zero(term)
    end
    return denominator, numerator / denominator_value
end

function _nested_vbond_from_prepared(
    nested, env, source,
    closed_top, closed_bottom, insertions,
)
    denominator = _contract_nested_vpatch3(
        nested, env, source, closed_top, closed_bottom
    )
    denominator_value = _nested_scalar_or_zero(denominator)
    numerator = zero(denominator_value)
    for (top_y, bottom_y) in insertions
        term = _contract_nested_vpatch3(
            nested, env, source, top_y, bottom_y
        )
        numerator += _nested_scalar_or_zero(term)
    end
    return denominator, numerator / denominator_value
end
```

The helpers return the full public `(denominator, value)` result, rather than
only `value`, so an upstream cotangent for either tuple component is handled.
They use Task 5's `_nested_scalar_or_zero` before sign multiplication or
addition; they never add or sign-multiply `GrassmannScalar`s.

### Public rules and pullback tuples

The proposed public signatures are:

```julia
function ChainRulesCore.rrule(
    config::RuleConfig{>:HasReverseMode},
    ::typeof(compute_nested_exp_hbond),
    nested::NestedNetwork,
    peps::Square_GPEPS,
    operator::Grassmann{<:Number, 4},
    env::CTMRGEnv,
    site,
)

function ChainRulesCore.rrule(
    config::RuleConfig{>:HasReverseMode},
    ::typeof(compute_nested_exp_vbond),
    nested::NestedNetwork,
    peps::Square_GPEPS,
    operator::Grassmann{<:Number, 4},
    env::CTMRGEnv,
    site,
)
```

After preparation, each rule should obtain a pullback with only the genuine
numeric state as AD input:

```julia
helper_y, helper_pullback = rrule_via_ad(
    config,
    (network, boundary) -> _nested_hbond_from_prepared(
        network, boundary, source,
        closed_left, closed_right, signed_insertions,
    ),
    nested, env,
)
```

The vertical rule is identical with its vertical helper. The rule should
return the public forward result (and tests should compare it with `helper_y`).
Given an upstream cotangent for `(denominator, value)`, call
`helper_pullback(unthunk(delta))` directly. Its result is
`(_, delta_nested, delta_env)`. The six-entry public pullback is:

```julia
(
    NoTangent(),       # function
    delta_nested,      # nested
    NoTangent(),       # peps: direct use is static metadata only
    NoTangent(),       # operator: fixed-observable boundary, see below
    delta_env,         # env remains a genuine numeric input
    NoTangent(),       # site/orientation geometry
)
```

For an `AbstractZero` upstream cotangent, return `ZeroTangent()` for the two
genuinely differentiable inputs (`nested` and `env`) and `NoTangent()` for the
static arguments without invoking the helper pullback.

The direct `peps` tangent must not be retained. Once `nested` is supplied,
`peps` is used only for bounds, dimensions, parity splits, and constructing
identity/crossing shapes. Its numerical tensor entries do not enter the
measurement directly. When a caller computes `nested_network(peps)` and then
the measurement, the physical PEPS gradient flows through `delta_nested` and
the `nested_network` rrule. Returning a second PEPS tangent would either be a
spurious path or double counting.

`env` is different: the strip contractions use its numerical tensors, so the
helper must take it as a dynamic argument and the public rule must return
`delta_env`. The directional tests freeze the environment, but discarding its
cotangent in the public rule would make the rule non-compositional if an
environment is ever produced by a differentiable caller.

The operator tangent is the one explicit contract limitation. Precomputing
Schmidt pairs and signs necessarily freezes the observable. Returning
`NoTangent()` is acceptable only for Task 6's fixed-observable measurement
boundary. A mathematically general public rrule cannot silently claim this:
operator differentiation would require a separate adjoint for the linear map
from the original rank-four operator to the numeric numerator, without
differentiating the SVD/truncation metadata. If differentiable operators are a
public requirement, the general rrule must be deferred or narrowed rather
than returning a false zero.

### Fixed-environment tests

Use one deterministic `ctmrg_iter=1` environment, then keep it fixed for all
three objectives. Rebuild `peps = Square_GPEPS(..., x, false)` and
`nested = nested_network(peps)` inside each objective, convert the frozen
environment only to `eltype(x)`, and call the public functions:

1. `compute_nested_exp_site(..., number, ..., (1, 1))` — retain the existing
   site directional check. A zero analytic/finite result is allowed for this
   fixture, but both must be finite.
2. `compute_nested_exp_hbond(..., bond, ..., (1, 1))` — require relative error
   at most `1e-4`, finite public forward value/denominator, and a non-vacuous
   analytic or finite derivative for the deterministic fixture.
3. `compute_nested_exp_vbond(..., bond, ..., (1, 1))` — apply the same checks.

Log `(relative, analytic, finite)` for every objective. H/V must call the
public APIs, not test-local reimplementations. A small rule-shape check should
also invoke each public `rrule` directly and confirm its pullback has six
entries, with `NoTangent` for direct PEPS/operator/site positions and an
environment cotangent position that is not discarded. No additional CTMRG
iteration is needed.
