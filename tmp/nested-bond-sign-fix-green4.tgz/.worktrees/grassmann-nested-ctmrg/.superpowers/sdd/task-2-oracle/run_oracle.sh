#!/usr/bin/env bash
set -uo pipefail

task_root=/home/jkkong/work/2026/0731/nested-task2-sector-oracle-019fb340
export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin
export JULIA_PKG_OFFLINE=true
export NESTED_ORACLE_TASK_ROOT="$task_root"

cd "$task_root"
set +e
./run_with_memory_guard.sh \
    --limit-gb 20 \
    --log log/sector-oracle-v3.log \
    -- bash -ic \
    "export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin; \
     export JULIA_PKG_OFFLINE=true; \
     export NESTED_ORACLE_TASK_ROOT=$task_root; \
     julia_grassmann $task_root/exp/sector_oracle.jl"
exit_code=$?
set -e

echo "exit_code=$exit_code"
exit "$exit_code"
