using Pkg

const TASK_ROOT = get(ENV, "NESTED_ORACLE_TASK_ROOT", @__DIR__)
Pkg.activate(joinpath(TASK_ROOT, "harness"))

using GrassmannTensorNetworks
using LinearAlgebra
using Random

@eval GrassmannTensorNetworks global global_sign = auto_sign

import GrassmannTensorNetworks:
    _graded_pair_sign,
    _nested_ket,
    _nested_bra,
    _nested_x,
    _nested_y,
    _physical_identity

const SIGN = GrassmannTensorNetworks.global_sign
const INDEX_TYPES = (:out, :out, :in, :in, :out)
const BRA_FIRST = (5, 1, 7, 3, 4, 2, 8, 6)

# The inversion set is
# bL*(kL + bR + kR + bU + kU + bD) + kR*bU.
const NATIVE_BASIS_BRAID = (2, 3, 5, 4, 6, 7, 1, 8)
const NATIVE_BASIS_TWISTS = (2, 4, 6) # kL, kR, kU after BRA_FIRST.

parity_index(q::Int) = q + 1

const PAIR_TO_FUSED_INDEX = Dict(
    (0, 0) => 1,
    (1, 1) => 2,
    (1, 0) => 3,
    (0, 1) => 4,
)

fused_index(q1::Int, q2::Int) = PAIR_TO_FUSED_INDEX[(q1, q2)]

function deterministic_tensor(::Type{T}) where {T}
    A = Grassmann(
        (2, 2, 2, 2, 2),
        (1, 1, 1, 1, 1),
        INDEX_TYPES,
        T;
        init=:zeros,
    )
    for (number, sector) in enumerate(sort!(collect(nonzero_keys(A))))
        value = if T <: Complex
            T(number, 2 * number + 1)
        else
            T(number)
        end
        fill!(A[sector], value)
    end
    return A
end

function seeded_tensor(
    ::Type{T},
    sizes::NTuple{5, Int},
    evens::NTuple{5, Int},
    seed::Int,
) where {T}
    rng = MersenneTwister(seed)
    A = Grassmann(sizes, evens, INDEX_TYPES, T; init=:zeros)
    for block in nonzero_vals(A)
        randn!(rng, block)
        block .+= one(T)
    end
    return A
end

function placed_x(A)
    raw = _nested_x(size(A)[2], even(A)[2], size(A)[5], even(A)[5], eltype(A))
    # TensorKit's nested_network applies twist(TensorMap(Xraw), 1).
    # Reference [W,S;N,E] codomain index 1 is native geographic W, axis 1.
    return add_parity_sign(raw, 1; sign_function=SIGN)
end

function open_tile(A; apply_x_twist::Bool)
    K = _nested_ket(A)
    B = _nested_bra(A)
    Xraw = _nested_x(
        size(A)[2], even(A)[2], size(A)[5], even(A)[5], eltype(A)
    )
    X = apply_x_twist ? add_parity_sign(Xraw, 1; sign_function=SIGN) : Xraw
    Y = _nested_y(
        _physical_identity(A),
        size(A)[3],
        even(A)[3],
        size(A)[4],
        even(A)[4],
    )
    ky = contract(K, Y, (2, 1); sign_function=SIGN)
    kx = contract(ky, X, (3, 3); sign_function=SIGN)
    tile = contract(kx, B, ((5, 7), (3, 1)); sign_function=SIGN)
    return (; K, B, Xraw, X, Y, ky, kx, tile)
end

function open_tile_distributed(A)
    # On the parity-compatible support,
    # D_raw = kL+kR+kU + bL*kD + kR*bU.
    ket_input = A
    for index in (2, 3, 4)
        ket_input = add_parity_sign(ket_input, index; sign_function=SIGN)
    end
    K = _nested_ket(ket_input)
    B = _nested_bra(A)
    Xraw = _nested_x(
        size(A)[2], even(A)[2], size(A)[5], even(A)[5], eltype(A)
    )
    X = _graded_pair_sign(Xraw, 1, 3)
    Yraw = _nested_y(
        _physical_identity(A),
        size(A)[3],
        even(A)[3],
        size(A)[4],
        even(A)[4],
    )
    Y = _graded_pair_sign(Yraw, 2, 3)
    ky = contract(K, Y, (2, 1); sign_function=SIGN)
    kx = contract(ky, X, (3, 3); sign_function=SIGN)
    tile = contract(kx, B, ((5, 7), (3, 1)); sign_function=SIGN)
    return (; K, B, Xraw, X, Yraw, Y, ky, kx, tile)
end

function reduced_style_fusions(ordered)
    ordered = add_parity_sign(ordered, 1; sign_function=SIGN)
    left = fuse(ordered, (1, 2); index_type_fused=:out)
    left = add_perm_sign(
        left, (1, 3, 2, 4, 5, 6, 7); sign_function=SIGN
    )
    right = fuse(left, (2, 3); index_type_fused=:in)
    right = add_perm_sign(
        right, (1, 2, 4, 3, 5, 6); sign_function=SIGN
    )
    up = fuse(right, (3, 4); index_type_fused=:in)
    up = add_parity_sign(up, 4; sign_function=SIGN)
    return fuse(up, (4, 5); index_type_fused=:out)
end

function native_basis_isomorphism(ordered)
    corrected = add_perm_sign(
        ordered, NATIVE_BASIS_BRAID; sign_function=SIGN
    )
    for index in NATIVE_BASIS_TWISTS
        corrected = add_parity_sign(corrected, index; sign_function=SIGN)
    end
    return corrected
end

function close_tile(A; apply_x_twist::Bool=true, correct_basis::Bool=true)
    nodes = open_tile(A; apply_x_twist)
    ordered = permutedims(nodes.tile, BRA_FIRST; sign_function=SIGN)
    correct_basis && (ordered = native_basis_isomorphism(ordered))
    return reduced_style_fusions(ordered)
end

function close_tile_distributed(A)
    nodes = open_tile_distributed(A)
    ordered = permutedims(nodes.tile, BRA_FIRST; sign_function=SIGN)
    return reduced_style_fusions(ordered)
end

function solve_gf2(matrix::BitMatrix, rhs::BitVector)
    augmented = hcat(copy(matrix), copy(rhs))
    rows, columns = size(matrix)
    pivot_columns = Int[]
    pivot_row = 1
    for column in 1:columns
        selected = findfirst(row -> augmented[row, column], pivot_row:rows)
        isnothing(selected) && continue
        selected_row = pivot_row + selected - 1
        augmented[pivot_row, :], augmented[selected_row, :] =
            copy(augmented[selected_row, :]), copy(augmented[pivot_row, :])
        for row in 1:rows
            if row != pivot_row && augmented[row, column]
                augmented[row, :] .⊻= augmented[pivot_row, :]
            end
        end
        push!(pivot_columns, column)
        pivot_row += 1
        pivot_row > rows && break
    end
    for row in pivot_row:rows
        if !any(augmented[row, 1:columns]) && augmented[row, end]
            error("inconsistent GF(2) system")
        end
    end
    solution = falses(columns)
    for (row, column) in enumerate(pivot_columns)
        solution[column] = augmented[row, end]
    end
    return solution, length(pivot_columns)
end

function quadratic_features(rows, names)
    feature_names = String["1"]
    append!(feature_names, names)
    for first in 1:(length(names) - 1), second in (first + 1):length(names)
        push!(feature_names, names[first] * "*" * names[second])
    end
    features = BitMatrix(undef, length(rows), length(feature_names))
    for (row_number, bits) in enumerate(rows)
        values = Bool[true]
        append!(values, Bool.(bits))
        for first in 1:(length(bits) - 1), second in (first + 1):length(bits)
            push!(values, bits[first] * bits[second] == 1)
        end
        features[row_number, :] = values
    end
    return features, feature_names
end

function phase_bit(value)
    distance_plus = abs(value - one(value))
    distance_minus = abs(value + one(value))
    min(distance_plus, distance_minus) <= 100 * eps(Float64) ||
        error("value is not a sign: $value")
    return distance_minus < distance_plus
end

function fit_polynomial(rows, signs, names)
    features, feature_names = quadratic_features(rows, names)
    rhs = BitVector(phase_bit(sign) for sign in signs)
    solution, rank = solve_gf2(features, rhs)
    fitted = features * Int.(solution)
    all(iszero, mod.(fitted .- Int.(rhs), 2)) || error("bad GF(2) fit")
    terms = feature_names[solution]
    return isempty(terms) ? "0" : join(terms, " + "), rank, length(feature_names) - rank
end

function component_phase_report(A)
    K, B, Xraw, X, Y = let nodes = open_tile(A; apply_x_twist=true)
        nodes.K, nodes.B, nodes.Xraw, nodes.X, nodes.Y
    end
    Adense = convert(Array, A)
    Kdense, Bdense = convert(Array, K), convert(Array, B)
    Xrawdense, Xdense, Ydense =
        convert(Array, Xraw), convert(Array, X), convert(Array, Y)

    ket_rows, ket_signs = NTuple{4, Int}[], Float64[]
    bra_rows, bra_signs = NTuple{4, Int}[], Float64[]
    x_rows, x_raw_signs, x_placed_signs =
        NTuple{2, Int}[], Float64[], Float64[]
    y_rows, y_signs = NTuple{3, Int}[], Float64[]

    for k in Iterators.product(ntuple(_ -> 0:1, 4)...)
        kL, kR, kU, kD = k
        p = mod(sum(k), 2)
        a = Adense[
            parity_index(p),
            parity_index(kL),
            parity_index(kR),
            parity_index(kU),
            parity_index(kD),
        ]
        kval = Kdense[
            parity_index(kL),
            fused_index(p, kR),
            parity_index(kU),
            parity_index(kD),
        ]
        push!(ket_rows, k)
        push!(ket_signs, real(kval / a))
    end

    for b in Iterators.product(ntuple(_ -> 0:1, 4)...)
        bL, bR, bU, bD = b
        p = mod(sum(b), 2)
        a = Adense[
            parity_index(p),
            parity_index(bL),
            parity_index(bR),
            parity_index(bU),
            parity_index(bD),
        ]
        bval = Bdense[
            parity_index(bL),
            parity_index(bR),
            fused_index(p, bU),
            parity_index(bD),
        ]
        push!(bra_rows, b)
        push!(bra_signs, real(bval / conj(a)))
    end

    for (bL, kD) in Iterators.product(0:1, 0:1)
        push!(x_rows, (bL, kD))
        push!(
            x_raw_signs,
            Xrawdense[
                parity_index(bL),
                parity_index(bL),
                parity_index(kD),
                parity_index(kD),
            ],
        )
        push!(
            x_placed_signs,
            Xdense[
                parity_index(bL),
                parity_index(bL),
                parity_index(kD),
                parity_index(kD),
            ],
        )
    end

    for (p, kR, bU) in Iterators.product(0:1, 0:1, 0:1)
        push!(y_rows, (p, kR, bU))
        push!(
            y_signs,
            Ydense[
                fused_index(p, kR),
                parity_index(kR),
                parity_index(bU),
                fused_index(p, bU),
            ],
        )
    end

    println("BOUNDARY component K phase = ", first(fit_polynomial(
        ket_rows, ket_signs, ["kL", "kR", "kU", "kD"]
    )))
    println("BOUNDARY component B phase = ", first(fit_polynomial(
        bra_rows, bra_signs, ["bL", "bR", "bU", "bD"]
    )))
    println("BOUNDARY component Xraw phase = ", first(fit_polynomial(
        x_rows, x_raw_signs, ["bL", "kD"]
    )))
    println("BOUNDARY component Xplaced phase = ", first(fit_polynomial(
        x_rows, x_placed_signs, ["bL", "kD"]
    )))
    println("BOUNDARY component Y phase = ", first(fit_polynomial(
        y_rows, y_signs, ["p", "kR", "bU"]
    )))
end

function compatible_rows()
    rows = NTuple{8, Int}[]
    for b in Iterators.product(ntuple(_ -> 0:1, 4)...)
        for k in Iterators.product(ntuple(_ -> 0:1, 4)...)
            mod(sum(b), 2) == mod(sum(k), 2) || continue
            bL, bR, bU, bD = b
            kL, kR, kU, kD = k
            push!(rows, (bL, kL, bR, kR, bU, kU, bD, kD))
        end
    end
    return rows
end

function global_phase_report(A)
    names = ["bL", "kL", "bR", "kR", "bU", "kU", "bD", "kD"]
    rows = compatible_rows()
    nodes = open_tile(A; apply_x_twist=true)
    ordered = permutedims(nodes.tile, BRA_FIRST; sign_function=SIGN)
    uncorrected = reduced_style_fusions(ordered)
    corrected = reduced_style_fusions(native_basis_isomorphism(ordered))
    target = reduced_tensor(A)

    Adense = convert(Array, A)
    tiledense = convert(Array, nodes.tile)
    ordereddense = convert(Array, ordered)
    uncorrecteddense = convert(Array, uncorrected)
    correcteddense = convert(Array, corrected)
    targetdense = convert(Array, target)

    tile_signs = Float64[]
    ordered_signs = Float64[]
    fused_signs = Float64[]
    target_signs = Float64[]
    residual_signs = Float64[]
    corrected_residual_signs = Float64[]

    for row in rows
        bL, kL, bR, kR, bU, kU, bD, kD = row
        p = mod(bL + bR + bU + bD, 2)
        bra = Adense[
            parity_index(p),
            parity_index(bL),
            parity_index(bR),
            parity_index(bU),
            parity_index(bD),
        ]
        ket = Adense[
            parity_index(p),
            parity_index(kL),
            parity_index(kR),
            parity_index(kU),
            parity_index(kD),
        ]
        bilinear = conj(bra) * ket
        tile_value = tiledense[
            parity_index(kL),
            parity_index(kU),
            parity_index(kR),
            parity_index(bU),
            parity_index(bL),
            parity_index(kD),
            parity_index(bR),
            parity_index(bD),
        ]
        ordered_value = ordereddense[
            parity_index(bL),
            parity_index(kL),
            parity_index(bR),
            parity_index(kR),
            parity_index(bU),
            parity_index(kU),
            parity_index(bD),
            parity_index(kD),
        ]
        output_index = (
            fused_index(bL, kL),
            fused_index(bR, kR),
            fused_index(bU, kU),
            fused_index(bD, kD),
        )
        target_value = targetdense[output_index...]
        fused_value = uncorrecteddense[output_index...]
        corrected_value = correcteddense[output_index...]
        push!(tile_signs, real(tile_value / bilinear))
        push!(ordered_signs, real(ordered_value / bilinear))
        push!(fused_signs, real(fused_value / bilinear))
        push!(target_signs, real(target_value / bilinear))
        push!(residual_signs, real(fused_value / target_value))
        push!(
            corrected_residual_signs,
            real(corrected_value / target_value),
        )
    end

    for (label, signs) in (
        ("open tile", tile_signs),
        ("bra-first permutation", ordered_signs),
        ("reduced-style external fusions", fused_signs),
        ("native reduced_tensor target", target_signs),
        ("uncorrected residual", residual_signs),
        ("corrected residual", corrected_residual_signs),
    )
        polynomial, rank, nullity = fit_polynomial(rows, signs, names)
        println(
            "BOUNDARY ",
            label,
            " phase = ",
            polynomial,
            " [rank=",
            rank,
            ", nullity=",
            nullity,
            "]",
        )
    end

    expected_residual = Float64[]
    for row in rows
        braid = SIGN(row, NATIVE_BASIS_BRAID)
        twists = prod(SIGN(row[index]) for index in NATIVE_BASIS_TWISTS)
        push!(expected_residual, braid * twists)
    end
    @assert BitVector(phase_bit(x) for x in residual_signs) ==
        BitVector(phase_bit(x) for x in expected_residual)
    @assert all(!phase_bit(x) for x in corrected_residual_signs)
    @assert count(!iszero, targetdense) == 128
    @assert correcteddense == targetdense
    println("SECTORS compatible=128 target_nonzero=128 corrected_residual_nonzero=0")
end

function raw_x_audit(A)
    X = _nested_x(
        size(A)[2], even(A)[2], size(A)[5], even(A)[5], eltype(A)
    )
    dense = convert(Array, X)
    for h in axes(dense, 1), hp in axes(dense, 2)
        for v in axes(dense, 3), vp in axes(dense, 4)
            qh = h <= even(A)[2] ? 0 : 1
            qv = v <= even(A)[5] ? 0 : 1
            expected =
                h == hp && v == vp ? (-one(eltype(A)))^(qh * qv) : zero(eltype(A))
            dense[h, hp, v, vp] == expected ||
                error("raw X mismatch at ($h,$hp,$v,$vp)")
        end
    end
    return true
end

function compare_case(label, A; require_exact::Bool=false)
    raw_x_audit(A)
    candidate = close_tile(A)
    target = reduced_tensor(A)
    candidate_dense = convert(Array, candidate)
    target_dense = convert(Array, target)
    max_abs = maximum(abs, candidate_dense .- target_dense)
    scale = max(maximum(abs, target_dense), eps(Float64))
    rel = max_abs / scale
    exact = candidate_dense == target_dense
    require_exact && !exact && error("$label was not bitwise exact")
    rel <= 5e-13 || error("$label relative residual $rel")
    println(
        "VERIFY ",
        label,
        " exact=",
        exact,
        " max_abs=",
        max_abs,
        " rel=",
        rel,
        " size=",
        size(A),
        " even=",
        even(A),
    )
end

function compare_distributed_case(label, A; require_exact::Bool=false)
    raw_x_audit(A)
    candidate = close_tile_distributed(A)
    target = reduced_tensor(A)
    candidate_dense = convert(Array, candidate)
    target_dense = convert(Array, target)
    max_abs = maximum(abs, candidate_dense .- target_dense)
    scale = max(maximum(abs, target_dense), eps(Float64))
    rel = max_abs / scale
    exact = candidate_dense == target_dense
    require_exact && !exact && error("$label was not bitwise exact")
    rel <= 5e-13 || error("$label relative residual $rel")
    println(
        "VERIFY_DISTRIBUTED ",
        label,
        " exact=",
        exact,
        " max_abs=",
        max_abs,
        " rel=",
        rel,
    )
end

function periodic_scalar_audit(label, A; distributed::Bool=false)
    tile = (
        distributed ?
        open_tile_distributed(A).tile :
        open_tile(A; apply_x_twist=true).tile
    )
    target = reduced_tensor(A)
    for (twist_x, twist_y) in
        ((false, false), (true, false), (false, true), (true, true))
        pbc_x, pbc_y = !twist_x, !twist_y
        nested_scalar = trace(
            tile,
            ((1, 5, 6, 8), (3, 7, 2, 4));
            sign_function=SIGN,
            pbc=(pbc_x, pbc_x, pbc_y, pbc_y),
        )
        reduced_scalar = trace(
            target,
            ((1, 4), (2, 3));
            sign_function=SIGN,
            pbc=(pbc_x, pbc_y),
        )
        difference = abs(scalar(nested_scalar) - scalar(reduced_scalar))
        scale = max(abs(scalar(reduced_scalar)), eps(Float64))
        println(
            "PERIODIC ",
            label,
            " distributed=",
            distributed,
            " twists=(",
            twist_x,
            ",",
            twist_y,
            ") nested=",
            scalar(nested_scalar),
            " reduced=",
            scalar(reduced_scalar),
            " rel=",
            difference / scale,
        )
    end
end

println("=== native parity-sector oracle ===")
minimal_float = deterministic_tensor(Float64)
component_phase_report(minimal_float)
global_phase_report(minimal_float)

compare_case("deterministic Float64", minimal_float; require_exact=true)
compare_case(
    "deterministic ComplexF64",
    deterministic_tensor(ComplexF64);
    require_exact=true,
)
periodic_scalar_audit("deterministic Float64", minimal_float)
periodic_scalar_audit("deterministic ComplexF64", deterministic_tensor(ComplexF64))
compare_distributed_case(
    "deterministic Float64", minimal_float; require_exact=true
)
compare_distributed_case(
    "deterministic ComplexF64",
    deterministic_tensor(ComplexF64);
    require_exact=true,
)
periodic_scalar_audit(
    "deterministic Float64", minimal_float; distributed=true
)
periodic_scalar_audit(
    "deterministic ComplexF64",
    deterministic_tensor(ComplexF64);
    distributed=true,
)

for T in (Float64, ComplexF64), seed in (1103, 2207, 3301)
    compare_case(
        "minimal $(T) seed=$seed",
        seeded_tensor(T, (2, 2, 2, 2, 2), (1, 1, 1, 1, 1), seed),
    )
end

const LARGE_SIZE = (3, 3, 4, 3, 4)
const LARGE_EVEN = (2, 1, 3, 2, 1)
for T in (Float64, ComplexF64), seed in (4409, 5519)
    compare_case(
        "larger mixed $(T) seed=$seed",
        seeded_tensor(T, LARGE_SIZE, LARGE_EVEN, seed),
    )
end

println("ORACLE_RESULT PASS")
