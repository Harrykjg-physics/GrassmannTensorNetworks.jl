using Pkg

const GTN_ROOT = normpath(joinpath(@__DIR__, "../.."))
Pkg.activate(GTN_ROOT)
Pkg.instantiate()
GTN_ROOT in LOAD_PATH || push!(LOAD_PATH, GTN_ROOT)

using GrassmannTensorNetworks
using LinearAlgebra
using Random

@eval GrassmannTensorNetworks global global_sign = auto_sign

normalized_params(params) =
    collect(params) ./ (norm(params) / sqrt(length(params)) + eps(Float64))

const D = 2
const LX = 2
const LY = 2
const SEED = 1234
const CHI = parse(Int, ARGS[1])
const PARAMETER_COUNT = square_gpeps_parameter_count(2, 1, D, LX, LY)

Random.seed!(SEED)
const PARAMS = normalized_params(randn(PARAMETER_COUNT))
const PEPS = Square_GPEPS(2, 1, D, LX, LY, PARAMS, false)
const HAMILTONIAN = nn_bond(SpinlessFermionModel(1.0, 1.0, 3.0))
const TBULK = Matrix{Grassmann{Float64, 4}}([
    reduced_tensor(PEPS.A[r, c]) for r in 1:LX, c in 1:LY
])
const TH = Matrix{Grassmann{Float64, 6}}([
    reduced_tensor_hbond(
        PEPS.A[r, c], PEPS.A[r, Nmod(c + 1, LY)], HAMILTONIAN
    ) for r in 1:LX, c in 1:LY
])
const TV = Matrix{Grassmann{Float64, 6}}([
    reduced_tensor_vbond(
        PEPS.A[r, c], PEPS.A[Nmod(r + 1, LX), c], HAMILTONIAN
    ) for r in 1:LX, c in 1:LY
])

function acceptance_seeded_environment()
    Random.seed!(SEED)
    normalized_params(randn(PARAMETER_COUNT))
    return CTMRGEnv(TBULK, CHI, div(CHI, 2))
end

finite_number(z) = isfinite(real(z)) && isfinite(imag(z))

function environment_norms(env)
    grids = (
        El=env.El, Er=env.Er, Eu=env.Eu, Ed=env.Ed,
        Clu=env.Clu, Cru=env.Cru, Cld=env.Cld, Crd=env.Crd,
    )
    values = map(grid -> maximum(norm, grid), grids)
    return merge(values, (maximum=maximum(values),))
end

function snapshot(label, iteration, env)
    horizontal = NamedTuple[]
    vertical = NamedTuple[]
    energy = 0.0
    for c in 1:LY, r in 1:LX
        cp1 = Nmod(c + 1, LY)
        rp1 = Nmod(r + 1, LX)
        hden, hvalue = compute_exp_hbond(
            TBULK[r, c], TBULK[r, cp1], TH[r, c],
            env.El[r, c], env.Er[r, cp1], env.Eu[r, c], env.Eu[r, cp1],
            env.Ed[r, c], env.Ed[r, cp1], env.Clu[r, c], env.Cru[r, cp1],
            env.Cld[r, c], env.Crd[r, cp1],
        )
        vden, vvalue = compute_exp_vbond(
            TBULK[rp1, c], TBULK[r, c], TV[r, c],
            env.Ed[rp1, c], env.Eu[r, c], env.Er[rp1, c], env.Er[r, c],
            env.El[rp1, c], env.El[r, c], env.Crd[rp1, c], env.Cru[r, c],
            env.Cld[rp1, c], env.Clu[r, c],
        )
        push!(horizontal, (
            site=(r, c), value=hvalue, denominator=hden,
            denominator_abs=abs(hden), denominator_phase=angle(hden),
            denominator_finite=finite_number(hden), value_finite=finite_number(hvalue),
        ))
        push!(vertical, (
            site=(r, c), value=vvalue, denominator=vden,
            denominator_abs=abs(vden), denominator_phase=angle(vden),
            denominator_finite=finite_number(vden), value_finite=finite_number(vvalue),
        ))
        energy += real(hvalue + vvalue)
    end
    record = (
        chi=CHI, label=label, iteration=iteration,
        energy=energy / (LX * LY), horizontal=horizontal, vertical=vertical,
        environment_norms=environment_norms(env),
    )
    println("REDUCED_RECORD=", repr(record))
    flush(stdout)
    return record
end

println("REDUCED_PARAMS=", repr((
    seed=SEED, count=PARAMETER_COUNT, norm=norm(PARAMS),
    checksum=sum(i * PARAMS[i] for i in eachindex(PARAMS)),
    first8=PARAMS[1:min(8, end)],
)))

env = acceptance_seeded_environment()
snapshot(:initial, 0, env)
for iteration in 1:40
    run_GCTMRG!(
        TBULK, TBULK, env, CHI;
        ctmrg_iter=1, ctmrg_tol=0.0, average_trunc=true,
        verbosity=0, save_iter=0,
    )
    if iteration <= 20 || iteration in (25, 30, 40)
        snapshot(:reuse_trajectory, iteration, env)
    end
end

println("REDUCED_FRESH20_BEGIN chi=", CHI)
fresh = acceptance_seeded_environment()
run_GCTMRG!(
    TBULK, TBULK, fresh, CHI;
    ctmrg_iter=20, ctmrg_tol=0.0, average_trunc=true,
    verbosity=0, save_iter=0,
)
snapshot(:fresh20, 20, fresh)
println("REDUCED_DONE chi=", CHI)
