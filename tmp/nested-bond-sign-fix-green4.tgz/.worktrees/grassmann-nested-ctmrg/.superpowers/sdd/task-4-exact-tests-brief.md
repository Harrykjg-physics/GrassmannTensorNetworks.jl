### Task 1: Replace One-Site CTMRG Tests with Exact Closures

**Files:**

- Modify: `algorithms/Nested_CTMRG/measurements.jl`
- Modify: `test/nested_measurements.jl`
- Preserve the other parent Task 4 file changes.

**Interfaces:**

- Consumes: `nested_network`, `nested_y_operator`, `reduced_tensor`, and
  `nested_test_torus_scalar`.
- Produces: `_check_nested_operator_unit_cell(peps, operators)` for the
  environment-based matrix overload and its environment-free validation
  test.

- [ ] **Step 1: Replace CTMRG fixtures with exact one-site network helpers**

Keep `physical_identity` and add:

```julia
import GrassmannTensorNetworks: _check_nested_operator_unit_cell

const MEASUREMENT_SPIN_STRUCTURES =
    ((false, false), (true, false), (false, true), (true, true))

function exact_site_networks(peps, operator, source::CartesianIndex{2})
    nested = nested_network(peps)
    nested_impurity = copy(nested.network)
    nested_impurity[nested.layout.y_sites[source]] =
        nested_y_operator(nested, peps, source, operator)

    T = eltype(peps)
    reduced_bulk =
        Matrix{Grassmann{T, 4}}(reduced_tensor.(peps.A))
    reduced_impurity = copy(reduced_bulk)
    reduced_impurity[source] =
        reduced_tensor(peps.A[source], operator)

    return (
        nested=nested,
        nested_bulk=nested.network,
        nested_impurity=nested_impurity,
        reduced_bulk=reduced_bulk,
        reduced_impurity=reduced_impurity,
    )
end

function exact_site_scalars(
    networks;
    twist_x::Bool,
    twist_y::Bool,
)
    close(tensors) = nested_test_torus_scalar(
        tensors; twist_x, twist_y
    )
    return (
        nested_denominator=close(networks.nested_bulk),
        nested_numerator=close(networks.nested_impurity),
        reduced_denominator=close(networks.reduced_bulk),
        reduced_numerator=close(networks.reduced_impurity),
    )
end
```

- [ ] **Step 2: Write the exact identity, number, validation, and matrix tests**

Replace every Task 4 test that constructs or iterates an environment with:

```julia
@testset "Exact nested one-site measurements" begin
    Random.seed!(0x4e455354)
    peps = Square_GPEPS(2, 1, 2, 1, 2, Float64, false)
    source = CartesianIndex(1, 1)
    nested = nested_network(peps)
    identity = physical_identity()
    number = n_site(SpinlessFermionModel(1.0, 1.0, 3.0))

    @test nested_y_operator(nested, peps, source, identity) ≈
        nested[nested.layout.y_sites[source]]

    wrong_size = Grassmann(
        Matrix{Float64}(I, 4, 4),
        (4, 4), (2, 2), (:out, :in),
    )
    wrong_even = Grassmann(
        Matrix{Float64}(I, 2, 2),
        (2, 2), (2, 2), (:out, :in),
    )
    wrong_arrows = Grassmann(
        Matrix{Float64}(I, 2, 2),
        (2, 2), (1, 1), (:in, :out),
    )
    @test_throws ArgumentError nested_y_operator(
        nested, peps, (2, 1), number
    )
    @test_throws DimensionMismatch nested_y_operator(
        nested, peps, source, wrong_size
    )
    @test_throws DimensionMismatch nested_y_operator(
        nested, peps, source, wrong_even
    )
    @test_throws ArgumentError nested_y_operator(
        nested, peps, source, wrong_arrows
    )

    operators = fill(number, size(peps))
    @test _check_nested_operator_unit_cell(peps, operators) === nothing
    @test_throws DimensionMismatch _check_nested_operator_unit_cell(
        peps, fill(number, 1, 3)
    )

    identity_networks = exact_site_networks(peps, identity, source)
    number_networks = exact_site_networks(peps, number, source)
    number_numerators = Float64[]
    for (twist_x, twist_y) in MEASUREMENT_SPIN_STRUCTURES
        identity_data = exact_site_scalars(
            identity_networks; twist_x, twist_y
        )
        @test identity_data.nested_denominator ≈
            identity_data.reduced_denominator rtol=5e-12 atol=1e-12
        @test identity_data.nested_numerator ≈
            identity_data.reduced_numerator rtol=5e-12 atol=1e-12
        @test identity_data.nested_numerator /
            identity_data.nested_denominator ≈ 1 atol=1e-12

        number_data = exact_site_scalars(
            number_networks; twist_x, twist_y
        )
        @test number_data.nested_denominator ≈
            number_data.reduced_denominator rtol=5e-12 atol=1e-12
        @test number_data.nested_numerator ≈
            number_data.reduced_numerator rtol=5e-12 atol=1e-12
        @test number_data.nested_numerator /
            number_data.nested_denominator ≈
            number_data.reduced_numerator /
            number_data.reduced_denominator rtol=5e-12 atol=1e-12
        push!(number_numerators, abs(number_data.nested_numerator))
    end
    @test maximum(number_numerators) > 1e-12
end
```

- [ ] **Step 3: Run the focused test and verify RED**

Run in
`/home/jkkong/work/2026/0731/nested-exact-site-019fb340`:

```bash
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/red-exact-site.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann focused_runtests.jl'
```

Expected: the import or validation test fails because
`_check_nested_operator_unit_cell` does not exist. No CTMRG iteration appears
in the command output.

- [ ] **Step 4: Implement the pure matrix-unit-cell validator**

Add:

```julia
function _check_nested_operator_unit_cell(
    peps::Square_GPEPS,
    operators::AbstractMatrix,
)
    size(operators) == size(peps) ||
        throw(DimensionMismatch("operator and PEPS unit cells differ"))
    return nothing
end
```

At the start of the environment-based matrix overload, replace its inline
size check with:

```julia
_check_nested_operator_unit_cell(peps, operators)
```

- [ ] **Step 5: Run focused and full tests and verify GREEN**

Use the same guarded focused command with `log/green-exact-site.log`, then:

```bash
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/full-exact-site.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann server_runtests_offline.jl'
```

Expected: all exact identity/number/validation tests and the full package
suite pass with exit code `0`; peak RSS stays below 20 GB. Run:

```bash
rg -n \
  'CTMRGEnv|initialize_nested_environment|run_GCTMRG!|run_nested_GCTMRG!' \
  test/nested_measurements.jl
```

Expected: no matches.

- [ ] **Step 6: Commit the completed parent Task 4**

```bash
git add algorithms/Nested_CTMRG/measurements.jl \
        src/algorithms.jl src/GrassmannTensorNetworks.jl \
        test/nested_measurements.jl test/runtests.jl \
        test/server_runtests.jl
git commit -m "feat: measure nested one-site operators"
```

---

