#!/usr/bin/env bash
set -u

base=/home/jkkong/work/2026/0801

while true; do
    printf 'POLL %s\n' "$(date --iso-8601=seconds)"
    completed=0
    for chi in 4 8 12; do
        task="$base/nested-accept-chi${chi}-924a20b"
        log="$task/log/accept.log"
        pid="$(cat "$task/results/guard.pid")"
        if grep -q '^--- summary ---' "$log" 2>/dev/null; then
            state=completed
            completed=$((completed + 1))
        elif kill -0 "$pid" 2>/dev/null; then
            state=running
        else
            state=exited-without-summary
        fi
        ad_line="$(grep '^AD ' "$log" 2>/dev/null | tail -n 1)"
        error_line="$(grep -E 'ERROR:|Killed for exceeding' "$log" 2>/dev/null | tail -n 1)"
        printf 'chi=%s pid=%s state=%s last_ad=%q error=%q\n' \
            "$chi" "$pid" "$state" "$ad_line" "$error_line"
    done
    if [ "$completed" -eq 3 ]; then
        exit 0
    fi
    sleep 30
done
