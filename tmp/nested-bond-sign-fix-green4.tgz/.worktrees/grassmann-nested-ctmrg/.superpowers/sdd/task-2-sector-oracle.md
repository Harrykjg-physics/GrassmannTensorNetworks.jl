# Task 2 Native Parity-Sector Oracle

Status: **DONE** for the requested local K/Y/X/B factorization and native
external comparison map.

No tracked production or test file was changed by this derivation. The
pre-existing forensic edits in
`algorithms/Nested_CTMRG/nested_network.jl` and `test/nested_network.jl`
remain untouched and uncommitted.

## Result

The local factorization is exact once three convention boundaries are handled
explicitly:

1. `_nested_x` is the **raw** braid and must retain
   `(-1)^(horizontal_parity*vertical_parity)`. The network node corresponding
   to the reference source is a distinct placed object with the west-leg
   twist.
2. Native `reduced_tensor` stores every external pair in **bra, ket** order.
   The prior plan grouped the reference's **ket, bra** products and therefore
   did not even preserve the complex bilinear entry.
3. TensorKit's categorical fusion/duality gauge is not native `fuse`.
   After the placed-X twist and the exact native `reduced_tensor` fusers, the
   remaining native basis isomorphism is one explicit braid word and three
   twists:

   ```julia
   add_perm_sign(ordered, (2, 3, 5, 4, 6, 7, 1, 8);
                 sign_function=global_sign)
   add_parity_sign(..., 2; sign_function=global_sign)
   add_parity_sign(..., 4; sign_function=global_sign)
   add_parity_sign(..., 6; sign_function=global_sign)
   ```

For all 128 compatible minimal sectors this map cancels the residual
identically over GF(2). Deterministic `Float64` and `ComplexF64` tensors close
bit-for-bit. Three independent minimal seeds per scalar type also close
bit-for-bit. Two larger mixed-multiplicity seeds per scalar type close to
relative error `8.35e-17`--`1.71e-16`, i.e. only floating contraction-order
roundoff remains.

## Sources and authoritative conventions

Read completely:

- Reference implementation:
  `D:\C 盘备份\Back up\Work_Save\coding\VS files\AI optimized Project\PEPSKit_nesting\src\network.jl`
  (148 lines).
- Directly linked reference layout and observable implementation:
  `src/layout.jl` (33 lines) and `src/observables.jl` (189 lines).
- Reference factorization:
  `PEPSKit_nesting/test/local_factorization.jl`, especially lines 12--54.
- Native primitives:
  `src/base.jl`, `src/contract.jl`, `src/fermionsign.jl`,
  `src/fusion.jl`, `src/grassmann.jl`, `auxiliary/ansatz.jl`, and
  `auxiliary/reduced_tensors.jl`.
- PDF:
  `D:\C 盘备份\Back up\Work_Save\latex file\2026\0730_Nested fTN\main.pdf`.
  Pages 4--6 establish arrows, duals, braiding, and twists. Figures 7--12
  are on pages 12, 13, 14, 15, 17, and 18.

The PDF and adjacent reference checkout agree at source baseline `5bd9de5`.

### Reference-to-native convention table

| Boundary | Reference/TensorKit convention | Native convention and required translation |
|---|---|---|
| PEPS order | `A[p; n e s w]`, a map `N*E*S*W -> P` | `A[P,L,R,U,D]`, arrows `(:out,:out,:in,:in,:out)` (`auxiliary/ansatz.jl:8-9`) |
| Four-leg order | `T[w s; n e]`, flat `(W,S,N,E)` | Geographic `(L,R,U,D)=(w,e,n,s)`, arrows `(:out,:in,:in,:out)`; flat conversion is reference permutation `(1,4,3,2)` |
| Same-order exchange | `S(V,W)=1-2 Pi_odd(V) tensor Pi_odd(W)`; it does not swap factors | `_graded_pair_sign(t,i,j)` multiplies a block by `(-1)^(q_i*q_j)` and does not move axes |
| Actual braid | `BraidingTensor(V,W): V*W -> W*V` | `_nested_x` stores the diagonal compass-port crossing and the exact odd-odd sign; route exchange and array-axis order must still be traced separately |
| Twist | `twist(T, i)` supplies `(-1)^q` without changing the space | `add_parity_sign(t,i; sign_function=auto_sign)` |
| Conjugation | TensorMap conjugation changes categorical domain/codomain orientation and `@tensor` supplies coherence maps | Native `conj(t; auto_sign)` keeps axis order, flips every arrow, conjugates values, and multiplies by the full reversal sign `(-1)^(sum_{i<j}q_i*q_j)` (`src/base.jl:229-242`) |
| Arrow bend/cup | TensorKit `flip`/duality isomorphisms can carry pivotal data | Native `index_conjugation` changes metadata only and reuses the same data dictionary (`src/grassmann.jl:302-318`). The current explicit bend is therefore `index_conjugation` plus `add_parity_sign`; it must not be assumed to equal a TensorKit cup without the sector check |
| Permutation | `permute` is a categorical reorder | Native `permutedims(...; auto_sign)` both moves axes and inserts the inversion Koszul phase. `add_perm_sign` inserts that phase without moving axes |
| Fusion basis | `isomorphism(fuse(V,W), V*W)` is a category/gauge choice | Native `fuse` is reshape plus block concatenation and adds no categorical phase (`src/fusion.jl:88-146`) |
| Raw/placed X | Raw `BraidingTensor(K.S,B.W)` has odd-odd `-1`; assembly uses `twist(TensorMap(Xraw),1)` (`network.jl:65-69,128-132`) | Keep `_nested_x` raw. The placed west/horizontal twist is native axis 1: `add_parity_sign(Xraw,1)` |
| Y | `C: V*H -> H*V`, west fusion order `(P,H)`, south `(P',V)`, physical closure `id(P)` | Current native outer product, permutation `(1,3,4,5,2,6)`, and fusions `(P,H)` and `(P',V)` produce geographic `[L,R,U,D]`; its homogeneous phase is `p*bU+kR*bU` |
| External fusers | Reference local test uses ket,bra products; W/S use `twist(F,3)`, N/E use `conj(F)` | Native `reduced_tensor` contracts bra first, so its stored pairs are `(bra,ket)`. It then applies left/down twists and right/up permutation signs before plain native `fuse` (`auxiliary/reduced_tensors.jl:24-40`) |

Two consequences must not be hidden by isotropic tests:

- X arguments are `(horizontal=B.W, vertical=K.S)`, not the reverse.
- Y arguments are `(horizontal=east-neighbour K.W,
  vertical=north-neighbour B.S)`.

The existing Task-3 plan has these X dimensions reversed; `D=2` makes that
mistake invisible.

## Native two-index fusion basis

`calculate_sectors` enumerates the first component fastest. For two mixed
one-dimensional parity sectors, native `fuse(first,second)` therefore stores:

| factor parities `(q1,q2)` | fused parity | dense fused index |
|---|---:|---:|
| `(0,0)` | 0 | 1 |
| `(1,1)` | 0 | 2 |
| `(1,0)` | 1 | 3 |
| `(0,1)` | 1 | 4 |

For arbitrary multiplicities, each row becomes a contiguous subspace with
the same sector order; Julia column-major reshape keeps the first component
fastest inside the product block. This is a concrete native basis statement,
not an assumption about TensorKit's `isomorphism`.

## Exhaustive minimal oracle

Let

```text
b = (bL,bR,bU,bD)
k = (kL,kR,kU,kD)
```

denote virtual parities in the conjugate bra and ket. Since `A` is even and
the physical identity identifies the two physical parities,

```text
p = bL+bR+bU+bD = kL+kR+kU+kD  (mod 2).
```

The even-sum virtual quadruples are

```text
0000 0011 0101 0110 1001 1010 1100 1111
```

and the odd-sum quadruples are

```text
0001 0010 0100 0111 1000 1011 1101 1110.
```

There are `8*8=64` compatible `(b,k)` pairs for `p=0` and another 64 for
`p=1`: 128 in total. The deterministic oracle assigns a distinct nonzero
scalar to every allowed `A[p,kL,kR,kU,kD]` block. Consequently every
compatible reduced entry is a single nonzero bilinear

```text
conj(A[p,bL,bR,bU,bD]) * A[p,kL,kR,kU,kD],
```

so division by that bilinear exposes an exact `+1` or `-1` coefficient at
every operation boundary. Dense arrays are used only to read these
diagnostic coefficients; every candidate tensor and correction is built with
native Grassmann operations.

The bra-first open-leg order is

```text
(bL,kL,bR,kR,bU,kU,bD,kD).
```

## Boundary-by-boundary GF(2) trace

All formulas below are exponents of `(-1)`. Products and sums are in GF(2).
The component fits are:

```text
phi_K =
    kL + kR
  + kL*kU + kL*kD + kR*kU + kR*kD
  = p*(kL+kR)

phi_B =
    bL + bR + bL*bR + bL*bU + bR*bU

phi_Xraw    = bL*kD
phi_Xplaced = bL + bL*kD

phi_Y = p*bU + kR*bU.
```

These match the direct operation trace:

- K: explicit `p*kR` exchange plus the `p*kL` graded permutation.
- B: native full-reversal conjugation, explicit `p*bU`, the `p*(bL+bR)`
  routing permutation, and the three bends.
- raw X: the literal braid `bL*kD`; placed X adds the west twist `bL`.
- Y: literal braid `kR*bU` plus moving the second physical leg, giving
  `p*bU`.

The fitted phase after each larger boundary is:

```text
phi_open_tile =
    kL + bR + kR + kU + bD
  + bL*bR + bL*bU + bL*bD + kL*bU
  + bR*bU + bR*bD + kR*kU + bU*kU

phi_after_bra_first =
    kL + kR + kU
  + bL*kL + bL*kR + bL*kU
  + kL*bR + kL*bU + kL*bD
  + bR*bU + bR*bD + kR*bD
  + bU*bD + kU*bD

phi_after_exact_external_fusers =
    bL + kL + kR + kU + bD
  + bL*kL + bL*kR + bL*kU
  + kL*bR + kL*bU + kL*bD
  + bR*kR + bR*bU + bR*bD + kR*bD
  + bU*kU + bU*bD + kU*bD

phi_reduced_tensor =
    bL + bD
  + bL*bR + bL*bU + bL*bD
  + kL*bR + kL*bU + kL*bD
  + bR*kR + bR*bU + bR*bD
  + kR*bU + kR*bD
  + bU*kU + bU*bD + kU*bD.
```

The quadratic feature matrix has rank 29 and nullity 8 because it is
restricted to the compatible hyperplane. The displayed representatives are
the deterministic row-reduction choices used by the oracle.

After the placed-X twist and exact external fusers, the residual is

```text
D =
    kL + kR + kU
  + bL*kL + bL*bR + bL*kR + bL*bU + bL*kU + bL*bD
  + kR*bU.
```

This is why placed X plus the direct fusers alone still fails.

## Exact basis correction and GF(2) proof

For

```julia
pi = (2, 3, 5, 4, 6, 7, 1, 8)
```

the inversion set is exactly

```text
(bL,kL), (bL,bR), (bL,kR), (bL,bU),
(bL,kU), (bL,bD), (kR,bU).
```

Therefore native

```julia
add_perm_sign(ordered, pi; sign_function=global_sign)
```

contributes the entire quadratic part of `D`. Twisting ordered axes
`(2,4,6)=(kL,kR,kU)` contributes its linear part. Calling the correction
exponent `C`,

```text
C = D,
residual_after = D + C = D + D = 0  (mod 2).
```

This is an algebraic identity on every one of the 128 compatible sectors,
not a random fit. The script also evaluates all sectors and asserts:

```text
SECTORS compatible=128 target_nonzero=128 corrected_residual_nonzero=0
```

Without the placed-X twist, the residual has one additional `bL`. On the
compatible support it also has the useful equivalent form

```text
D_raw = kL+kR+kU + bL*kD + kR*bU,
```

obtained by adding the zero relation

```text
bL*(bL+kL+bR+kR+bU+kU+bD+kD)=0.
```

The diagnostic script used this equivalent form to confirm a
node-distributed local factorization as an independent check. That
alternative is not the recommended handoff because it cancels the explicit
X/Y braid coefficients in the placed nodes and therefore needs a separate
global categorical interpretation.

## Proven native pseudocode

The raw node formulas remain the current sector-proven operations:

```julia
function nested_ket(A)
    signed = graded_pair_sign(A, 1, 3)                 # P,R
    routed = permutedims(signed, (2,1,3,4,5);
                         sign_function=global_sign)
    return fuse(routed, (2,3); index_type_fused=:in)  # (P,R)
end

function nested_bra(A)
    bra = conj(A; sign_function=global_sign)
    signed = graded_pair_sign(bra, 1, 4)               # P,U
    routed = permutedims(signed, (2,3,1,4,5);
                         sign_function=global_sign)
    fused = fuse(routed, (3,4); index_type_fused=:in)  # (P,U)
    return bend(bend(bend(fused, 1), 2), 4)
end

Xraw[h,h,v,v] = (-1)^(parity(h)*parity(v))
Xplaced = add_parity_sign(Xraw, 1; sign_function=global_sign)

function nested_y(identity, H, V)
    product = contract(identity, Xraw(H,V);
                       sign_function=global_sign)
    routed = permutedims(product, (1,3,4,5,2,6);
                         sign_function=global_sign)
    west = fuse(routed, (1,2); index_type_fused=:out)
    return fuse(west, (4,5); index_type_fused=:out)
end
```

The exact local closure/comparison is:

```julia
ky = contract(K, Y, (2,1); sign_function=global_sign)
kx = contract(ky, Xplaced, (3,3); sign_function=global_sign)
tile = contract(kx, B, ((5,7),(3,1)); sign_function=global_sign)

# Native reduced_tensor stores (bra,ket) in each direction.
ordered = permutedims(tile, (5,1,7,3,4,2,8,6);
                      sign_function=global_sign)

# TensorKit categorical gauge -> native fuse gauge.
ordered = add_perm_sign(
    ordered, (2,3,5,4,6,7,1,8); sign_function=global_sign
)
for index in (2,4,6)
    ordered = add_parity_sign(
        ordered, index; sign_function=global_sign
    )
end

# Exact native reduced_tensor external fusers.
ordered = add_parity_sign(ordered, 1; sign_function=global_sign)
left = fuse(ordered, (1,2); index_type_fused=:out)
left = add_perm_sign(
    left, (1,3,2,4,5,6,7); sign_function=global_sign
)
right = fuse(left, (2,3); index_type_fused=:in)
right = add_perm_sign(
    right, (1,2,4,3,5,6); sign_function=global_sign
)
up = fuse(right, (3,4); index_type_fused=:in)
up = add_parity_sign(up, 4; sign_function=global_sign)
candidate = fuse(up, (4,5); index_type_fused=:out)
```

`candidate == reduced_tensor(A)` is bitwise true in both deterministic
minimal scalar-type cases.

## Verification

Diagnostic sources:

- `.superpowers/sdd/task-2-oracle/sector_oracle.jl`
- `.superpowers/sdd/task-2-oracle/run_oracle.sh`
- copied final output:
  `.superpowers/sdd/task-2-oracle/sector-oracle-v3.log`

Remote task:

```text
/home/jkkong/work/2026/0731/nested-task2-sector-oracle-019fb340
```

Required environment:

```text
PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin
JULIA_PKG_OFFLINE=true
julia_grassmann
20 GB run_with_memory_guard.sh
```

Final command:

```bash
cd /home/jkkong/work/2026/0731/nested-task2-sector-oracle-019fb340
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/sector-oracle-v3.log \
  -- bash -ic \
  "export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin; \
   export JULIA_PKG_OFFLINE=true; \
   export NESTED_ORACLE_TASK_ROOT=/home/jkkong/work/2026/0731/nested-task2-sector-oracle-019fb340; \
   julia_grassmann \
   /home/jkkong/work/2026/0731/nested-task2-sector-oracle-019fb340/exp/sector_oracle.jl"
```

Final guarded result:

```text
ORACLE_RESULT PASS
exit_code: 0
peak_rss_kb: 810280
killed_for_memory: 0
duration_seconds: 67
```

Case results:

| Case | Result |
|---|---|
| deterministic Float64, minimal | bitwise exact; max abs `0.0` |
| deterministic ComplexF64, minimal | bitwise exact; max abs `0.0` |
| Float64 minimal seeds 1103, 2207, 3301 | bitwise exact |
| ComplexF64 minimal seeds 1103, 2207, 3301 | bitwise exact |
| larger mixed Float64 `(3,3,4,3,4)`, even `(2,1,3,2,1)`, seeds 4409/5519 | relative `1.13e-16`, `8.35e-17` |
| larger mixed ComplexF64, same dimensions/seeds | relative `1.71e-16`, `1.25e-16` |
| raw X, all basis states in every case | diagonal `(-1)^(h*v)`, all off-diagonal entries zero |

The larger residuals are floating association error, not a parity residual:
the phase proof is multiplicity-independent and the minimal exhaustive
residual is exactly zero.

Local Julia log:

```text
D:\C 盘备份\Back up\Work_Save\coding\codex_server_logs\2026\0731\nested-task2-sector-oracle-019fb340.md
```

## Minimal implementation handoff

1. Preserve `_nested_x` as the raw exchange tensor so its odd-odd entry
   remains exactly `-1` and the other three parity exchanges remain `+1`.
2. Distinguish raw X from the placed X; apply the west/axis-1 twist at
   placement.
3. Keep the sector-proven K, B, and closed-Y operations above.
4. Replace the ket-first local test comparison with bra-first order
   `(5,1,7,3,4,2,8,6)`.
5. Add the native basis-isomorphism helper (one `add_perm_sign`, three
   `add_parity_sign` calls), then apply the exact `reduced_tensor` fusers.
6. Add the deterministic 128-sector test and at least one anisotropic
   dimension test; do not rely only on `Dvir=2`.

No dense conversion belongs in production.

## Remaining composition risk

The proven basis correction is a multi-leg comparison morphism, not a
product of four independent diagonal leg gauges. It is valid and necessary
for the requested local closure. It must not be silently attached to one
network bond.

An exploratory one-tile periodic `trace` that omitted this comparison
morphism did not match the trace of `reduced_tensor`; neither the original
placed-node set nor the diagnostic node-distributed equivalent passed that
probe. This is not a contradiction of the local identity: the probe did not
insert/invert the derived external fusion/basis maps and is not the
reference's `@tensor` periodic contraction.

Before Task 3 is accepted, run a proper native analogue of the reference
`2x2 reduced / 4x4 nested` contraction under all four spin structures, with
the proven external basis maps composed explicitly. Treat a failure there as
a global assembly blocker rather than changing another local sign.

