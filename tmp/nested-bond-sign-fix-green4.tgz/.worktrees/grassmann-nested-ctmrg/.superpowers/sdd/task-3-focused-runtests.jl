using Pkg

Pkg.activate(joinpath(@__DIR__, "harness"))
Pkg.develop(path=joinpath(@__DIR__, "src"))

using Test
using LinearAlgebra
using GrassmannTensorNetworks

@testset "Focused nested network" begin
    include(joinpath(@__DIR__, "src", "test", "nested_network.jl"))
end
