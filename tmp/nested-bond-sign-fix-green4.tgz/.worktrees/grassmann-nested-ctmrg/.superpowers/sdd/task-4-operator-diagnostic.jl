using Pkg

Pkg.activate(joinpath(@__DIR__, "harness"))
Pkg.develop(path=joinpath(@__DIR__, "src"))

using LinearAlgebra
using Random
using GrassmannTensorNetworks

@eval GrassmannTensorNetworks global global_sign = auto_sign

function close_nested_test_row(row; twist_x=false)
    sign = GrassmannTensorNetworks.global_sign
    cols = length(row)
    current =
        permutedims(row[1], (1, 3, 4, 2); sign_function=sign)
    for c in 2:cols
        j = c - 1
        rank = 2j + 2
        perm = (
            1,
            (2:(j + 1))...,
            2j + 3,
            ((j + 2):(2j + 1))...,
            2j + 4,
            2j + 2,
        )
        current = contract(
            current, row[c], (rank, 1);
            perm, sign_function=sign,
        )
    end
    return trace(
        current, (1, 2cols + 2);
        pbc=!twist_x, sign_function=sign,
    )
end

function nested_test_torus_scalar(tensors; twist_x=false, twist_y=false)
    sign = GrassmannTensorNetworks.global_sign
    rows, cols = size(tensors)
    row_tensors = [
        close_nested_test_row(collect(tensors[r, :]); twist_x)
        for r in 1:rows
    ]
    current = row_tensors[1]
    for r in 2:rows
        current = contract(
            current,
            row_tensors[r],
            (ntuple(i -> cols + i, cols), ntuple(identity, cols));
            sign_function=sign,
        )
    end
    closed = trace(
        current,
        (ntuple(identity, cols), ntuple(i -> cols + i, cols));
        pbc=ntuple(_ -> !twist_y, cols),
        sign_function=sign,
    )
    return scalar(closed)
end

function contract_corrected_nested_tile(K, Y, X, B)
    sign = GrassmannTensorNetworks.global_sign
    ky = contract(K, Y, (2, 1); sign_function=sign)
    kx = contract(ky, X, (3, 3); sign_function=sign)
    tile = contract(kx, B, ((5, 7), (3, 1)); sign_function=sign)
    ordered = permutedims(
        tile, (5, 1, 7, 3, 4, 2, 8, 6); sign_function=sign
    )
    ordered =
        GrassmannTensorNetworks._nested_network_reduced_basis(ordered)
    ordered = add_parity_sign(ordered, 1; sign_function=sign)
    left = fuse(ordered, (1, 2); index_type_fused=:out)
    left = add_perm_sign(
        left, (1, 3, 2, 4, 5, 6, 7); sign_function=sign
    )
    right = fuse(left, (2, 3); index_type_fused=:in)
    right = add_perm_sign(
        right, (1, 2, 4, 3, 5, 6); sign_function=sign
    )
    up = fuse(right, (3, 4); index_type_fused=:in)
    up = add_parity_sign(up, 4; sign_function=sign)
    return fuse(up, (4, 5); index_type_fused=:out)
end

Random.seed!(0x4e455354)
peps = Square_GPEPS(2, 1, 2, 1, 1, Float64, false)
number = n_site(SpinlessFermionModel(1.0, 1.0, 3.0))

nested = nested_network(peps)
nested_number_y = nested_y_operator(nested, peps, (1, 1), number)
local_nested_number = contract_corrected_nested_tile(
    nested[nested.layout.ket_sites[1, 1]],
    nested_number_y,
    nested[nested.layout.x_sites[1, 1]],
    nested[nested.layout.bra_sites[1, 1]],
)
local_reduced_number = reduced_tensor(peps.A[1, 1], number)
println(
    "local_operator_isapprox=",
    isapprox(
        local_nested_number, local_reduced_number;
        rtol=5e-13, atol=1e-13,
    ),
)
println(
    "local_operator_relative_error=",
    norm(local_nested_number - local_reduced_number) /
    norm(local_reduced_number),
)

nested_impurity = copy(nested.network)
nested_impurity[nested.layout.y_sites[1, 1]] =
    nested_number_y
nested_ratio =
    nested_test_torus_scalar(nested_impurity) /
    nested_test_torus_scalar(nested.network)

reduced_bulk =
    Matrix{Grassmann{Float64, 4}}(reduced_tensor.(peps.A))
reduced_impurity =
    Matrix{Grassmann{Float64, 4}}(
        reduced_tensor.(peps.A, Ref(number))
    )
reduced_ratio =
    nested_test_torus_scalar(reduced_impurity) /
    nested_test_torus_scalar(reduced_bulk)

println("nested_ratio=", nested_ratio)
println("reduced_ratio=", reduced_ratio)
println("ratio_difference=", nested_ratio - reduced_ratio)
