# Task 3 Existing-Ops — Task 2 Report

Status: **DONE**

## Implementation

Implemented the ordinary corrected `2m x 2n` rank-four checkerboard using
the reviewed native placement helpers and existing Grassmann tensor
operations only:

- `nested_network(peps, layout)` validates the layout source size, constructs
  corrected K/B/Y placements, stores corrected placed X tensors in the
  checkerboard, and preserves raw X tensors in
  `NestedNetwork.x_crossings`.
- `_check_nested_links` audits every periodic right/down link for total
  dimension, even-sector dimension, and opposite arrow direction.
- Y dimensions are taken from the periodic north-bra/east-ket neighbors, so
  arbitrary odd/even source shapes and nonuniform periodic multiplicities are
  supported.
- `initialize_nested_environment` delegates directly to
  `CTMRGEnv(nested.network, chi, chi_even)`.
- `run_nested_GCTMRG!` validates environment/network size, delegates to
  `run_GCTMRG!` with the nested checkerboard as bulk and impurity, forwards
  all keywords, and returns the same environment.
- Exported the three public Task 2 interfaces.

No MPO, correction parameter, tangent field, or new tensor structure was
introduced. Raw Task 2 constructors and all reviewed Task 1 placement helpers
remain unchanged.

## Files changed

- `algorithms/Nested_CTMRG/nested_network.jl`
- `test/nested_network.jl`
- `src/GrassmannTensorNetworks.jl`

The test additions include the exact native periodic closure helpers,
all four spin structures, `1 x 1`, `1 x 2`, `2 x 1`, and `2 x 2` source
shapes, nonuniform Float64/ComplexF64 mixed multiplicities, periodic link
audits, mismatched-layout rejection, raw/corrected X assertions, and the
one-iteration CTMRG smoke test.

## TDD evidence

All Julia execution was remote-only on
`jkkong@172.23.26.248` through `julia_grassmann`. Every run used the
20 GB process-group memory guard in:

```text
/home/jkkong/work/2026/0731/nested-existing-ops-assembly-019fb340
```

### Assembly RED

Exact command:

```bash
cd /home/jkkong/work/2026/0731/nested-existing-ops-assembly-019fb340
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/red-assembly.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann focused_runtests.jl'
```

Result: exit 1, 174 passed, 3 failed, 3 errored, duration 78 seconds,
peak RSS 975,540 KB, no memory kill. The public API assertions failed, and
the assembly, universal periodic, and mixed algebra testsets each reached
their first construction call and errored specifically with
`UndefVarError: nested_network not defined`. Existing nested behavior passed.

The initial focused harness included the test file outside a containing
testset, causing Julia to stop at the first top-level failed assertion. That
setup-only attempt is preserved as `log/red-assembly-harness.log` (exit 1,
14 seconds, 702,644 KB). Wrapping the include in an outer testset allowed the
required full RED evidence without changing project tests.

### Assembly GREEN

Exact command:

```bash
cd /home/jkkong/work/2026/0731/nested-existing-ops-assembly-019fb340
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/green-periodic.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann focused_runtests.jl'
```

Result: exit 0, 303/303 passed, duration 116 seconds, peak RSS
892,240 KB, no memory kill.

The checkpoint covers:

- 102 checkerboard/link/raw-X assertions;
- 16 universal shape/spin assertions;
- 8 mixed Float64/ComplexF64 multiplicity assertions;
- all existing placement/local assertions.

Because the brief places all three `isdefined` assertions before the two
ordered implementation stages, empty generic adapter declarations were used
temporarily for this assembly-only checkpoint. They supplied no methods.
They were removed when the exact adapter methods were added, so they do not
appear in the final diff. The preceding intermediate log
`log/green-periodic-predecl.log` independently shows that all assembly and
periodic assertions were already green while only the two future API-name
assertions remained red.

### CTMRG RED

After adding the prescribed smoke test, the exact command was:

```bash
cd /home/jkkong/work/2026/0731/nested-existing-ops-assembly-019fb340
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/red-ctmrg.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann focused_runtests.jl'
```

Result: exit 1, 303 passed, 1 errored, duration 118 seconds, peak RSS
920,636 KB, no memory kill. The smoke test alone errored with:

```text
MethodError: no method matching
initialize_nested_environment(::NestedNetwork, ::Int64)
```

This proves the missing adapter behavior independently of assembly.

### Final focused GREEN

Exact command:

```bash
cd /home/jkkong/work/2026/0731/nested-existing-ops-assembly-019fb340
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/green-final.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann focused_runtests.jl'
```

Result: exit 0, 305/305 passed, duration 138 seconds, peak RSS
963,748 KB, no memory kill. The one-iteration GCTMRG smoke completed and
returned the original environment.

## Full guarded suite

Exact command:

```bash
cd /home/jkkong/work/2026/0731/nested-existing-ops-assembly-019fb340
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/full.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann server_runtests_offline.jl'
```

Result: exit 0, `GrassmannTensorNetworks | 1252 / 1252`, test time
10m00.5s, guarded duration 676 seconds, peak RSS 1,378,312 KB, no memory
kill.

The first full-suite wrapper attempt failed before test execution because a
shell-generated `joinpath` lost its string quotes. It is preserved as
`log/full-harness.log` (exit 1, 4 seconds, 394,924 KB). Uploading a literal
untracked wrapper fixed only the remote harness; the project source was not
changed.

## Logs

- Local required Markdown log:
  `D:\C 盘备份\Back up\Work_Save\coding\codex_server_logs\2026\0731\nested-existing-ops-assembly_019fb340.md`
- Remote logs:
  `/home/jkkong/work/2026/0731/nested-existing-ops-assembly-019fb340/log/`

## Commit

```text
a32fe9cd317cdddf13dff98badb823e04a0ca3c0
feat: assemble corrected nested network
```

The commit contains exactly the three specified tracked files.

## Self-review

- `git diff --check` passed before staging.
- `git diff --cached --check` passed.
- Post-commit `git diff HEAD^ HEAD --check` passed.
- The worktree is clean after commit.
- The final production diff is the brief’s exact corrected constructor,
  link validation, and thin CTMRG adapters.
- `NestedNetwork.x_crossings` contains raw X; only the checkerboard X sites
  contain `_nested_x_for_network(xraw)`.
- Neighbor-derived Y dimensions cover odd/even source shapes and mixed
  periodic multiplicities.
- The environment adapter checks size before delegating and forwards all
  keywords unchanged.
- Fresh focused and full guarded server suites pass below the 20 GB limit.

## Concerns

None for the implementation. Two remote test-harness setup issues were
diagnosed and preserved in separate logs; neither involved or changed
tracked project code.
