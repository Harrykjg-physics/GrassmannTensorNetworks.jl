using Test

const TASK_ROOT = "/home/jkkong/work/2026/0801/task7-nested-example-a13f/exp"
TASK_ROOT in LOAD_PATH || pushfirst!(LOAD_PATH, TASK_ROOT)

include(joinpath(
    TASK_ROOT,
    "examples",
    "Spinless_Fermion_2D_Square_AD_nested",
    "Spinless_Fermion_2D_Square_AD_nested.jl",
))

@testset "Nested line-search validation RED" begin
    params = normalized_params([1.0, -0.5, 0.75, 2.0])
    objective = x -> sum(abs2, x)
    @test_throws ArgumentError _normalized_gradient_candidate(
        objective, params; max_step_norm=Inf
    )

    error = try
        run_Square_SpinlessFermion_AD_nested(
            1.0, 1.0, 3.0, 1, 1, 1, 4, 1;
            ad_iter=1, min_step=0.0,
        )
        nothing
    catch caught
        caught
    end
    @test error isa ArgumentError
    @test occursin("min_step", sprint(showerror, error))
end
