### Task 1: Add Universal Native Placement Helpers

**Files:**

- Modify: `algorithms/Nested_CTMRG/nested_network.jl`
- Modify: `test/nested_network.jl`

**Interfaces:**

- Consumes: `_nested_ket`, `_nested_bra`, `_nested_x`,
  `_placed_nested_x`, `_nested_y`, `_graded_pair_sign`,
  `add_parity_sign`, `add_perm_sign`, and `global_sign`.
- Produces:
  - `_nested_ket_for_network(A)`
  - `_nested_bra_for_network(A)`
  - `_nested_x_for_network(xraw)`
  - `_nested_y_for_network(yraw)`
  - `_nested_network_reduced_basis(ordered)`

- [ ] **Step 1: Write failing placement and corrected-factorization tests**

Import the five new private helpers and append:

```julia
import GrassmannTensorNetworks:
    _nested_ket_for_network,
    _nested_bra_for_network,
    _nested_x_for_network,
    _nested_y_for_network,
    _nested_network_reduced_basis

function contract_corrected_nested_tile(K, Y, X, B)
    sign = GrassmannTensorNetworks.global_sign
    ky = contract(K, Y, (2, 1); sign_function=sign)
    kx = contract(ky, X, (3, 3); sign_function=sign)
    tile = contract(kx, B, ((5, 7), (3, 1)); sign_function=sign)
    ordered = permutedims(
        tile, (5, 1, 7, 3, 4, 2, 8, 6); sign_function=sign
    )
    ordered = _nested_network_reduced_basis(ordered)
    ordered = add_parity_sign(ordered, 1; sign_function=sign)
    left = fuse(ordered, (1, 2); index_type_fused=:out)
    left = add_perm_sign(
        left, (1, 3, 2, 4, 5, 6, 7); sign_function=sign
    )
    right = fuse(left, (2, 3); index_type_fused=:in)
    right = add_perm_sign(
        right, (1, 2, 4, 3, 5, 6); sign_function=sign
    )
    up = fuse(right, (3, 4); index_type_fused=:in)
    up = add_parity_sign(up, 4; sign_function=sign)
    return fuse(up, (4, 5); index_type_fused=:out)
end

function corrected_nested_tile(A)
    K = _nested_ket_for_network(A)
    B = _nested_bra_for_network(A)
    Xraw = _nested_x(
        size(B)[1], even(B)[1], size(K)[4], even(K)[4], eltype(A)
    )
    X = _nested_x_for_network(Xraw)
    Yraw = _nested_y(
        _physical_identity(A),
        size(A)[3], even(A)[3],
        size(A)[4], even(A)[4],
    )
    Y = _nested_y_for_network(Yraw)
    return contract_corrected_nested_tile(K, Y, X, B)
end

@testset "Universal native nested placement signs" begin
    A = deterministic_nested_tensor(
        ComplexF64, (2, 2, 2, 2, 2), (1, 1, 1, 1, 1)
    )
    xraw = _nested_x(2, 1, 2, 1, ComplexF64)
    @test only(xraw[(1, 1, 1, 1)]) == -1
    @test index_type(_nested_x_for_network(xraw)) == index_type(xraw)
    @test size(_nested_x_for_network(xraw)) == size(xraw)
    @test corrected_nested_tile(A) ≈ reduced_tensor(A) rtol=1e-12
end

@testset "Universal native placement preserves mixed bases" begin
    sizes = (3, 3, 4, 3, 4)
    evens = (2, 1, 3, 2, 1)
    for T in (Float64, ComplexF64)
        A = deterministic_nested_tensor(T, sizes, evens)
        @test corrected_nested_tile(A) ≈ reduced_tensor(A) rtol=5e-13
    end
end
```

- [ ] **Step 2: Run the focused test and verify RED**

Run only `test/nested_network.jl` with the Task 2 layout:

```bash
cd /home/jkkong/work/2026/0731/nested-existing-ops-placement-019fb340
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/red.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann focused_runtests.jl'
```

Expected: import failure because `_nested_ket_for_network` and the other
placement helpers do not exist. Existing Task 2 tests before that import
remain green.

- [ ] **Step 3: Implement the universal placement helpers**

Add:

```julia
function _nested_input_north_twist(A::Grassmann)
    return add_parity_sign(A, 4; sign_function=global_sign)
end

_nested_ket_for_network(A::Grassmann{T, 5}) where {T} =
    _nested_ket(_nested_input_north_twist(A))

_nested_bra_for_network(A::Grassmann{T, 5}) where {T} =
    _nested_bra(_nested_input_north_twist(A))

function _nested_x_for_network(xraw::Grassmann{T, 4}) where {T}
    placed = _placed_nested_x(xraw)
    return add_perm_sign(
        placed, (1, 3, 2, 4); sign_function=global_sign
    )
end

function _nested_y_for_network(yraw::Grassmann{T, 4}) where {T}
    return add_perm_sign(
        yraw, (1, 3, 2, 4); sign_function=global_sign
    )
end

function _nested_network_reduced_basis(
    ordered::Grassmann{T, 8}
) where {T}
    corrected = ordered
    for axis in (1, 2, 4, 5)
        corrected = add_parity_sign(
            corrected, axis; sign_function=global_sign
        )
    end
    return corrected
end
```

Do not replace or weaken `_nested_reduced_basis`; it remains the comparison
map for the raw Task 2 primitives.

- [ ] **Step 4: Run focused tests and verify GREEN**

```bash
cd /home/jkkong/work/2026/0731/nested-existing-ops-placement-019fb340
./run_with_memory_guard.sh \
  --limit-gb 20 \
  --log log/green.log \
  -- bash -ic \
  'export PATH=/home/jkkong/bin:/usr/local/bin:/usr/bin:/bin;
   export JULIA_PKG_OFFLINE=true;
   julia_grassmann focused_runtests.jl'
```

Expected:

- raw X odd-odd remains `-1`;
- minimal `Float64` and `ComplexF64` corrected closure passes;
- nonuniform mixed-coordinate closure passes;
- all prior Task 1 and Task 2 assertions pass.

- [ ] **Step 5: Commit**

```bash
git add algorithms/Nested_CTMRG/nested_network.jl test/nested_network.jl
git commit -m "fix: place native nested fermion signs"
```

---

