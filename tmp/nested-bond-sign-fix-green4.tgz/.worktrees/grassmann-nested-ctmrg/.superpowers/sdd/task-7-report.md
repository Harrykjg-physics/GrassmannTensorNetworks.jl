# Task 7 implementation report

Status: DONE (implementation and example-local verification complete; awaiting
fresh review before commit)

## Implemented

- Added the example-local `Project.toml` with Zygote and the Test target. Optim
  was removed after its dependency chain proved unavailable on the required
  server.
- Added the nested spinless-fermion AD driver with guarded package setup,
  midpoint exact-energy quadrature, a deterministic Zygote-only normalized
  steepest-descent candidate with Armijo backtracking and a total trust radius,
  nested CTMRG refresh/validation, and the acceptance report.
- Renamed the local parameter-count variable so it does not shadow
  `Base.count` when the final report counts accepted steps.
- The energy is the unit-cell average of the public horizontal and vertical
  `nn_bond` measurements. No extra one-site term, MPO, or new tensor-network
  structure is used.
- Added example-local exact-energy and one-step AD smoke tests. Including the
  example from this test does not activate or instantiate a project.
- Restored `test/nested_measurements.jl` after the plan moved Task 7 tests out
  of the root measurement suite.

## Verification evidence

- TDD RED: focused helper call failed because
  `_normalized_gradient_candidate` was undefined; exit `1`, duration `6 s`,
  peak RSS `509,060 KB`, no memory kill.
- Final remote example-local suite passed `26 / 26` under the 20 GB guard:
  exact `2 / 2`, pure helper `19 / 19`, one-step nested smoke `5 / 5`; exit
  `0`, duration `123 s`, peak RSS `1,499,456 KB`, no memory kill.
- Smoke energy changed from `-0.440463887147` to fresh-validated
  `-0.974376017856`; gradient norm was `1.0255` and the accepted outer step
  was `1.0`.
- Fresh static check passed for exactly three Task 7 files: required Project
  entries exist, files have final LF/no tabs/no trailing whitespace, forbidden
  reduced/site/MPO/ForwardDiff patterns are absent, and
  `test/nested_measurements.jl` is unchanged.
- Optim and all lazy loading were removed; no Optim dependency or reference
  remains in the three Task 7 files. The isolated Zygote-only environment
  instantiated offline in `8 s` and the complete smoke ran successfully.
- The Julia 1.12 module-global setup issue exposed by the first complete GREEN
  attempt was corrected with the repository's existing `@eval ... global`
  pattern in both the test and direct-script entry points.
- No Julia code was run locally.

## Pending

Request fresh Task 7 review. Do not commit until that review approves the
three-file change.

## Fresh-review validation fix

- Important finding: invalid outer `step_shrink`/`min_step` could bypass a
  finite terminating backtracking schedule; helper also accepted an infinite
  trust radius.
- RED: focused regression produced the expected `max_step_norm=Inf` missing
  exception and wrong `min_step=0` validation path (`1` passed, `2` failed;
  exit `1`, `40 s`, peak RSS `1,359,632 KB`).
- Fix: require finite nonnegative `max_step_norm`, finite `step_shrink` in
  `(0,1)`, and finite positive `min_step`, all before CTMRG construction.
- Focused GREEN: `3 / 3`, exit `0`, `38 s`, peak RSS `1,370,876 KB`.
- Complete GREEN: exact `2 / 2`, helper `21 / 21`, parameter validation
  `16 / 16`, nested smoke `5 / 5`; total `44 / 44`, exit `0`, `122 s`, peak
  RSS `1,507,732 KB`, no memory kill.
- Fresh static check passed for the three-file, 601-line uncommitted change;
  root tests remain unchanged. Awaiting re-review.
